'use strict';
const root = document.getElementById('app');
const state = { user: null, tab: null, products: [], cart: new Map(), table: '', orders: [], error: '', timer: null };
const money = (c) => (c / 100).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' });
const has = (...roles) => state.user?.roles.some((r) => roles.includes(r));
const STATUS = { pending: 'Pendiente', preparing: 'En preparación', ready: 'Listo', served: 'Servido' };

function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'onclick' || k === 'oninput') el[k] = v; else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || 'GET', credentials: 'same-origin',
    headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== '/api/v1/auth/login') { state.user = null; stop(); render(); }
  if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
  return data;
}

const run = async (fn) => { state.error = ''; try { await fn(); } catch (e) { state.error = e.message; } render(); };
const stop = () => { clearInterval(state.timer); state.timer = null; };

function tabs() {
  const t = [];
  if (has('waiter', 'cashier', 'manager', 'admin')) t.push(['comanda', 'Comanda'], ['mesas', 'Mesas']);
  if (has('kitchen', 'bar', 'manager', 'admin')) t.push(['estacion', 'Estación']);
  return t;
}

async function refreshOrders() { state.orders = (await api('/api/v1/orders')).orders; }
function poll() {
  stop();
  if (state.tab === 'comanda') return;
  state.timer = setInterval(() => run(refreshOrders), 5000);
}
async function go(tab) {
  state.tab = tab; state.error = '';
  if (tab === 'comanda' && !state.products.length) state.products = (await api('/api/v1/products')).products;
  if (tab !== 'comanda') await refreshOrders();
  poll(); render();
}

function loginView() {
  const u = h('input', { placeholder: 'Usuario', autocomplete: 'username', autocapitalize: 'none', autocorrect: 'off' });
  const p = h('input', { placeholder: 'Contraseña', type: 'password', autocomplete: 'current-password' });
  const submit = () => run(async () => {
    const r = await api('/api/v1/auth/login', { method: 'POST', body: { username: u.value.trim(), password: p.value } });
    state.user = r.user; state.products = [];
    await go(tabs()[0]?.[0] ?? 'comanda');
  });
  p.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
  return [h('h1', {}, 'Barbachu POS'), u, p, h('button', { class: 'wide', onclick: submit }, 'Entrar')];
}

function comandaView() {
  const table = h('input', { placeholder: 'Mesa (ej. 4 o Barra 2)', value: state.table, maxlength: '20', oninput: (e) => { state.table = e.target.value; } });
  const byCat = new Map();
  for (const p of state.products) byCat.set(p.category, [...(byCat.get(p.category) || []), p]);
  const list = [];
  for (const [cat, items] of byCat) {
    list.push(h('h2', {}, cat));
    for (const p of items) {
      const q = state.cart.get(p.sku)?.qty || 0;
      const set = (n) => { n > 0 ? state.cart.set(p.sku, { qty: Math.min(n, 50), note: state.cart.get(p.sku)?.note || '' }) : state.cart.delete(p.sku); render(); };
      list.push(h('div', { class: 'card row' },
        h('div', {}, h('div', {}, p.name), h('div', { class: 'mut' }, money(p.price_cents))),
        h('div', { class: 'qty' }, h('button', { class: 'alt', 'aria-label': 'Quitar', onclick: () => set(q - 1) }, '−'), h('b', {}, q), h('button', { 'aria-label': 'Agregar', onclick: () => set(q + 1) }, '+'))));
    }
  }
  const total = [...state.cart].reduce((s, [sku, c]) => s + c.qty * state.products.find((p) => p.sku === sku).price_cents, 0);
  const send = h('button', { class: 'wide', disabled: !state.cart.size || !state.table.trim(), onclick: () => run(async () => {
    await api('/api/v1/orders', { method: 'POST', body: { table: state.table.trim(), items: [...state.cart].map(([sku, c]) => ({ sku, qty: c.qty })) } });
    state.cart.clear(); state.table = ''; await go('mesas');
  }) }, `Enviar comanda · ${money(total)}`);
  return [h('h1', {}, 'Nueva comanda'), table, ...list, h('div', { style: 'height:12px' }), send];
}

function advance(item, to, label) {
  return h('button', { onclick: () => run(async () => { await api(`/api/v1/order-items/${item.id}/status`, { method: 'PATCH', body: { status: to } }); await refreshOrders(); }) }, label);
}

function mesasView() {
  if (!state.orders.length) return [h('h1', {}, 'Mesas'), h('p', { class: 'mut' }, 'No hay órdenes abiertas.')];
  return [h('h1', {}, 'Mesas'), ...state.orders.map((o) => h('div', { class: 'card' },
    h('div', { class: 'row' }, h('b', {}, `Mesa ${o.table_label}`), h('span', {}, money(o.total_cents))),
    ...o.items.map((i) => h('div', { class: 'row', style: 'margin-top:8px' },
      h('div', {}, `${i.qty}× ${i.name}`, h('div', { class: i.status === 'ready' ? 'ok' : 'mut' }, STATUS[i.status] + (i.note ? ` · ${i.note}` : ''))),
      i.status === 'ready' ? advance(i, 'served', 'Servido') : null)),
    has('cashier', 'manager', 'admin') ? h('button', { class: 'wide', style: 'margin-top:10px', disabled: o.items.some((i) => i.status !== 'served'),
      onclick: () => run(async () => { await api(`/api/v1/orders/${o.id}/close`, { method: 'POST' }); await refreshOrders(); }) }, `Cobrar y cerrar · ${money(o.total_cents)}`) : null))];
}

function estacionView() {
  const mine = (i) => has('manager', 'admin') || has(i.station);
  const rows = state.orders.flatMap((o) => o.items.filter((i) => mine(i) && ['pending', 'preparing'].includes(i.status)).map((i) => ({ o, i })));
  if (!rows.length) return [h('h1', {}, 'Estación'), h('p', { class: 'mut' }, 'Sin pendientes.')];
  return [h('h1', {}, 'Estación'), ...rows.map(({ o, i }) => h('div', { class: 'card row' },
    h('div', {}, h('b', {}, `Mesa ${o.table_label}`), h('div', {}, `${i.qty}× ${i.name}`), h('div', { class: 'mut' }, STATUS[i.status] + (i.note ? ` · ${i.note}` : ''))),
    i.status === 'pending' ? advance(i, 'preparing', 'Preparar') : advance(i, 'ready', 'Listo')))];
}

function render() {
  const scroll = window.scrollY;
  root.replaceChildren();
  if (state.error) root.append(h('div', { class: 'err', role: 'alert' }, state.error));
  if (!state.user) { root.append(...loginView()); return; }
  const views = { comanda: comandaView, mesas: mesasView, estacion: estacionView };
  root.append(h('div', { class: 'row mut' }, h('span', {}, state.user.display_name), h('button', { class: 'alt', onclick: () => run(async () => { await api('/api/v1/auth/logout', { method: 'POST' }); state.user = null; stop(); }) }, 'Salir')));
  root.append(...(views[state.tab] || mesasView)());
  const t = tabs();
  if (t.length > 1) document.body.append(...[]);
  document.querySelector('nav')?.remove();
  document.body.append(h('nav', {}, t.map(([id, label]) => h('button', { class: id === state.tab ? 'on' : '', onclick: () => run(() => go(id)) }, label))));
  window.scrollTo(0, scroll);
}

(async () => {
  try {
    state.user = (await api('/api/v1/auth/me')).user;
    await go(tabs()[0]?.[0] ?? 'mesas');
  } catch { state.user = null; }
  render();
})();
