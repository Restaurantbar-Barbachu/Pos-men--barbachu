import { authenticate, requireRoles } from './auth.mjs';
import { canTransition, canActOnItem, orderTotalCents } from '../lib/orders-logic.mjs';

const uuidParams = { type: 'object', required: ['id'], properties: { id: { type: 'string', format: 'uuid' } } };

const createSchema = {
  body: {
    type: 'object', required: ['table', 'items'], additionalProperties: false,
    properties: {
      table: { type: 'string', pattern: '^[A-Za-z0-9 .#-]{1,20}$' },
      items: {
        type: 'array', minItems: 1, maxItems: 40,
        items: {
          type: 'object', required: ['sku', 'qty'], additionalProperties: false,
          properties: {
            sku: { type: 'string', minLength: 1, maxLength: 64 },
            qty: { type: 'integer', minimum: 1, maximum: 50 },
            note: { type: 'string', maxLength: 200 }
          }
        }
      }
    }
  }
};

const statusSchema = {
  params: uuidParams,
  body: { type: 'object', required: ['status'], additionalProperties: false, properties: { status: { enum: ['preparing', 'ready', 'served'] } } }
};

async function audit(client, userId, type, subjectType, subjectId, metadata = {}) {
  await client.query(
    `INSERT INTO audit_events (actor_user_id, event_type, subject_type, subject_id, metadata)
     VALUES ($1::uuid, $2, $3, $4::text, $5::jsonb)`,
    [userId, type, subjectType, subjectId, JSON.stringify(metadata)]
  );
}

async function inTransaction(pool, work) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await work(client);
    await client.query(result?.rollback ? 'ROLLBACK' : 'COMMIT');
    return result.value;
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

export function registerOrderRoutes(app, { pool, config }) {
  const auth = authenticate(pool, config);
  const noStore = (reply) => reply.header('Cache-Control', 'no-store');

  app.get('/api/v1/products', { preHandler: auth }, async (_request, reply) => {
    noStore(reply);
    const { rows } = await pool.query(
      'SELECT sku, name, category, price_cents, station FROM products WHERE active ORDER BY category, name'
    );
    return { products: rows };
  });

  app.get('/api/v1/orders', { preHandler: auth }, async (_request, reply) => {
    noStore(reply);
    const { rows } = await pool.query(
      `SELECT o.id, o.table_label, o.status, o.created_at,
              COALESCE(json_agg(json_build_object('id', i.id, 'name', i.name_snapshot, 'qty', i.qty, 'note', i.note,
                'station', i.station, 'status', i.status, 'price_cents', i.price_cents_snapshot)
                ORDER BY i.created_at, i.id) FILTER (WHERE i.id IS NOT NULL), '[]') AS items
       FROM orders o LEFT JOIN order_items i ON i.order_id = o.id
       WHERE o.status = 'open' GROUP BY o.id ORDER BY o.created_at LIMIT 100`
    );
    return { orders: rows.map((o) => ({ ...o, total_cents: orderTotalCents(o.items) })) };
  });

  app.post('/api/v1/orders', {
    schema: createSchema,
    preHandler: [auth, requireRoles('waiter', 'cashier', 'manager', 'admin')]
  }, async (request, reply) => {
    const { table, items } = request.body;
    const skus = [...new Set(items.map((i) => i.sku))];
    const out = await inTransaction(pool, async (client) => {
      const found = await client.query(
        'SELECT id, sku, name, price_cents, station FROM products WHERE active AND sku = ANY($1::text[])', [skus]
      );
      if (found.rows.length !== skus.length) return { rollback: true, value: null };
      const bySku = new Map(found.rows.map((p) => [p.sku, p]));
      const order = (await client.query(
        'INSERT INTO orders (table_label, created_by) VALUES ($1, $2) RETURNING id, table_label, status, created_at',
        [table.trim(), request.authUser.id]
      )).rows[0];
      for (const it of items) {
        const p = bySku.get(it.sku);
        await client.query(
          `INSERT INTO order_items (order_id, product_id, name_snapshot, price_cents_snapshot, qty, note, station)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [order.id, p.id, p.name, p.price_cents, it.qty, it.note?.trim() || null, p.station]
        );
      }
      await audit(client, request.authUser.id, 'order.created', 'order', order.id, { items: items.length });
      return { value: order };
    });
    if (!out) return reply.code(422).send({ error: 'Producto inexistente o inactivo' });
    return reply.code(201).send({ order: out });
  });

  app.patch('/api/v1/order-items/:id/status', { schema: statusSchema, preHandler: auth }, async (request, reply) => {
    const { status } = request.body;
    const result = await inTransaction(pool, async (client) => {
      const row = (await client.query(
        `SELECT i.id, i.status, i.station FROM order_items i JOIN orders o ON o.id = i.order_id
         WHERE i.id = $1 AND o.status = 'open' FOR UPDATE OF i`, [request.params.id]
      )).rows[0];
      if (!row) return { value: { code: 404, error: 'Partida no encontrada' } };
      if (!canActOnItem(request.authUser.roles, row.station, status)) return { value: { code: 403, error: 'Permisos insuficientes' } };
      if (!canTransition(row.status, status)) return { value: { code: 409, error: `No se puede pasar de ${row.status} a ${status}` } };
      await client.query('UPDATE order_items SET status = $2, updated_at = now() WHERE id = $1', [row.id, status]);
      await audit(client, request.authUser.id, 'order_item.status', 'order_item', row.id, { from: row.status, to: status });
      return { value: { code: 200, body: { id: row.id, status } } };
    });
    return result.code === 200 ? result.body : reply.code(result.code).send({ error: result.error });
  });

  app.post('/api/v1/orders/:id/close', {
    schema: { params: uuidParams },
    preHandler: [auth, requireRoles('cashier', 'manager', 'admin')]
  }, async (request, reply) => {
    const result = await inTransaction(pool, async (client) => {
      const order = (await client.query("SELECT id FROM orders WHERE id = $1 AND status = 'open' FOR UPDATE", [request.params.id])).rows[0];
      if (!order) return { value: { code: 404, error: 'Orden no encontrada o ya cerrada' } };
      const items = (await client.query(
        'SELECT qty, price_cents_snapshot AS price_cents, status FROM order_items WHERE order_id = $1', [order.id]
      )).rows;
      if (items.some((i) => i.status !== 'served')) return { value: { code: 409, error: 'Hay productos sin servir' } };
      const total = orderTotalCents(items);
      await client.query("UPDATE orders SET status = 'closed', closed_at = now() WHERE id = $1", [order.id]);
      await audit(client, request.authUser.id, 'order.closed', 'order', order.id, { total_cents: total });
      return { value: { code: 200, body: { id: order.id, status: 'closed', total_cents: total } } };
    });
    return result.code === 200 ? result.body : reply.code(result.code).send({ error: result.error });
  });
}
