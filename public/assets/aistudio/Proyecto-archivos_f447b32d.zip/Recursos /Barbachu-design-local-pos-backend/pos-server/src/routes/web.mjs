import { readFileSync } from 'node:fs';

const FILES = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/app.css': ['app.css', 'text/css; charset=utf-8'],
  '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json'],
  '/icon-180.png': ['icon-180.png', 'image/png']
};

/** Sirve la app web del POS (PWA instalable en iOS). Los archivos se leen al arrancar: si faltan, falla pronto. */
export function registerWebRoutes(app) {
  for (const [url, [file, type]] of Object.entries(FILES)) {
    const body = readFileSync(new URL(`../../public/${file}`, import.meta.url));
    app.get(url, async (_request, reply) => reply.header('Content-Type', type).header('Cache-Control', 'no-cache').send(body));
  }
}
