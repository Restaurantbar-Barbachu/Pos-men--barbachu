# Barbachu POS Server — fase 1

API privada del POS local con app web (PWA) para iPhone/iPad. Requiere Node.js 24 y PostgreSQL 18. Incluye comandas por mesa, estaciones cocina/barra, servido y cierre de cuenta. No incluye todavía pagos, división de cuenta, cancelaciones, inventario, recetas, impresión ni modo sin conexión (requiere HTTPS). Para probar en iOS ver `docs/pos/IOS.md`.

## Preparación local

1. Copiar `.env.example` a `.env` y sustituir las contraseñas de ejemplo por valores aleatorios URL-safe. No compartir ni subir `.env`.
2. Instalar dependencias con `npm ci` (usa el `package-lock.json` incluido; no uses `npm install` para no cambiar versiones).
3. Iniciar PostgreSQL: `docker compose up -d db`.
4. Aplicar migraciones: `node --env-file=.env scripts/migrate.mjs`.
5. Crear un usuario explícitamente con `node --env-file=.env scripts/create-user.mjs`, definiendo `NEW_USER_USERNAME`, `NEW_USER_DISPLAY_NAME`, `NEW_USER_PASSWORD` (mínimo 12 caracteres) y `NEW_USER_ROLE`. No existe una contraseña predeterminada.
6. Iniciar API: `npm start`.

Con Docker Compose, `docker compose up -d --build` crea el rol restringido, ejecuta migraciones y después inicia la API. PostgreSQL solo se publica en `127.0.0.1:5432` y la API, por defecto, también en `127.0.0.1:3000`. Para que tabletas y teléfonos accedan, define `API_BIND_ADDRESS` en `.env` con la IP LAN del servidor, pero solo con HTTPS delante (`COOKIE_SECURE=true`) y firewall limitado a los dispositivos del restaurante.

## Variables y seguridad

- `DATABASE_URL`: cuenta limitada `barbachu_app` para la API.
- `MIGRATION_DATABASE_URL`: cuenta propietaria, solo para migraciones y altas de usuario.
- `COOKIE_SECURE=false` es solo para desarrollo HTTP local. En producción usar TLS y `COOKIE_SECURE=true`.
- El usuario de ejecución no puede modificar ni borrar eventos de auditoría; además `TRUNCATE` sobre `audit_events` queda bloqueado por trigger (la cuenta propietaria podría quitar el trigger, por eso debe usarse solo para migraciones).
- La API borra al iniciar y cada 6 horas las sesiones vencidas o revocadas hace más de 7 días.
- El límite de intentos de login vive en memoria del proceso: válido para una sola instancia.

## Pruebas

- `npm run test:unit`: pruebas puras sin base de datos.
- `npm run check`: comprobación sintáctica de módulos de aplicación.
- `npm run seed:dev`: datos demo para pruebas locales (nunca en producción).
- `npm test`: incluye las pruebas de integración cuando `TEST_DATABASE_URL` (cuenta `barbachu_app`) y `MIGRATION_DATABASE_URL` (cuenta propietaria) apuntan a PostgreSQL con las migraciones 001 a 003 aplicadas.

Esta versión es una base para revisión. No habilitar ventas reales hasta completar pruebas de integración, TLS, respaldos y piloto físico.
