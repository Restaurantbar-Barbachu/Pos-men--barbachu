import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransition, canActOnItem, orderTotalCents } from '../src/lib/orders-logic.mjs';

test('solo se permiten transiciones hacia adelante, una a la vez', () => {
  assert.equal(canTransition('pending', 'preparing'), true);
  assert.equal(canTransition('preparing', 'ready'), true);
  assert.equal(canTransition('ready', 'served'), true);
  for (const [a, b] of [['pending', 'ready'], ['pending', 'served'], ['served', 'pending'], ['ready', 'preparing'], ['x', 'ready']]) {
    assert.equal(canTransition(a, b), false, `${a}→${b}`);
  }
});

test('cada rol solo actúa donde le corresponde', () => {
  assert.equal(canActOnItem(['kitchen'], 'kitchen', 'preparing'), true);
  assert.equal(canActOnItem(['kitchen'], 'bar', 'preparing'), false);
  assert.equal(canActOnItem(['bar'], 'bar', 'ready'), true);
  assert.equal(canActOnItem(['kitchen'], 'kitchen', 'served'), false);
  assert.equal(canActOnItem(['waiter'], 'kitchen', 'served'), true);
  assert.equal(canActOnItem(['waiter'], 'kitchen', 'preparing'), false);
  assert.equal(canActOnItem(['manager'], 'bar', 'ready'), true);
  assert.equal(canActOnItem(undefined, 'bar', 'ready'), false);
});

test('el total suma precio por cantidad en centavos enteros', () => {
  assert.equal(orderTotalCents([{ price_cents: 6500, qty: 2 }, { price_cents: 2000, qty: 1 }]), 15000);
  assert.equal(orderTotalCents([]), 0);
});
