import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

// Requiere PostgreSQL con migraciones 001-003 aplicadas.
test('flujo completo: comanda → cocina → servido → cobro, con permisos por rol', {
  skip: !process.env.TEST_DATABASE_URL || !process.env.MIGRATION_DATABASE_URL
}, async () => {
  const [pgModule, argon2Module, { buildApp }] = await Promise.all([import('pg'), import('argon2'), import('../src/app.mjs')]);
  const { Pool } = pgModule.default ?? pgModule;
  const argon2 = argon2Module.default ?? argon2Module;
  const pool = new Pool({ connectionString: process.env.TEST_DATABASE_URL });
  const owner = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL });
  const tag = randomUUID().replaceAll('-', '').slice(0, 8);
  const password = 'Prueba-Segura-2026!';
  const hash = await argon2.hash(password, { type: argon2.argon2id, memoryCost: 19_456, timeCost: 2, parallelism: 1 });
  const config = { cookieName: 'barbachu_session', cookieSecure: false, sessionTtlHours: 12, trustProxy: false, nodeEnv: 'test' };
  const userIds = [];
  const sku = `T-${tag}`;
  let app; let orderId;

  try {
    const mk = async (role) => {
      const username = `t${tag}_${role}`;
      const id = (await owner.query('INSERT INTO users (username, display_name, password_hash) VALUES ($1, $2, $3) RETURNING id', [username, role, hash])).rows[0].id;
      await owner.query('INSERT INTO user_roles (user_id, role_id) SELECT $1, id FROM roles WHERE name = $2', [id, role]);
      userIds.push(id);
      return username;
    };
    const names = { waiter: await mk('waiter'), kitchen: await mk('kitchen'), bar: await mk('bar'), cashier: await mk('cashier') };
    await owner.query("INSERT INTO products (sku, name, category, price_cents, station) VALUES ($1, 'Tostada prueba', 'Prueba', 6500, 'kitchen')", [sku]);
    app = buildApp({ pool, config });
    const login = async (role) => {
      const r = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: names[role], password } });
      assert.equal(r.statusCode, 200, `login ${role}`);
      return { cookie: r.headers['set-cookie'].split(';')[0] };
    };
    const [waiter, kitchen, bar, cashier] = await Promise.all(['waiter', 'kitchen', 'bar', 'cashier'].map(login));
    const call = (who, method, url, payload) => app.inject({ method, url, payload, headers: { cookie: who.cookie } });

    assert.equal((await app.inject({ method: 'GET', url: '/api/v1/orders' })).statusCode, 401);
    assert.equal((await call(kitchen, 'POST', '/api/v1/orders', { table: '9', items: [{ sku, qty: 1 }] })).statusCode, 403);
    assert.equal((await call(waiter, 'POST', '/api/v1/orders', { table: '9', items: [{ sku: 'NO-EXISTE', qty: 1 }] })).statusCode, 422);
    assert.equal((await call(waiter, 'POST', '/api/v1/orders', { table: '9', items: [{ sku, qty: 0 }] })).statusCode, 400);

    const created = await call(waiter, 'POST', '/api/v1/orders', { table: `M${tag.slice(0, 4)}`, items: [{ sku, qty: 2, note: 'sin cebolla' }] });
    assert.equal(created.statusCode, 201);
    orderId = created.json().order.id;
    const listed = (await call(waiter, 'GET', '/api/v1/orders')).json().orders.find((o) => o.id === orderId);
    assert.equal(listed.total_cents, 13000);
    const item = listed.items[0];

    assert.equal((await call(bar, 'PATCH', `/api/v1/order-items/${item.id}/status`, { status: 'preparing' })).statusCode, 403);
    assert.equal((await call(kitchen, 'PATCH', `/api/v1/order-items/${item.id}/status`, { status: 'ready' })).statusCode, 409);
    assert.equal((await call(kitchen, 'PATCH', `/api/v1/order-items/${item.id}/status`, { status: 'preparing' })).statusCode, 200);
    assert.equal((await call(cashier, 'POST', `/api/v1/orders/${orderId}/close`)).statusCode, 409);
    assert.equal((await call(kitchen, 'PATCH', `/api/v1/order-items/${item.id}/status`, { status: 'ready' })).statusCode, 200);
    assert.equal((await call(waiter, 'PATCH', `/api/v1/order-items/${item.id}/status`, { status: 'served' })).statusCode, 200);
    assert.equal((await call(waiter, 'POST', `/api/v1/orders/${orderId}/close`)).statusCode, 403);
    const closed = await call(cashier, 'POST', `/api/v1/orders/${orderId}/close`);
    assert.equal(closed.statusCode, 200);
    assert.equal(closed.json().total_cents, 13000);
    assert.equal((await call(cashier, 'POST', `/api/v1/orders/${orderId}/close`)).statusCode, 404);

    const web = await app.inject({ method: 'GET', url: '/' });
    assert.equal(web.statusCode, 200);
    assert.doesNotMatch(web.headers['content-security-policy'], /upgrade-insecure-requests/);
  } finally {
    if (app) await app.close();
    await owner.query('UPDATE sessions SET revoked_at = now() WHERE user_id = ANY($1::uuid[]) AND revoked_at IS NULL', [userIds]);
    if (orderId) await owner.query('DELETE FROM order_items WHERE order_id = $1', [orderId]).then(() => owner.query('DELETE FROM orders WHERE id = $1', [orderId]));
    await owner.query('DELETE FROM products WHERE sku = $1', [sku]);
    if (userIds.length) await owner.query('UPDATE users SET disabled_at = now() WHERE id = ANY($1::uuid[])', [userIds]);
    await pool.end(); await owner.end();
  }
});
