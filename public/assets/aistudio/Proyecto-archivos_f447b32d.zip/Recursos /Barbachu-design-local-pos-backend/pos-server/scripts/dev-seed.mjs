import { randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import pg from 'pg';
import argon2 from 'argon2';

// Solo para pruebas locales (por ejemplo, desde un iPhone en la misma red). Nunca en producción.
if (process.env.NODE_ENV === 'production') { console.error('dev-seed no se ejecuta con NODE_ENV=production'); process.exit(1); }
if (!process.env.MIGRATION_DATABASE_URL) { console.error('Falta MIGRATION_DATABASE_URL'); process.exit(1); }

const USERS = [
  ['demo_mesero', 'Mesero Demo', 'waiter'], ['demo_cocina', 'Cocina Demo', 'kitchen'],
  ['demo_barra', 'Barra Demo', 'bar'], ['demo_caja', 'Caja Demo', 'cashier'], ['demo_admin', 'Admin Demo', 'admin']
];
const BAR = new Set(['DEMO-PROD-02']);
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL });

try {
  const catalog = JSON.parse(await readFile(new URL('../../pos-demo/data/demo-catalog.json', import.meta.url), 'utf8'));
  for (const p of catalog.products) {
    await pool.query(
      `INSERT INTO products (sku, name, category, price_cents, station) VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (sku) DO NOTHING`,
      [p.id, p.name, p.category, p.priceCents, BAR.has(p.id) ? 'bar' : 'kitchen']
    );
  }
  console.log(`Productos demo: ${catalog.products.length}`);
  for (const [username, displayName, role] of USERS) {
    const exists = await pool.query('SELECT 1 FROM users WHERE username = $1', [username]);
    if (exists.rowCount) { console.log(`${username}: ya existe (sin cambios)`); continue; }
    const password = randomBytes(12).toString('base64url');
    const hash = await argon2.hash(password, { type: argon2.argon2id, memoryCost: 19_456, timeCost: 2, parallelism: 1 });
    const { rows } = await pool.query('INSERT INTO users (username, display_name, password_hash) VALUES ($1, $2, $3) RETURNING id', [username, displayName, hash]);
    await pool.query('INSERT INTO user_roles (user_id, role_id) SELECT $1, id FROM roles WHERE name = $2', [rows[0].id, role]);
    console.log(`${username} (${role}) contraseña: ${password}`);
  }
  console.log('Guarda las contraseñas ahora: no se vuelven a mostrar.');
} catch (error) {
  console.error('Fallo en dev-seed:', error.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
