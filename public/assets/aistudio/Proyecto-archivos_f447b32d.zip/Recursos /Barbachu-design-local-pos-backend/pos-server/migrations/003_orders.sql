-- Comandas: productos, órdenes y partidas por estación (cocina/barra). Sin DELETE para el rol de ejecución.
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sku TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'General',
  price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
  station TEXT NOT NULL CHECK (station IN ('kitchen', 'bar')),
  active BOOLEAN NOT NULL DEFAULT true,
  CONSTRAINT products_sku_length CHECK (char_length(sku) BETWEEN 1 AND 64),
  CONSTRAINT products_name_length CHECK (char_length(name) BETWEEN 1 AND 120)
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_label TEXT NOT NULL CHECK (char_length(table_label) BETWEEN 1 AND 20),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'cancelled')),
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  name_snapshot TEXT NOT NULL,
  price_cents_snapshot INTEGER NOT NULL CHECK (price_cents_snapshot >= 0),
  qty INTEGER NOT NULL CHECK (qty BETWEEN 1 AND 50),
  note TEXT CHECK (note IS NULL OR char_length(note) <= 200),
  station TEXT NOT NULL CHECK (station IN ('kitchen', 'bar')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'preparing', 'ready', 'served')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS orders_open_idx ON orders (created_at) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items (order_id);

GRANT SELECT ON products TO barbachu_app;
GRANT SELECT, INSERT ON orders, order_items TO barbachu_app;
GRANT UPDATE (status, closed_at) ON orders TO barbachu_app;
GRANT UPDATE (status, updated_at) ON order_items TO barbachu_app;
