# Probar el POS en iPhone / iPad

## Opción A — Demo sin servidor (1 minuto)
Abre en Safari el enlace de la demo interactiva (`Barbachu_POS_Demo_Interactiva.html` publicada como artefacto). No necesita red local ni base de datos; los datos de prueba no se guardan en ningún servidor.

## Opción B — App real con comandas (servidor en tu red)
Requiere Node.js 24 y Docker en la computadora que hará de servidor.

1. `cd pos-server && cp .env.example .env` y reemplaza las contraseñas de ejemplo por valores aleatorios.
2. `npm ci`
3. `docker compose up -d db`
4. `node --env-file=.env scripts/migrate.mjs`
5. `npm run seed:dev` (crea 3 productos demo y 5 usuarios `demo_*`; **anota las contraseñas**, solo se muestran una vez).
6. `npm start` (escucha en `0.0.0.0:3000` con `COOKIE_SECURE=false`).
7. Averigua la IP de esa computadora (`ipconfig` en Windows, `ifconfig` en Mac/Linux). Permite el puerto 3000 en el firewall.
8. En el iPhone, conectado a la **misma red Wi-Fi**, abre Safari en `http://IP-DEL-SERVIDOR:3000`.
9. Compartir → **Añadir a pantalla de inicio** para usarla como app a pantalla completa.

### Qué probar (necesitas 2 dispositivos o cerrar/abrir sesión)
- `demo_mesero`: pestaña Comanda → mesa + productos → Enviar.
- `demo_cocina` / `demo_barra`: pestaña Estación → Preparar → Listo (cada rol solo ve su estación).
- `demo_mesero`: pestaña Mesas → Servido.
- `demo_caja`: pestaña Mesas → Cobrar y cerrar (solo habilitado cuando todo está servido).

### Limitaciones conocidas
- Por HTTP, iOS no permite service worker: no hay modo sin conexión. Eso requiere HTTPS (fase siguiente).
- Si la red tiene aislamiento de clientes (típico en Wi-Fi de invitados), el iPhone no verá al servidor: usa la red del personal.
- `seed:dev` es solo para pruebas y se niega a correr con `NODE_ENV=production`.
