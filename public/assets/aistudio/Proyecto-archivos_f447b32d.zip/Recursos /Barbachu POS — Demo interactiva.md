**BARBACHU**RESTAURANTE · POS DEMO

Demo local activa

Datos ficticios · Sin conexión al servidor

Barbachu POS · Vista de concepto

BARBACHU / SISTEMA DE OPERACIÓN

# Resumen general

● MODO DEMOSTRACIÓN

AD

Esta es una simulación interactiva. Los importes, órdenes y existencias son ficticios; no representan ventas reales.

Ventas de hoy

$4,850.00

Ejemplo de jornada

Órdenes abiertas

4

Mesas con consumo

Mesas ocupadas

4 / 10

Ocupación simulada

Pendientes en cocina

3

Órdenes de demostración

## Actividad reciente

Movimientos ficticios de ejemplo

En vivo · demo

## Accesos rápidos

Prueba los principales flujos

## Estado operativo

Resumen de módulos incluidos en el concepto final

Catálogo de origen

199

Productos importados

Insumos de origen

121

Pendientes de recetas

Usuarios de ejemplo

4

Administrador, caja, mesero y cocina

Servidor

No conectado

Se implementará después de aprobar el plan

Los productos se cargan desde el catálogo SoftRestaurant incluido en el paquete. Los artículos con precio cero no se ofrecen para venta.

## Catálogo

Productos disponibles

Catálogo de origen

## Nueva cuenta

Comanda de demostración

Sin cobrar

Mesa Mesero

Selecciona productos del catálogo.

Total$0.00

Selecciona una mesa para preparar una cuenta. Las ocupaciones son ficticias y se pueden modificar en esta sesión.

## Salón · 10 mesas

Verde: libre · Dorado: ocupada

Vista de cocina/barra. Avanza cada ticket para simular el flujo de preparación y entrega.

### ● RECIBIDA

### ● PREPARANDO

### ● LISTA / ENTREGADA

Caja de demostración: no procesa pagos bancarios ni genera comprobantes fiscales.

Fondo inicial

$1,000.00

Ejemplo

Ventas en efectivo

$2,850.00

Simulación de turno

Ventas con tarjeta

$2,000.00

Dato ficticio

Total esperado

$5,850.00

Incluye fondo inicial

## Simular cobro

Selecciona una orden pendiente de esta demostración

## Movimientos del turno

| Hora | Concepto | Método | Importe | Estado |
| --- | --- | --- | --- | --- |

Se muestran insumos importados como referencia. No se descuentan existencias: faltan recetas, unidades, rendimientos y existencias iniciales validadas.

Insumos de origen

121

Registros importados

Costos en cero

94

Requieren revisión

Recetas aprobadas

0

No activar descuentos todavía

Alertas reales

—

Sin existencias iniciales

## Control de inventario

Ejemplos visuales; cantidades no representan existencias reales

| Insumo de ejemplo | Unidad | Existencia demo | Estado |
| --- | --- | --- | --- |

Administración de demostración: los cambios se guardan solo en este navegador, no en un servidor.

Reporte ilustrativo con cifras ficticias. En el sistema terminado se calculará desde las ventas registradas en el servidor.

## Ventas por día

Semana de ejemplo

## Distribución de pagos

Datos ficticios

$4,850

Venta de ejemplo

Efectivo**58.8%**

Tarjeta**41.2%**

## Exportación de demostración

Descarga órdenes generadas durante esta sesión

## Confirmación