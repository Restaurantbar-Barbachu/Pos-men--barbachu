# Criterios de aceptación — Backend base

| Criterio | Estado de esta entrega |
|---|---|
| Servicio Fastify 5 y Node.js 24 fijados | Implementado en archivos locales; runtime local no es Node 24 |
| PostgreSQL 18 y migración inicial | Definidos; no ejecutados porque no hay servidor PostgreSQL/Docker local |
| Usuarios y roles sin usuario por defecto | Implementado en migración/script |
| Hash de contraseña Argon2id | Implementado; instalación/ejecución pendiente |
| Sesiones con token aleatorio y hash persistido | Implementado y probado en módulo puro |
| Cookie HttpOnly/SameSite y Secure en producción | Implementado; prueba de navegador pendiente |
| Rate limit del login | Configurado; integración pendiente de dependencias |
| Autorización por rol en servidor | Implementada en ruta de control; prueba de integración pendiente |
| Auditoría append-only | Definida en SQL; no ejecutada localmente |
| PostgreSQL solo en loopback | Configurado en Compose; no probado con Docker |
| CI Node 24/PostgreSQL 18 | Workflow creado localmente; no ejecutado en GitHub |
| Cambios integrados en rama remota | Bloqueado por HTTP 403 |
| Merge/deploy/ventas reales | No autorizado ni realizado |


## Evidencia local disponible

- Tests backend ejecutados: 11 aprobados, 0 fallidos, 1 integración omitida por falta de PostgreSQL/dependencias.
- Sintaxis JavaScript y shell: aprobada.
- YAML de GitHub Actions y Docker Compose: parseado correctamente.
- Auditoría de catálogo del ZIP fuente: 4 pruebas aprobadas; 199 productos, 121 insumos y 40 precios cero/negativos preservados.
