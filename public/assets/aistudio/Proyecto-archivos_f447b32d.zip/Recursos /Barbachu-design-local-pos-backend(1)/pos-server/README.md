# Barbachu POS Server — fase 1

API privada de base para el POS local. Requiere Node.js 24 y PostgreSQL 18. No incluye todavía ventas, comandas, caja, cocina, inventario, pagos ni PWA.

## Preparación local

1. Copiar `.env.example` a `.env` y sustituir las contraseñas de ejemplo por valores aleatorios URL-safe. No compartir ni subir `.env`.
2. Instalar dependencias: `npm install`. Revisar y conservar el `package-lock.json` que se genera.
3. Iniciar PostgreSQL: `docker compose up -d db`.
4. Aplicar migraciones: `node --env-file=.env scripts/migrate.mjs`.
5. Crear un usuario explícitamente con `node --env-file=.env scripts/create-user.mjs`, definiendo `NEW_USER_USERNAME`, `NEW_USER_DISPLAY_NAME`, `NEW_USER_PASSWORD` (mínimo 12 caracteres) y `NEW_USER_ROLE`. No existe una contraseña predeterminada.
6. Iniciar API: `npm start`.

Con Docker Compose, `docker compose up -d --build` crea el rol restringido, ejecuta migraciones y después inicia la API. PostgreSQL solo se publica en `127.0.0.1:5432`; la API se publica en el puerto 3000 de la LAN. Configurar firewall para aceptar solo dispositivos de la red del restaurante.

## Variables y seguridad

- `DATABASE_URL`: cuenta limitada `barbachu_app` para la API.
- `MIGRATION_DATABASE_URL`: cuenta propietaria, solo para migraciones y altas de usuario.
- `COOKIE_SECURE=false` es solo para desarrollo HTTP local. En producción usar TLS y `COOKIE_SECURE=true`.
- El usuario de ejecución no puede modificar ni borrar eventos de auditoría.

## Pruebas

- `npm run test:unit`: pruebas puras sin base de datos.
- `npm run check`: comprobación sintáctica de módulos de aplicación.
- `npm test`: incluye prueba de integración cuando `TEST_DATABASE_URL` apunta a PostgreSQL con migración aplicada.

Esta versión es una base para revisión. No habilitar ventas reales hasta completar pruebas de integración, TLS, respaldos y piloto físico.
