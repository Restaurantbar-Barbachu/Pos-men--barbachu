#!/bin/sh
set -eu
# Crea una cuenta de ejecución distinta del propietario de la base de datos.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  --set=app_password="$APP_DB_PASSWORD" <<'SQL'
CREATE ROLE barbachu_app LOGIN PASSWORD :'app_password';
SQL
