import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const sql = await readFile(new URL('../migrations/001_initial_schema.sql', import.meta.url), 'utf8');

test('initial schema defines users, roles, sessions and immutable audit events', () => {
  for (const table of ['users', 'roles', 'user_roles', 'sessions', 'audit_events']) {
    assert.match(sql, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`, 'i'));
  }
  assert.match(sql, /password_hash/);
  assert.match(sql, /token_hash/);
  assert.match(sql, /expires_at/);
  assert.match(sql, /ON DELETE RESTRICT/i);
});

test('schema seeds only role definitions and does not create default users', () => {
  assert.match(sql, /INSERT INTO roles/i);
  assert.doesNotMatch(sql, /INSERT INTO users/i);
});
