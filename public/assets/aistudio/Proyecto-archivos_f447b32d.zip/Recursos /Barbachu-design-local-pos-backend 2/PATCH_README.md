# Integración local — POS Barbachu, Fases 0 y 1

Este archivo documenta la integración del paquete de backend base en el ZIP completo recibido del usuario el 2026-11-01. El ZIP resultante contiene el repositorio recibido más los archivos de las Fases 0 y 1.

- Repositorio previsto: `Restaurantbar-Barbachu/Barbachu`
- Rama de trabajo prevista: `design/local-pos-backend`
- Commit base remoto observado previamente: `48b0ef9262922762b393ae4b65a9085f5e7b035f`

El ZIP recibido no contiene metadatos `.git`; por tanto, no permite verificar el HEAD local ni confirmar que el contenido recibido corresponda exactamente al commit base. No se realizó ninguna escritura en GitHub, commit remoto, merge a `main` ni despliegue.

## Integración realizada

- Se incorporó `pos-server/` con API Fastify, configuración, autenticación/sesiones, migración inicial, roles, permisos, auditoría, scripts y pruebas.
- Se añadió `.github/workflows/pos-server-ci.yml` para validación con Node.js 24 y PostgreSQL 18.
- Se añadieron `docs/pos/` con especificación, plan, criterios de aceptación, catálogo y estado.
- Se actualizaron `README.md` y `pos-demo/README.md` para aclarar la separación entre menú público, demo sintética y backend local.
- Se conservaron sin cambios `index.html`, `og-image.png`, `pos-demo/index.html` y `pos-demo/data/demo-catalog.json`.

## Pasos antes de usar el backend

1. Comparar este snapshot con la rama remota `design/local-pos-backend` y reconciliar cualquier cambio que haya ocurrido después del ZIP recibido.
2. Usar Node.js 24 y revisar el `package-lock.json` ya incluido en `pos-server/` (instalar con `npm ci`).
3. Ejecutar PostgreSQL 18 y Docker Compose; aplicar migraciones y ejecutar pruebas de integración.
4. Revisar el diff completo y los resultados de CI.
5. Mantener prohibido el merge a `main`, el despliegue y la operación con ventas reales hasta una aprobación separada.

No incluir `.env` real ni credenciales en el repositorio.
