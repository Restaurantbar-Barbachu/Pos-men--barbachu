import pg from 'pg';
import argon2 from 'argon2';

const username = process.env.NEW_USER_USERNAME?.trim();
const displayName = process.env.NEW_USER_DISPLAY_NAME?.trim();
const password = process.env.NEW_USER_PASSWORD;
const role = process.env.NEW_USER_ROLE;
const allowedRoles = new Set(['admin', 'manager', 'cashier', 'waiter', 'kitchen', 'bar']);

if (!process.env.MIGRATION_DATABASE_URL) throw new Error('MIGRATION_DATABASE_URL es obligatorio para alta administrativa');
if (!username || username.length < 3 || username.length > 64) throw new Error('NEW_USER_USERNAME debe tener entre 3 y 64 caracteres');
if (!displayName || displayName.length > 120) throw new Error('NEW_USER_DISPLAY_NAME es obligatorio (máximo 120 caracteres)');
if (!password || password.length < 12 || password.length > 256) throw new Error('NEW_USER_PASSWORD debe tener entre 12 y 256 caracteres');
if (!allowedRoles.has(role)) throw new Error(`NEW_USER_ROLE debe ser uno de: ${[...allowedRoles].join(', ')}`);

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL, max: 1 });
const passwordHash = await argon2.hash(password, {
  type: argon2.argon2id,
  memoryCost: 19_456,
  timeCost: 2,
  parallelism: 1
});

try {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const user = await client.query(
      `INSERT INTO users (username, display_name, password_hash)
       VALUES ($1, $2, $3) RETURNING id`,
      [username, displayName, passwordHash]
    );
    const assignment = await client.query(
      `INSERT INTO user_roles (user_id, role_id)
       SELECT $1, id FROM roles WHERE name = $2`,
      [user.rows[0].id, role]
    );
    if (assignment.rowCount !== 1) throw new Error(`El rol ${role} no existe en la base de datos`);
    await client.query(
      `INSERT INTO audit_events (event_type, subject_type, subject_id, metadata)
       VALUES ('user.created', 'user', $1, jsonb_build_object('username', $2, 'role', $3))`,
      [user.rows[0].id, username, role]
    );
    await client.query('COMMIT');
    process.stdout.write(`Usuario creado: ${username} (${role})\n`);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
} finally {
  await pool.end();
}
