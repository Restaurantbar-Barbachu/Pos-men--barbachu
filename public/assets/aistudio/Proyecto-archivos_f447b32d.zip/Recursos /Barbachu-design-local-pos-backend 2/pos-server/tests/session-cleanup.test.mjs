import test from 'node:test';
import assert from 'node:assert/strict';
import { purgeStaleSessions, startSessionCleanup } from '../src/lib/session-cleanup.mjs';

test('purgeStaleSessions borra solo por fechas parametrizadas y devuelve el conteo', async () => {
  const calls = [];
  const pool = { query: async (sql, params) => { calls.push({ sql, params }); return { rowCount: 3 }; } };
  assert.equal(await purgeStaleSessions(pool, { retainDays: 14 }), 3);
  assert.deepEqual(calls[0].params, [14]);
  assert.match(calls[0].sql, /DELETE FROM sessions/);
  assert.match(calls[0].sql, /expires_at < now\(\)/);
  assert.match(calls[0].sql, /revoked_at < now\(\)/);
});

test('purgeStaleSessions rechaza retainDays inválido sin tocar la base', async () => {
  const pool = { query: async () => { throw new Error('no debe llamarse'); } };
  for (const bad of [0, -1, 1.5, 366, '7']) {
    await assert.rejects(() => purgeStaleSessions(pool, { retainDays: bad }), /retainDays/);
  }
});

test('startSessionCleanup limpia al arrancar, tolera errores y se puede detener', async () => {
  const logs = [];
  const log = { info: (...a) => logs.push(['info', ...a]), error: (...a) => logs.push(['error', ...a]) };
  let n = 0;
  const pool = { query: async () => { n += 1; if (n === 1) return { rowCount: 2 }; throw new Error('db caída'); } };
  const stop = startSessionCleanup(pool, log, { intervalMs: 1000 });
  await new Promise((resolve) => setTimeout(resolve, 20));
  stop();
  assert.equal(n, 1);
  assert.equal(logs[0][0], 'info');
  assert.throws(() => startSessionCleanup(pool, log, { intervalMs: 5 }), /intervalMs/);
});
