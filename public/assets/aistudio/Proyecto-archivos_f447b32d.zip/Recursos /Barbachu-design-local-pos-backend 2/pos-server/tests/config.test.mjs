import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config.mjs';

test('configuration requires a database URL', () => {
  assert.throws(() => loadConfig({}), /DATABASE_URL/);
});

test('configuration uses safe defaults and parses booleans and integers', () => {
  const config = loadConfig({ DATABASE_URL: 'postgres://pos:pass@localhost:5432/barbachu' });
  assert.equal(config.host, '0.0.0.0');
  assert.equal(config.port, 3000);
  assert.equal(config.cookieSecure, false);
  assert.equal(config.sessionTtlHours, 12);
  assert.equal(config.trustProxy, false);
});

test('configuration rejects invalid ports, cookie names and insecure production cookies', () => {
  assert.throws(() => loadConfig({ DATABASE_URL: 'postgres://x', PORT: '70000' }), /PORT/);
  assert.throws(() => loadConfig({ DATABASE_URL: 'postgres://x', NODE_ENV: 'production', COOKIE_SECURE: 'false' }), /COOKIE_SECURE/);
  const unsafeCookieName = `bad;${String.fromCharCode(13, 10)}Set-Cookie`;
  assert.throws(() => loadConfig({ DATABASE_URL: 'postgres://x', SESSION_COOKIE_NAME: unsafeCookieName }), /SESSION_COOKIE_NAME/);
  assert.equal(loadConfig({ DATABASE_URL: 'postgres://x', NODE_ENV: 'production' }).cookieSecure, true);
});
