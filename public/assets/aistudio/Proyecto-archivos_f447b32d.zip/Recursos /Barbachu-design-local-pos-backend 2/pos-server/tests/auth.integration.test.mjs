import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

// Requiere PostgreSQL con migraciones aplicadas. CI lo proporciona como servicio.
test('login, sesión, autorización por rol y cierre de sesión funcionan en conjunto', {
  skip: !process.env.TEST_DATABASE_URL
}, async () => {
  const [pgModule, argon2Module, { buildApp }] = await Promise.all([
    import('pg'), import('argon2'), import('../src/app.mjs')
  ]);
  const { Pool } = pgModule.default ?? pgModule;
  const argon2 = argon2Module.default ?? argon2Module;
  const pool = new Pool({ connectionString: process.env.TEST_DATABASE_URL });
  const ownerPool = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL });
  const username = `test_${randomUUID().replaceAll('-', '').slice(0, 12)}`;
  const password = 'Prueba-Segura-2026!';
  const passwordHash = await argon2.hash(password, { type: argon2.argon2id, memoryCost: 19_456, timeCost: 2, parallelism: 1 });
  const config = {
    cookieName: 'barbachu_session', cookieSecure: false, sessionTtlHours: 12, trustProxy: false
  };
  let app;
  let userId;

  try {
    const inserted = await ownerPool.query(
      'INSERT INTO users (username, display_name, password_hash) VALUES ($1, $2, $3) RETURNING id',
      [username, 'Usuario de prueba', passwordHash]
    );
    userId = inserted.rows[0].id;
    await ownerPool.query(
      `INSERT INTO user_roles (user_id, role_id) SELECT $1, id FROM roles WHERE name = 'cashier'`,
      [userId]
    );

    app = buildApp({ pool, config });
    const invalidLogin = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username, password: 'incorrecta' } });
    assert.equal(invalidLogin.statusCode, 401);
    assert.equal(invalidLogin.json().error, 'Credenciales inválidas');

    const login = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username, password } });
    assert.equal(login.statusCode, 200);
    assert.equal(login.headers['x-content-type-options'], 'nosniff');
    assert.equal(login.headers['cache-control'], 'no-store');
    assert.equal(login.json().user.username, username);
    assert.deepEqual(login.json().user.roles, ['cashier']);
    assert.equal(Object.hasOwn(login.json().user, 'password_hash'), false);

    const cookie = login.headers['set-cookie'].split(';')[0];
    const me = await app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie } });
    assert.equal(me.statusCode, 200);
    assert.equal(me.json().user.id, userId);

    const denied = await app.inject({ method: 'GET', url: '/api/v1/admin/access-check', headers: { cookie } });
    assert.equal(denied.statusCode, 403);

    const logout = await app.inject({ method: 'POST', url: '/api/v1/auth/logout', headers: { cookie } });
    assert.equal(logout.statusCode, 204);
    const afterLogout = await app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie } });
    assert.equal(afterLogout.statusCode, 401);
  } finally {
    if (app) await app.close();
    if (userId) {
      await pool.query('UPDATE sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [userId]);
      // La bitácora es append-only: se conserva el evento de prueba y se desactiva el usuario.
      await ownerPool.query('UPDATE users SET disabled_at = now() WHERE id = $1', [userId]);
    }
    await pool.end();
    await ownerPool.end();
  }
});
