import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

// Requiere PostgreSQL con migraciones 001 y 002 aplicadas (CI lo proporciona).
test('limpieza de sesiones real y auditoría protegida contra DELETE/TRUNCATE', {
  skip: !process.env.TEST_DATABASE_URL || !process.env.MIGRATION_DATABASE_URL
}, async () => {
  const [pgModule, { purgeStaleSessions }] = await Promise.all([import('pg'), import('../src/lib/session-cleanup.mjs')]);
  const { Pool } = pgModule.default ?? pgModule;
  const pool = new Pool({ connectionString: process.env.TEST_DATABASE_URL });
  const owner = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL });
  const username = `hard_${randomUUID().replaceAll('-', '').slice(0, 12)}`;
  let userId;
  try {
    userId = (await owner.query(
      'INSERT INTO users (username, display_name, password_hash) VALUES ($1, $2, $3) RETURNING id',
      [username, 'Prueba hardening', 'x'.repeat(40)]
    )).rows[0].id;
    // Los desplazamientos son días respecto a ahora (negativo = pasado); null = sin revocar.
    const insert = (hash, createdDays, expiresDays, revokedDays) => owner.query(
      `INSERT INTO sessions (user_id, token_hash, created_at, expires_at, revoked_at)
       VALUES ($1, $2, now() + ($3::numeric * interval '1 day'), now() + ($4::numeric * interval '1 day'),
               CASE WHEN $5::numeric IS NULL THEN NULL ELSE now() + ($5::numeric * interval '1 day') END)`,
      [userId, hash, createdDays, expiresDays, revokedDays]
    );
    const h = (c) => c.repeat(64);
    await insert(h('a'), -30, -20, null);  // vencida hace 20 días: se borra
    await insert(h('b'), -30, 1, -10);     // revocada hace 10 días: se borra
    await insert(h('c'), -0.04, 0.46, null); // activa: se conserva
    await insert(h('d'), -3, -2, null);    // vencida hace 2 días: se conserva
    const removed = await purgeStaleSessions(pool, { retainDays: 7 });
    assert.equal(removed >= 2, true);
    const left = (await owner.query('SELECT token_hash FROM sessions WHERE user_id = $1 ORDER BY token_hash', [userId])).rows.map((r) => r.token_hash[0]);
    assert.deepEqual(left, ['c', 'd']);

    await assert.rejects(() => pool.query('DELETE FROM audit_events'), /permission denied/);
    await assert.rejects(() => pool.query('TRUNCATE audit_events'), /permission denied/);
    await assert.rejects(() => owner.query('TRUNCATE audit_events'), /append-only/);
    await assert.rejects(() => owner.query('DELETE FROM audit_events'), /append-only/);
  } finally {
    if (userId) {
      await owner.query('DELETE FROM sessions WHERE user_id = $1', [userId]);
      await owner.query('DELETE FROM users WHERE id = $1', [userId]);
    }
    await pool.end();
    await owner.end();
  }
});
