import test from 'node:test';
import assert from 'node:assert/strict';
import { createSessionToken, expiredSessionCookie, hashSessionToken, parseCookies, safeUser, sessionCookie } from '../src/lib/security.mjs';

test('session token is cryptographically random and stored as a one-way digest', () => {
  const first = createSessionToken();
  const second = createSessionToken();

  assert.equal(typeof first.token, 'string');
  assert.equal(first.token.length, 64);
  assert.notEqual(first.token, second.token);
  assert.equal(first.digest, hashSessionToken(first.token));
  assert.notEqual(first.digest, first.token);
  assert.equal(first.digest.length, 64);
});

test('cookie parser handles multiple cookies and ignores malformed pairs', () => {
  assert.deepEqual({ ...parseCookies('theme=dark; pos_session=abc123; broken; flag=1=2') }, {
    theme: 'dark', pos_session: 'abc123', flag: '1=2'
  });
});

test('cookie parser decodes percent-encoded values without throwing on invalid encoding', () => {
  assert.deepEqual({ ...parseCookies('name=Barbachu%20POS; bad=%E0%A4%A') }, {
    name: 'Barbachu POS', bad: '%E0%A4%A'
  });
});

test('safe user projection never exposes password hashes or internal fields', () => {
  assert.deepEqual(safeUser({
    id: 'u-1', username: 'caja', display_name: 'Caja', password_hash: 'secret',
    disabled_at: null, roles: ['cashier'], internal_flag: true
  }), {
    id: 'u-1', username: 'caja', displayName: 'Caja', roles: ['cashier']
  });
});

test('session cookies are HttpOnly, SameSite strict and Secure when configured', () => {
  const cookie = sessionCookie('opaque-token', { name: 'barbachu_session', secure: true, maxAgeSeconds: 43200 });
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  assert.match(cookie, /Secure/);
  assert.match(cookie, /Max-Age=43200/);
  assert.match(expiredSessionCookie({ name: 'barbachu_session', secure: true }), /Max-Age=0/);
});

test('cookie parser uses a null prototype to avoid prototype pollution', () => {
  const cookies = parseCookies('__proto__=polluted; constructor=unexpected');
  assert.equal(Object.getPrototypeOf(cookies), null);
  assert.equal({}.polluted, undefined);
  assert.equal(cookies.__proto__, 'polluted');
});
