import pg from 'pg';
import { buildApp } from './app.mjs';
import { loadConfig } from './config.mjs';
import { startSessionCleanup } from './lib/session-cleanup.mjs';

// Evita ejecutar accidentalmente con un runtime distinto al fijado por la arquitectura.
if (Number(process.versions.node.split('.')[0]) !== 24) {
  throw new Error(`Este servicio requiere Node.js 24; versión detectada: ${process.versions.node}`);
}

const { Pool } = pg;
const config = loadConfig();
const pool = new Pool({
  connectionString: config.databaseUrl,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  statement_timeout: 10_000,
  application_name: 'barbachu-pos-api'
});

const app = buildApp({ pool, config, logger: true });
app.addHook('onClose', async () => pool.end());

let stopCleanup = () => {};
try {
  await app.listen({ host: config.host, port: config.port });
  stopCleanup = startSessionCleanup(pool, app.log);
} catch (error) {
  app.log.error(error);
  await pool.end();
  process.exitCode = 1;
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, async () => {
    stopCleanup();
    await app.close();
    process.exit(0);
  });
}
