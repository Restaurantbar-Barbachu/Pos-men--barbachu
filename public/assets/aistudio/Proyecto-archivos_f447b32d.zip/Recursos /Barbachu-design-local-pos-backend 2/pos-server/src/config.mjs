/**
 * Lee y valida la configuración de entorno antes de iniciar el servicio.
 * En producción la cookie de sesión debe viajar únicamente por HTTPS.
 */
export function loadConfig(env = process.env) {
  if (!env.DATABASE_URL) throw new Error('DATABASE_URL es obligatorio');

  const port = Number(env.PORT ?? 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT debe ser un entero entre 1 y 65535');
  }

  const sessionTtlHours = Number(env.SESSION_TTL_HOURS ?? 12);
  if (!Number.isInteger(sessionTtlHours) || sessionTtlHours < 1 || sessionTtlHours > 168) {
    throw new Error('SESSION_TTL_HOURS debe estar entre 1 y 168');
  }

  const cookieName = env.SESSION_COOKIE_NAME ?? 'barbachu_session';
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(cookieName)) {
    throw new Error('SESSION_COOKIE_NAME contiene caracteres no permitidos');
  }

  const nodeEnv = env.NODE_ENV ?? 'development';
  const cookieSecure = parseBoolean(env.COOKIE_SECURE, nodeEnv === 'production');
  if (nodeEnv === 'production' && !cookieSecure) {
    throw new Error('COOKIE_SECURE debe ser true en producción');
  }

  return Object.freeze({
    nodeEnv,
    host: env.HOST ?? '0.0.0.0',
    port,
    databaseUrl: env.DATABASE_URL,
    cookieName,
    cookieSecure,
    sessionTtlHours,
    trustProxy: parseBoolean(env.TRUST_PROXY, false)
  });
}

function parseBoolean(value, fallback) {
  if (value === undefined || value === '') return fallback;
  if (value === 'true') return true;
  if (value === 'false') return false;
  throw new Error('Los valores booleanos deben ser true o false');
}
