import Fastify from 'fastify';
import rateLimit from '@fastify/rate-limit';
import helmet from '@fastify/helmet';
import { registerAuthRoutes } from './routes/auth.mjs';

/** Crea la API; las dependencias se inyectan para poder probarla sin globales. */
export function buildApp({ pool, config, logger = false, passwordVerifier } = {}) {
  if (!pool) throw new Error('pool de PostgreSQL es obligatorio');
  if (!config) throw new Error('configuración es obligatoria');

  const app = Fastify({
    logger,
    trustProxy: config.trustProxy,
    bodyLimit: 16 * 1024,
    requestTimeout: 15_000,
    maxRequestsPerSocket: 1000
  });

  app.register(helmet, { hsts: config.nodeEnv === 'production' ? { maxAge: 15_552_000, includeSubDomains: false } : false });
  app.register(rateLimit, { global: false });

  app.get('/health/live', async () => ({ status: 'ok' }));
  app.get('/health/ready', async (_request, reply) => {
    try {
      await pool.query('SELECT 1');
      return { status: 'ready' };
    } catch {
      return reply.code(503).send({ status: 'unavailable' });
    }
  });

  registerAuthRoutes(app, { pool, config, passwordVerifier });

  app.setNotFoundHandler((_request, reply) => reply.code(404).send({ error: 'Ruta no encontrada' }));
  app.setErrorHandler((error, _request, reply) => {
    if (error.validation) return reply.code(400).send({ error: 'Solicitud inválida' });
    app.log.error(error);
    return reply.code(500).send({ error: 'Error interno del servidor' });
  });

  return app;
}
