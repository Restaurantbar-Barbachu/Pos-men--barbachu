import argon2 from 'argon2';
import { createSessionToken, expiredSessionCookie, hashSessionToken, parseCookies, safeUser, sessionCookie } from '../lib/security.mjs';

const loginSchema = {
  body: {
    type: 'object',
    additionalProperties: false,
    required: ['username', 'password'],
    properties: {
      username: { type: 'string', minLength: 3, maxLength: 64 },
      password: { type: 'string', minLength: 1, maxLength: 256 }
    }
  }
};

export function registerAuthRoutes(app, { pool, config, passwordVerifier = argon2.verify }) {
  app.post('/api/v1/auth/login', { schema: loginSchema, config: { rateLimit: { max: 5, timeWindow: '1 minute' } } }, async (request, reply) => {
    reply.header('Cache-Control', 'no-store');
    const username = request.body.username.trim();
    const result = await pool.query(
      `SELECT u.id, u.username, u.display_name, u.password_hash,
              COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL), '{}') AS roles
       FROM users u
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       WHERE lower(u.username) = lower($1) AND u.disabled_at IS NULL
       GROUP BY u.id`,
      [username]
    );

    const user = result.rows[0];
    // Ejecuta un hash Argon2id también cuando el usuario no existe para reducir
    // diferencias de tiempo que faciliten enumerar cuentas.
    const passwordIsValid = user
      ? await passwordVerifier(user.password_hash, request.body.password)
      : (await argon2.hash(request.body.password, { type: argon2.argon2id, memoryCost: 19_456, timeCost: 2, parallelism: 1 }), false);
    if (!user || !passwordIsValid) {
      return reply.code(401).send({ error: 'Credenciales inválidas' });
    }

    const { token, digest } = createSessionToken();
    const maxAgeSeconds = config.sessionTtlHours * 60 * 60;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        'INSERT INTO sessions (user_id, token_hash, expires_at) VALUES ($1, $2, now() + ($3::int * interval \'1 hour\'))',
        [user.id, digest, config.sessionTtlHours]
      );
      await client.query(
        `INSERT INTO audit_events (actor_user_id, event_type, subject_type, subject_id)
         VALUES ($1::uuid, 'auth.login', 'user', $2::text)`,
        [user.id, user.id]
      );
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

    reply.header('Set-Cookie', sessionCookie(token, {
      name: config.cookieName,
      secure: config.cookieSecure,
      maxAgeSeconds
    }));
    return { user: safeUser(user) };
  });

  app.post('/api/v1/auth/logout', async (request, reply) => {
    reply.header('Cache-Control', 'no-store');
    const token = parseCookies(request.headers.cookie)[config.cookieName];
    if (token) {
      const digest = hashSessionToken(token);
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const revoked = await client.query(
          `UPDATE sessions SET revoked_at = now()
           WHERE token_hash = $1 AND revoked_at IS NULL
           RETURNING user_id`,
          [digest]
        );
        if (revoked.rows[0]) {
          await client.query(
            `INSERT INTO audit_events (actor_user_id, event_type, subject_type, subject_id)
             VALUES ($1::uuid, 'auth.logout', 'user', $2::text)`,
            [revoked.rows[0].user_id, revoked.rows[0].user_id]
          );
        }
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    }
    reply.header('Set-Cookie', expiredSessionCookie({ name: config.cookieName, secure: config.cookieSecure }));
    return reply.code(204).send();
  });

  app.get('/api/v1/auth/me', { preHandler: authenticate(pool, config) }, async (request, reply) => {
    reply.header('Cache-Control', 'no-store');
    return { user: request.authUser };
  });

  app.get('/api/v1/admin/access-check', {
    preHandler: [authenticate(pool, config), requireRoles('admin', 'manager')]
  }, async () => ({ allowed: true }));
}

function authenticate(pool, config) {
  return async (request, reply) => {
    const token = parseCookies(request.headers.cookie)[config.cookieName];
    if (!token || token.length > 256) return reply.code(401).send({ error: 'Sesión requerida' });

    const result = await pool.query(
      `SELECT u.id, u.username, u.display_name,
              COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL), '{}') AS roles
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       WHERE s.token_hash = $1 AND s.revoked_at IS NULL
         AND s.expires_at > now() AND u.disabled_at IS NULL
       GROUP BY u.id`,
      [hashSessionToken(token)]
    );
    if (!result.rows[0]) return reply.code(401).send({ error: 'Sesión inválida o expirada' });
    request.authUser = safeUser(result.rows[0]);
  };
}

function requireRoles(...allowedRoles) {
  return async (request, reply) => {
    if (!request.authUser?.roles.some((role) => allowedRoles.includes(role))) {
      return reply.code(403).send({ error: 'Permisos insuficientes' });
    }
  };
}
