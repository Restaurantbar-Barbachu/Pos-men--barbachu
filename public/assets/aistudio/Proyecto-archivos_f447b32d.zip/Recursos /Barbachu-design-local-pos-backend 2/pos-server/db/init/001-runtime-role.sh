#!/bin/sh
set -eu
# Crea (una sola vez) la cuenta de ejecución, distinta del propietario de la base de datos.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  --set=app_password="$APP_DB_PASSWORD" <<'SQL'
SELECT format('CREATE ROLE barbachu_app LOGIN PASSWORD %L', :'app_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'barbachu_app')
\gexec
SQL
