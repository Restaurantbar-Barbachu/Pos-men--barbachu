-- Limpieza de sesiones vencidas y endurecimiento de la bitácora de auditoría.

-- La API necesita borrar sesiones vencidas o revocadas; no recibe DELETE en ninguna otra tabla.
GRANT DELETE ON sessions TO barbachu_app;

CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions (expires_at);
CREATE INDEX IF NOT EXISTS sessions_revoked_at_idx ON sessions (revoked_at) WHERE revoked_at IS NOT NULL;

-- TRUNCATE no dispara los triggers por fila; se bloquea con un trigger de sentencia.
DROP TRIGGER IF EXISTS audit_events_no_truncate ON audit_events;
CREATE TRIGGER audit_events_no_truncate
BEFORE TRUNCATE ON audit_events
FOR EACH STATEMENT EXECUTE FUNCTION prevent_audit_event_mutation();
