-- Esquema inicial de identidad, sesiones, permisos y auditoría.
-- No contiene ventas, caja, comandas ni inventario: pertenecen a fases posteriores.

CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT roles_name_format CHECK (name ~ '^[a-z][a-z0-9_]{1,31}$')
);

CREATE TABLE IF NOT EXISTS permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE RESTRICT,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  disabled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT users_username_length CHECK (char_length(username) BETWEEN 3 AND 64),
  CONSTRAINT users_display_name_length CHECK (char_length(display_name) BETWEEN 1 AND 120),
  CONSTRAINT users_password_hash_nonempty CHECK (length(password_hash) > 20)
);

CREATE UNIQUE INDEX IF NOT EXISTS users_username_lower_unique ON users (lower(username));

CREATE TABLE IF NOT EXISTS user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  token_hash CHAR(64) NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  CONSTRAINT sessions_expiry_after_creation CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS sessions_user_expiry_idx ON sessions (user_id, expires_at);

CREATE TABLE IF NOT EXISTS audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  event_type TEXT NOT NULL,
  subject_type TEXT NOT NULL,
  subject_id TEXT,
  reason TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT audit_event_type_length CHECK (char_length(event_type) BETWEEN 1 AND 100),
  CONSTRAINT audit_subject_type_length CHECK (char_length(subject_type) BETWEEN 1 AND 100)
);

CREATE INDEX IF NOT EXISTS audit_events_created_at_idx ON audit_events (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_events_actor_idx ON audit_events (actor_user_id, created_at DESC);

-- Evita modificaciones o borrados accidentales desde la aplicación.
CREATE OR REPLACE FUNCTION prevent_audit_event_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_events es append-only';
END;
$$;

DROP TRIGGER IF EXISTS audit_events_immutable ON audit_events;
CREATE TRIGGER audit_events_immutable
BEFORE UPDATE OR DELETE ON audit_events
FOR EACH ROW EXECUTE FUNCTION prevent_audit_event_mutation();

INSERT INTO roles (name, description) VALUES
  ('admin', 'Administración total del POS'),
  ('manager', 'Supervisión y autorización operativa'),
  ('cashier', 'Operación de caja'),
  ('waiter', 'Captura y seguimiento de comandas'),
  ('kitchen', 'Preparación y actualización de cocina'),
  ('bar', 'Preparación y actualización de barra')
ON CONFLICT (name) DO NOTHING;

INSERT INTO permissions (name, description) VALUES
  ('users.manage', 'Crear y administrar usuarios'),
  ('system.read', 'Consultar estado del sistema')
ON CONFLICT (name) DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r CROSS JOIN permissions p
WHERE (r.name = 'admin') OR (r.name = 'manager' AND p.name = 'system.read')
ON CONFLICT DO NOTHING;

-- El rol de ejecución solo recibe permisos DML necesarios. Las migraciones
-- se ejecutan con una cuenta propietaria separada.
GRANT USAGE ON SCHEMA public TO barbachu_app;
GRANT SELECT ON roles, permissions, role_permissions TO barbachu_app;
GRANT SELECT ON users, user_roles TO barbachu_app;
GRANT SELECT, INSERT ON sessions TO barbachu_app;
GRANT UPDATE (revoked_at) ON sessions TO barbachu_app;
GRANT SELECT, INSERT ON audit_events TO barbachu_app;
