# Barbachu — menú público y POS local

Este repositorio mantiene separado el menú público de la aplicación operativa privada.

## Componentes

- `index.html`: menú público actual. No se debe modificar para desarrollar el backend del POS.
- `pos-demo/`: demostración visual y funcional con datos sintéticos y persistencia únicamente local en el navegador. No procesa ventas reales.
- `pos-server/`: API local en Node.js 24, Fastify 5 y PostgreSQL 18. La base de datos no se expone a la red LAN; los clientes se conectan a la API.
- `docs/pos/`: intención, especificación, plan, estado y criterios de aceptación.

## Estado

La fase de backend base se prepara en la rama `design/local-pos-backend`. No está autorizada la fusión a `main`, el despliegue ni la operación con ventas reales. Consulta `docs/pos/STATUS.md` y `docs/pos/REVIEW.md` antes de continuar.
