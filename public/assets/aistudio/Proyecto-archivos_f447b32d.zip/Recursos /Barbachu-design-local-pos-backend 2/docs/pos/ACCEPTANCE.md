# Criterios de aceptación — Backend base

| Criterio | Estado de esta entrega |
|---|---|
| Servicio Fastify 5 y Node.js 24 fijados | Implementado en archivos locales; runtime local no es Node 24 |
| PostgreSQL 18 y migraciones 001-002 | Aplicadas en PostgreSQL 16 (dos veces, idempotente); pendiente PostgreSQL 18 |
| Usuarios y roles sin usuario por defecto | Implementado en migración/script |
| Hash de contraseña Argon2id | Implementado; instalación/ejecución pendiente |
| Sesiones con token aleatorio y hash persistido | Implementado y probado en módulo puro |
| Cookie HttpOnly/SameSite y Secure en producción | Implementado; prueba de navegador pendiente |
| Rate limit del login | Configurado; integración pendiente de dependencias |
| Autorización por rol en servidor | Implementada en ruta de control; prueba de integración pendiente |
| Auditoría append-only | Definida en SQL; no ejecutada localmente |
| PostgreSQL solo en loopback | Configurado en Compose; no probado con Docker |
| CI Node 24/PostgreSQL 18 | Workflow creado localmente; no ejecutado en GitHub |
| Cambios integrados en rama remota | Bloqueado por HTTP 403 |
| Merge/deploy/ventas reales | No autorizado ni realizado |


## Evidencia local disponible

- Tests backend ejecutados (Node 22, PostgreSQL 16): 17 aprobados, 0 fallidos, 0 omitidos, incluidas 2 pruebas de integración.
- Sintaxis JavaScript y shell: aprobada.
- YAML de GitHub Actions y Docker Compose: parseado correctamente.
- Auditoría de catálogo del ZIP fuente: 4 pruebas aprobadas; 199 productos, 121 insumos y 40 precios cero/negativos preservados.
