# Estado del catálogo SoftRestaurant

Fuente: paquete `Barbachu_Export_Claude_actualizado.zip`, carpeta `Barbachu_POS_Fase1/`.

- Productos exportados: 199.
- Insumos exportados: 121.
- Productos con precio cero o negativo: 40.
- Pruebas de integridad de claves y filas: 4/4 aprobadas en el entorno disponible.
- `scripts/validar_catalogo.py`: confirma filas y claves, y conserva los productos sin precio como alertas de negocio.

No se modificaron claves, descripciones, precios ni costos. No se incorporó aún el catálogo a la base de datos: el importador corresponde a una fase posterior y requiere confirmar productos vendibles, modificadores, presentaciones y precios ambiguos. Las recetas y unidades de consumo no están completas para habilitar descuento automático de inventario.
