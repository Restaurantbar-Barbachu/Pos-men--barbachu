# Plan — Fases 0 y 1

## Files to Create

- `pos-server/package.json`
- `pos-server/src/config.mjs`
- `pos-server/src/lib/security.mjs`
- `pos-server/src/routes/auth.mjs`
- `pos-server/src/app.mjs`
- `pos-server/src/server.mjs`
- `pos-server/migrations/001_initial_schema.sql`
- `pos-server/scripts/migrate.mjs`
- `pos-server/scripts/create-user.mjs`
- `pos-server/tests/*.test.mjs`
- `pos-server/Dockerfile`, `docker-compose.yml`, `.env.example`, `db/init/`
- `.github/workflows/pos-server-ci.yml`
- `docs/pos/{intent,spec,plan,STATUS,ACCEPTANCE,REVIEW,CATALOGO}.md`
- Revisión documental de `README.md` y `pos-demo/README.md` para reflejar arquitectura local-first.

## Execution Order

1. Preparar el paquete local aislado y registrar restricciones.
2. Escribir pruebas de configuración, seguridad y esquema antes de implementación (RED).
3. Implementar módulos mínimos para hacer pasar pruebas (GREEN).
4. Añadir Fastify, rutas de salud y autenticación; cubrir el flujo con prueba de integración en PostgreSQL.
5. Añadir migración, cuenta de ejecución separada y herramienta explícita para alta de usuarios.
6. Añadir Docker Compose con PostgreSQL ligado a loopback y API expuesta a la LAN.
7. Añadir CI para Node 24 y PostgreSQL 18.
8. Ejecutar verificaciones locales disponibles y registrar expresamente las no ejecutables.
9. Revisar seguridad, documentación y empaquetado.

## Verification Plan

- `node --test tests/config.test.mjs tests/security.test.mjs tests/migration.test.mjs`
- `npm run check`
- `npm run migrate` contra PostgreSQL 18.
- `npm test` con `TEST_DATABASE_URL` contra PostgreSQL 18.
- Docker build/compose config y comprobación de bind loopback para PostgreSQL.
- CI debe repetir migración, tests unitarios e integración con Node 24.
- Comparar el diff remoto contra `main`; no modificar ni fusionar `main`.

## Acceptance Gate

La fase solo se considera integrada cuando CI pase con Node 24/PostgreSQL 18, se revise el diff y el usuario apruebe la fase. Esta entrega local no cumple aún el gate remoto ni la verificación de integración completa.
