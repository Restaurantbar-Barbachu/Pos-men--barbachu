# Spec — Backend base POS Barbachu

## Runtime y componentes

- Node.js 24 LTS (versión fijada por la arquitectura aprobada; en noviembre de 2026 está en Maintenance LTS, con soporte previsto hasta abril de 2028). No se cambia a Node 26 sin revisar y aprobar la arquitectura.
- Fastify 5 para la API HTTP.
- PostgreSQL 18 como base de datos local.
- `pg` para conexiones SQL parametrizadas.
- Argon2id para hash/verificación de contraseñas.
- `@fastify/rate-limit` para limitar intentos de inicio de sesión.
- `@fastify/helmet` para encabezados HTTP de seguridad.

## Endpoints incluidos

| Método | Ruta | Acceso | Resultado |
|---|---|---|---|
| GET | `/health/live` | Público | Proceso activo |
| GET | `/health/ready` | Público | API puede consultar PostgreSQL |
| POST | `/api/v1/auth/login` | Público, limitado a 5/minuto | Crea sesión y cookie segura |
| POST | `/api/v1/auth/logout` | Público | Revoca sesión si existe y expira cookie |
| GET | `/api/v1/auth/me` | Sesión válida | Devuelve perfil mínimo y roles |
| GET | `/api/v1/admin/access-check` | admin/manager | Verifica autorización de rol |

## Modelo de datos

- `users`: usuario, nombre visible, hash de contraseña y desactivación.
- `roles`: admin, manager, cashier, waiter, kitchen y bar.
- `permissions`, `role_permissions`, `user_roles`: permisos y asignaciones.
- `sessions`: hash de token, expiración y revocación.
- `audit_events`: bitácora append-only.
- `schema_migrations`: registro de migraciones aplicado por el runner.

## Estados y errores

- 200: operación correcta.
- 204: cierre de sesión correcto.
- 400: cuerpo inválido.
- 401: credenciales o sesión inválidas.
- 403: rol insuficiente.
- 404: ruta inexistente.
- 503: base de datos no disponible en readiness.
- 500: error interno con respuesta genérica; detalle solo en logs del servidor.

## Casos límite y seguridad

- Usuarios desactivados no pueden iniciar ni mantener sesión.
- Los tokens se generan con 256 bits aleatorios; la base guarda SHA-256, nunca el token original.
- La cookie es HttpOnly y SameSite=Strict; Secure se exige en producción.
- Los cuerpos HTTP tienen límite de 16 KiB y el login limita intentos.
- Las consultas usan parámetros, no interpolación de valores.
- La bitácora rechaza UPDATE/DELETE mediante trigger.
- La API usa una cuenta PostgreSQL de ejecución separada de la cuenta propietaria de migraciones.
- No se crea usuario administrador por defecto; se provisiona explícitamente con script.
