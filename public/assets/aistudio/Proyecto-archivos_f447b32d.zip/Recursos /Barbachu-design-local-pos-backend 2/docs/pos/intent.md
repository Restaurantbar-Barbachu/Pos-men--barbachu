# Intent — Backend local del POS Barbachu

## Problem

El prototipo actual es una demostración sintética basada en `localStorage`. No ofrece autenticación real, permisos en servidor, base de datos compartida ni sincronización entre dispositivos. No debe utilizarse para registrar ventas reales.

## Proposed Outcome

Construir la base técnica privada para un POS de una sucursal, operable desde celulares, tablets y computadoras dentro de la red local, con una API central y PostgreSQL. Esta entrega cubre solo la fundación técnica: servicio Fastify, configuración, migración inicial de identidad/roles/sesiones/auditoría, autenticación, autorización básica, pruebas y CI.

## Constraints

- Mantener intacto el menú público de la raíz.
- Mantener `pos-demo/` como demostración sintética, no como sistema transaccional.
- No exponer PostgreSQL a la LAN; solo la API puede recibir conexiones de clientes.
- No almacenar tokens de sesión en texto claro; persistir solo su SHA-256.
- Usar Argon2id para contraseñas, cookies HttpOnly y SameSite=Strict, y HTTPS/Secure en producción.
- No incluir secretos ni usuarios predeterminados.
- No cambiar claves ni precios del catálogo SoftRestaurant.
- No implementar ventas, comandas, caja, inventario, recetas, pagos ni PWA en esta fase.
- No fusionar ni desplegar sin autorización humana.
