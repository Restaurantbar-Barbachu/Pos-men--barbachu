# Revisión técnica — Paquete local de fase 1

## Alcance

Revisión estática del backend base preparado localmente. No equivale a revisión de un diff integrado en GitHub ni a auditoría de seguridad independiente.

## Controles implementados

- Configuración validada y rechazo de cookie no segura en producción.
- Argon2id previsto para contraseñas.
- Token de sesión aleatorio de 256 bits; solo SHA-256 persistido.
- Cookie HttpOnly, SameSite=Strict y Secure en producción.
- Rate limit en endpoint de login.
- Encabezados HTTP de seguridad con `@fastify/helmet`.
- Validación JSON Schema y límite de cuerpo.
- Consultas SQL parametrizadas.
- Roles y autorización del lado servidor.
- Bitácora append-only con trigger SQL.
- Separación entre cuenta propietaria de migraciones y cuenta de ejecución.
- PostgreSQL enlazado a `127.0.0.1` en Docker Compose.
- No se incluyen credenciales reales ni usuarios por defecto.

## Hallazgos y pendientes antes de piloto

1. **Bloqueo de integración:** la escritura de GitHub devuelve 403. El paquete no está en la rama remota.
2. **Dependencias:** `package-lock.json` generado y `npm audit` sin vulnerabilidades; falta revisarlo con Node 24 en CI.
3. **Pruebas de integración:** ejecutadas y aprobadas contra PostgreSQL 16; falta repetirlas en PostgreSQL 18.
4. **TLS:** `COOKIE_SECURE=false` es únicamente para desarrollo LAN local. Producción requiere HTTPS y `COOKIE_SECURE=true`.
5. **Rate limit:** el almacenamiento por defecto es memoria del proceso; aceptable para una sola instancia inicial, no para múltiples instancias.
6. **Bootstrap de DB:** el script de rol ahora es idempotente y se probó en PostgreSQL 16; probar dentro del contenedor `postgres:18-alpine`.
7. **Seguridad operacional:** definir firewall LAN, respaldo/restauración cifrados, rotación de secretos, política de sesiones y monitoreo antes de piloto.
8. **Auditoría:** verificado que la cuenta de ejecución no puede DELETE ni TRUNCATE `audit_events`; la cuenta propietaria sigue pudiendo quitar el trigger.
9. **Bug corregido:** login/logout devolvían 500 contra PostgreSQL real (tipos de parámetro en la auditoría). Corregido y cubierto por prueba de integración.

## Veredicto

**No listo para producción.** Es una base de implementación para revisión e integración. La puerta de aceptación requiere CI verde con Node 24/PostgreSQL 18, revisión del diff remoto y aprobación humana.
