# Estado de implementación POS Barbachu

**Fecha:** 2026-11-01  
**Destino previsto:** `Restaurantbar-Barbachu/Barbachu`  
**Rama prevista:** `design/local-pos-backend`  
**Base remota observada:** `48b0ef9262922762b393ae4b65a9085f5e7b035f`

## Estado remoto verificado

- La rama `design/local-pos-backend` existe.
- Al inicio de esta ejecución, `main` y la rama estaban idénticas (0 commits de diferencia).
- La lectura del árbol y archivos de la rama funciona.
- La primera escritura de `docs/pos/STATUS.md` fue rechazada por GitHub con HTTP 403: `Resource not accessible by integration`.
- No se creó commit remoto y no se modificó `main`.
- La clonación por HTTPS también falló por falta de resolución de `github.com` en este entorno.

## Estado local tras integrar el ZIP recibido

El 2026-11-01 se integraron los archivos de las Fases 0 y 1 sobre el ZIP completo que entregó el usuario. El resultado es un snapshot completo del contenido recibido más el backend base: configuración, autenticación/sesiones, migración de roles y auditoría, scripts, pruebas, Docker Compose, CI y documentación.

El ZIP recibido no contiene metadatos `.git`, por lo que no se pudo confirmar su HEAD exacto ni sincronizarlo contra GitHub. No se realizó ningún commit remoto, merge ni despliegue.

## Restricciones vigentes

- No escribir en `main`, fusionar ni desplegar.
- No alterar el HTML del menú público.
- `pos-demo/` sigue siendo sintético.
- No implementar ventas, comandas, caja, cocina, inventario, recetas ni PWA en esta entrega.
- No activar pagos ni operación real.

## Limitaciones de verificación

El entorno tiene Node.js 22.16.0, no Node.js 24; no tiene Docker ni PostgreSQL; y no puede resolver `registry.npmjs.org`. Por ello no fue posible instalar Fastify/pg/Argon2, levantar PostgreSQL 18 ni ejecutar las pruebas de integración. Los tests unitarios puros pasan (11 aprobados, 1 prueba de integración omitida por falta de `TEST_DATABASE_URL`), las comprobaciones de sintaxis pasan y las validaciones del catálogo pasan (4/4). Estas verificaciones se ejecutaron con Node 22/Python 3.13 y no sustituyen CI con Node 24/PostgreSQL 18.

## Correcciones posteriores (2026-11-01, segunda pasada)

- **Bug corregido:** `POST /api/v1/auth/login` y `/logout` devolvían HTTP 500 en PostgreSQL real (`inconsistent types deduced for parameter $1`, código 42P08) por usar `$1` como `uuid` y como `text` en el INSERT de auditoría. Ahora usa `$1::uuid` y `$2::text`. Las pruebas puras no lo detectaban; solo la prueba de integración.
- Se añadió `package-lock.json` (79 paquetes; `npm audit`: 0 vulnerabilidades). `Dockerfile` y CI usan `npm ci`.
- Migración `002_session_cleanup_and_audit_hardening.sql`: `GRANT DELETE ON sessions`, índices de expiración/revocación y trigger que bloquea `TRUNCATE` en `audit_events`.
- `src/lib/session-cleanup.mjs`: purga de sesiones vencidas/revocadas (>7 días) al arrancar y cada 6 h.
- `docker-compose.yml`: la API se publica en `127.0.0.1` por defecto (`API_BIND_ADDRESS` para abrir a la LAN).
- `db/init/001-runtime-role.sh` ahora es idempotente.

### Verificación de esta pasada

Node.js 22.22.2 y PostgreSQL **16** (no 18, no Node 24): 17 de 17 pruebas aprobadas, incluidas las 2 de integración contra una base real; migraciones 001 y 002 aplicadas dos veces sin error. Sigue pendiente CI en Node 24 / PostgreSQL 18, Docker Compose real, TLS y revisión humana. Sigue sin autorizarse merge, despliegue ni ventas reales.
