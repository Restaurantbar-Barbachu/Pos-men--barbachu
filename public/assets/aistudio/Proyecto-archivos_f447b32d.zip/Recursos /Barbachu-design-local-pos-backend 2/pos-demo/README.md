# POS Barbachu · Demo pública

Prototipo estático para revisar interfaz y flujos. Contiene exclusivamente información sintética; no procesa pagos, no conecta con SoftRestaurant y no debe usarse para ventas reales.

## Probar localmente

Desde esta carpeta, con Node.js 24, Python 3 y pnpm 11:

```sh
pnpm install --frozen-lockfile
pnpm exec playwright install chromium
pnpm test
python -m unittest tests/test_demo_catalog.py -v
pnpm test:ui
```

Los cobros son simulados y el inventario se guarda solo en el `localStorage` del navegador bajo `barbachu.pos-demo.v1`. No existe sincronización multi-dispositivo.

## Relación con el backend

La demo permanece separada del backend local privado, que se desarrolla en `pos-server/` con Node.js 24, Fastify 5 y PostgreSQL 18. La API real no está conectada a esta demo hasta que las fases posteriores sean aprobadas y probadas.

## Límites

No hay autenticación real, permisos de servidor, base de datos compartida, pagos, impresión fiscal ni deducción automática de inventario. No habilitar ventas reales ni deducciones de inventario hasta validar el catálogo, recetas, cantidades, unidades, rendimientos, existencias y reglas de cancelación/devolución.
