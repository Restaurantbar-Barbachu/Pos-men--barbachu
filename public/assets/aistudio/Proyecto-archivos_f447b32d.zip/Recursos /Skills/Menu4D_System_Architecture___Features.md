# Especificación del Sistema de Gestión Restaurante QR (Menu4D)

Este documento describe la arquitectura funcional, modelo de datos y flujos de trabajo para un sistema de gestión de restaurantes basado en pedidos por código QR.

---

## 📱 1. Flujo de Usuario (Cliente / Mesa)

1. **Escaneo de QR:**
   * El cliente escanea el código QR de la mesa (asociado a `Mesa ID` único).
   * Se despliega el menú digital directamente en el navegador sin necesidad de descargar una app.
2. **Realización de Pedidos:**
   * Selección de ítems y personalizaciones.
   * Envío del pedido: se notifica al sistema central con el estado `Pedido Recibido`.
3. **Atención en Mesa:**
   * Botón para **Llamar al Mozo**.
   * Botón para **Pedir la Cuenta**.
4. **Pago Flexible:**
   * Opciones integradas: Efectivo, Mercado Pago, Tarjeta de Crédito, Tarjeta de Débito.

---

## 🖥️ 2. Panel de Administración / Métricas en Tiempo Real (Dashboard)

El dashboard consolida la operación de todo el establecimiento en 4 vistas o estados clave:

### Resumen General (Métricas)
* **Ventas del turno:** Acumulado en moneda local.
* **Pedidos activos:** Contador de comandas sin confirmar/en curso.
* **Mesas ocupadas:** Total de mesas activas en el salón.

### Módulos del Sistema

| Módulo | Funcionalidad Clave |
| :--- | :--- |
| **Mesas / Sala** | Vista global del mapa del salón. Estado de ocupación de cada mesa (Ocupada / Libre) y notificaciones de atención/cuenta. |
| **Cocina (KDS)** | Pantalla para el personal de cocina. Visualiza comandas entrantes (`En cocina`, `Listos / En camino`). Cambio de estado con un solo toque (`Listo`). |
| **Caja** | Gestión de cuentas solicitadas y cierres por método de pago (Efectivo, Mercado Pago, Débito, Crédito). |

---

## 🗄️ 3. Modelo de Datos Simplificado (Data Schema)

```json
{
  "Table": {
    "id": "mesa_4",
    "number": 4,
    "status": "occupied", // occupied | free
    "current_order_id": "ord_8123"
  },
  "Order": {
    "id": "ord_8123",
    "table_id": "mesa_4",
    "status": "in_kitchen", // received | confirmed | in_kitchen | ready | delivered
    "items": [
      { "name": "Milanesa Napolitana", "qty": 1, "price": 18500 },
      { "name": "Pollo al Verdeo", "qty": 1, "price": 14000 }
    ],
    "total": 32500,
    "created_at": "2026-10-29T21:32:00Z"
  },
  "ServiceRequest": {
    "table_id": "mesa_4",
    "type": "call_waiter", // call_waiter | request_bill
    "payment_method": "mercado_pago",
    "status": "pending" // pending | attended
  }
}
```

---

## 🔄 4. Estados del Pedido (Order Lifecycle)

1. `Pedido Recibido` (Cliente envía el pedido).
2. `Pedido Confirmado` (Pasa a preparación).
3. `Pedido en Camino` (Cocina marca como "Listo").
4. `Pedido Entregado` (El mozo entrega el plato en mesa).