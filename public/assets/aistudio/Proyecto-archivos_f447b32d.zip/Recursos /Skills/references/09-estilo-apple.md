# 09 · Estilo Apple para web (interfaces fluidas, materiales y movimiento físico)

Fuente completa: la skill `apple-design` (WWDC: *Designing Fluid Interfaces*, *Details of UI Typography*, *Principles of Great Design*). Este archivo es la versión de consulta rápida, con código listo y adaptada a la web. Si necesitas más detalle, abre el SKILL.md indicado en cada sección.

## 0. Cuándo aplicar / cuándo NO
- **Aplicar** en: menús digitales, apps móviles en web, POS táctil, paneles, hojas (sheets), carruseles, cualquier UI que se toca con el dedo.
- **No aplicar** (o reducir) en: documentos para imprimir (usar su CSS `@media print`), landings informativas muy simples, acciones de teclado de alta frecuencia (no animarlas), contenido legal.
- Contención primero: un solo momento de movimiento orquestado por pantalla; el resto, feedback funcional (presionar, abrir, cerrar). Si una animación no comunica un estado o relación espacial, se elimina.

## 1. La idea central
Una interfaz se siente viva cuando el movimiento **parte del valor actual en pantalla, hereda la velocidad del usuario, proyecta el impulso y puede agarrarse y revertirse en cualquier instante.** Los resortes (springs) lo logran porque son interrumpibles y conscientes de la velocidad. Cuatro necesidades humanas que sirven de guía: seguridad/predictibilidad, comprensión, logro y alegría.

## 2. Reglas operativas (en orden de importancia)
| # | Regla | Cómo se implementa |
|---|---|---|
| 1 | **Respuesta inmediata**: feedback al presionar, no al soltar | `:active` instantáneo (`transition:none` al presionar, fundido al soltar); `touch-action: manipulation` elimina el retardo de toque |
| 2 | **Manipulación directa 1:1** | Pointer Events + `setPointerCapture`; respetar dónde agarró el usuario; seguir el dedo todo el recorrido |
| 3 | **Interrumpible** | Nunca bloquear entrada durante una transición; animar siempre desde el valor **actual** (presentación), no desde el destino |
| 4 | **Resortes en gestos**, CSS en estados | Para todo lo que se toca: resorte. Para hover/color/aparición simple: `transition` CSS |
| 5 | **Entregar velocidad** al soltar | La velocidad del dedo es la velocidad inicial del resorte (sin "costura") |
| 6 | **Proyectar el impulso** | Elegir el destino por dónde *iría* el gesto, no por dónde se soltó |
| 7 | **Consistencia espacial** | Lo que entra por un lado sale por el mismo; popover/sheet nacen del elemento que los abrió (`transform-origin`) |
| 8 | **Bordes elásticos** | Resistencia progresiva (rubber-band), no tope duro |

### Valores de resorte (damping = rebote, response = rapidez en segundos)
| Interacción | Damping | Response |
|---|---|---|
| Mover / reposicionar | 1.0 | 0.4 |
| Rotación | 0.8 | 0.4 |
| Cajón / sheet | 0.8 | 0.3 |
Por defecto: **damping 1.0** (críticamente amortiguado, sin rebote). Añade rebote (~0.8) **solo** si el gesto traía impulso (un lanzamiento). Un menú que aparece no rebota.
Con Motion/Framer: `{type:'spring', bounce:0, duration:.4}` (default) y `bounce:.2` para gestos con impulso.

### Funciones clave (copiar tal cual)
```js
// Proyección de impulso (forma exponencial de Apple; 0.998 scroll normal, 0.99 más ágil)
const project = (v /* px/s */, d = 0.998) => (v / 1000) * d / (1 - d);

// Elástico en el borde
const rubber = (over, dim, c = 0.55) => (over * dim * c) / (dim + c * Math.abs(over));

// Resorte críticamente amortiguado sin dependencias (interrumpible: parte de y y vel actuales)
function spring(state, to, v0, onFrame, done, response = 0.34) {
  cancelAnimationFrame(state.raf);
  const w = (2 * Math.PI) / response, x0 = state.y - to, c2 = v0 + w * x0, t0 = performance.now();
  const step = (now) => {
    const t = (now - t0) / 1000, e = Math.exp(-w * t);
    state.y = to + (x0 + c2 * t) * e;                 // posición
    state.vel = (c2 - w * (x0 + c2 * t)) * e;         // velocidad (para interrumpir)
    onFrame(state.y);
    if (t < 1 && (Math.abs(state.y - to) > 0.4 || Math.abs(state.vel) > 8)) state.raf = requestAnimationFrame(step);
    else { state.y = to; onFrame(to); state.vel = 0; done && done(); }
  };
  state.raf = requestAnimationFrame(step);
}
```
Decisión al soltar: `if (y + project(vel) > alto * 0.5) cerrar(); else volver();` — decide con la **velocidad proyectada**, no con la posición sola.

## 3. Sheet inferior (patrón completo)
Usar `<dialog>` nativo (`showModal()`: foco atrapado, Esc, `::backdrop`) con arrastre propio en el asa.
```html
<dialog class="sheet" id="sheet" aria-labelledby="s-name">
  <div class="sheet-head"><div class="grab"></div></div>   <!-- zona de arrastre, touch-action:none -->
  <div class="sheet-body">…contenido…</div>                 <!-- sin padding en <dialog> para detectar clic en fondo -->
</dialog>
```
```css
.sheet{margin:auto auto 0;width:min(100%,640px);max-width:none;max-height:88dvh;border:0;padding:0;
  border-radius:28px 28px 0 0;overflow:visible;will-change:transform;
  background:var(--mat);backdrop-filter:blur(28px) saturate(180%);box-shadow:inset 0 1px 0 var(--edge)}
.sheet::backdrop{background:rgb(0 0 0/calc(var(--dim,1)*.55))}  /* el oscurecimiento sigue al arrastre */
.sheet-head{touch-action:none;cursor:grab;padding:10px 0 6px}
.grab{width:36px;height:5px;border-radius:3px;background:var(--edge);margin:0 auto}
```
Flujo JS: abrir → `showModal(); set(alto); spring(0,0)`; arrastrar → `set(d<0 ? -rubber(-d,300) : d)`; soltar → proyectar y `close()`/`spring(0,vel)`; cerrar → `spring(alto, max(vel,0), () => dlg.close())`; `cancel` (Esc) → `preventDefault()` + cerrar animado; clic en `dlg` (fondo) → cerrar. Referencia viva: `index-apple.html`.

## 4. Materiales y profundidad
- Barras y hojas **translúcidas** (contenido pasa por debajo), no franjas opacas.
- Peso del material = jerarquía: superficies grandes → más blur y sombra más profunda; **nunca** apilar una superficie translúcida clara sobre otra.
- Borde superior brillante = luz sobre el material. Separar de contenido con **efecto de borde de scroll** (sombra sutil al quedar pegada), no con una línea fija.
- Modal: oscurecer fondo (scrim). Panel paralelo no bloqueante: translúcido, sin scrim.
- Texto sobre material: contraste alto, peso algo mayor; el color va en una capa sólida, no en el texto translúcido.
```css
.bar{background:var(--mat);backdrop-filter:blur(20px) saturate(180%);-webkit-backdrop-filter:blur(20px) saturate(180%);border-top:1px solid var(--edge)}
.bar.stuck{box-shadow:0 1px 0 var(--line),0 8px 24px rgba(0,0,0,.35)}   /* clase añadida por IntersectionObserver en un centinela */
```
Título grande que colapsa: centinela `<div id="sentinel">` antes de la barra; `IntersectionObserver` activa `.stuck`; el título pequeño de la barra se muestra con `max-height` + `opacity`.

## 5. Tipografía (óptica y por tamaño)
- Fuente del sistema por defecto: `system-ui, -apple-system, "SF Pro Text", "Segoe UI", Roboto, sans-serif`. Serif de marca solo en títulos/logotipo (p. ej. Georgia).
- **Tracking según tamaño**: títulos grandes negativo (`-0.02em`), cuerpo ≈ `0`, texto pequeño/etiquetas ligeramente positivo (`.02–.08em`). Nunca un `letter-spacing` fijo global.
- **Interlineado inverso al tamaño**: 1.05–1.15 en titulares, 1.5 en cuerpo.
- Jerarquía = peso + tamaño + interlineado juntos. Espaciado en `rem` (respeta el tamaño de texto del usuario). `text-wrap: balance` en títulos, `pretty` en párrafos.
- `font-variant-numeric: tabular-nums` en precios y cifras alineadas.

## 6. Patrones de página tipo app
| Patrón | Receta |
|---|---|
| **Lista agrupada (inset grouped)** | `ul` con `background:var(--card); border-radius:20px; overflow:hidden`; filas `button` de ≥56 px; separador `li+li{border-top:1px solid var(--line)}`; precio/valor alineado a la derecha; pie explicativo (`.foot`) debajo |
| **Fila** | Todo el renglón es tocable; `:active` cambia fondo al instante; subtítulo secundario en `--dim` |
| **Carrusel** | `display:flex; overflow-x:auto; scroll-snap-type:x mandatory; scroll-padding-inline`; tarjetas `flex:0 0 min(72%,224px)`; `scroll-snap-align:start` |
| **Chips de navegación** | `nav` con scroll horizontal, píldoras ≥44 px, `aria-current` y centrado de la activa (IntersectionObserver con `rootMargin:'-20% 0px -70% 0px'`) |
| **Hoja de detalle** | §3, abierta al tocar una fila o tarjeta; acción primaria grande (≥52 px) + "Cerrar" |
| **Barra inferior / botón flotante** | Respetar `env(safe-area-inset-bottom)`; reservar `padding-bottom` en el cuerpo para que no tape contenido |

## 7. Nativo en móvil (checklist rápido)
- `viewport-fit=cover` + `env(safe-area-inset-*)` en barras, flotantes y márgenes.
- `100svh`/`dvh` en lugar de `100vh`. Inputs ≥16 px (evita zoom en iOS).
- `-webkit-tap-highlight-color: transparent`; `user-select:none` en botones/píldoras; `touch-action: manipulation`.
- **Hover solo con puntero preciso**: `@media (hover:hover) and (pointer:fine){…}`; en táctil usar `:active`.
- `overscroll-behavior` en contenedores con scroll interno; `-webkit-backdrop-filter` junto al estándar.
- Áreas táctiles ≥44×44 px; separación suficiente entre objetivos.
Detalle: la skill `mobile-native`.

## 8. Accesibilidad del movimiento (tres señales independientes)
```css
@media (prefers-reduced-motion: reduce){ /* sin deslizar/rebotar: fundidos cortos */
  *,*::before,*::after{transition-duration:.01ms!important;animation-duration:.01ms!important;scroll-behavior:auto!important}
}
@media (prefers-reduced-transparency: reduce){ .bar,.sheet{background:var(--card);backdrop-filter:none} }
@media (prefers-contrast: more){ .list,.card,.sheet{border:1px solid var(--cream)} .r-sub,.cap{color:var(--cream)} }
```
- En JS: `matchMedia('(prefers-reduced-motion: reduce)')` → `set(destino)` directo, sin resorte.
- Reduced motion ≠ sin feedback: se mantienen cambios de opacidad/color que ayudan a entender.
- Evitar fondos en movimiento de pantalla completa, oscilaciones lentas continuas y saltos bruscos de brillo.
- Mantener `<dialog>`, `aria-current`, etiquetas y orden de foco: lo táctil bonito no sustituye lo accesible (ver `04`).

## 9. Rendimiento
- Solo `transform` y `opacity`; `will-change: transform` únicamente en lo que se mueve (sheet), no en todo.
- `backdrop-filter` es costoso: pocas capas, áreas pequeñas; desactivar con `prefers-reduced-transparency`.
- Un `requestAnimationFrame` activo a la vez por elemento; cancelar al interrumpir.
- `scroll-timeline` nativo (`animation-timeline: scroll(root)`) para barras de progreso, con respaldo JS (ver `05`).
Detalle: la skill `animation-performance` y `performance-cheatsheet.md`.

## 10. Los 8 principios de diseño (para razonar decisiones)
1 **Propósito** (decidir qué NO construir) · 2 **Agencia** (control + deshacer fácil; confirmar solo lo irreversible) · 3 **Responsabilidad** (privacidad, seguridad, no dañar) · 4 **Familiaridad** (patrones conocidos y consistentes; romperlos solo con prueba) · 5 **Flexibilidad** (contextos, dispositivos, capacidades) · 6 **Simplicidad ≠ minimalismo** (camino común primero, avanzado un nivel más hondo) · 7 **Craft** (cada valor es deliberado) · 8 **Delight** (consecuencia de los siete anteriores).
Tácticas: cuatro tipos de feedback (estado, finalización, aviso, error; validar en línea); *wayfinding* (¿dónde estoy, a dónde voy, cómo salgo?); etiquetas específicas ("Bebidas", no "Más"); proximidad = relación.

## 11. Tema Barbachu (ejemplo de tokens para conservar la marca)
```css
:root{color-scheme:dark;
 --bg:#0a0a0b;--card:#161618;--card2:#1f1f22;--cream:#f0e6d3;--dim:rgba(240,230,211,.72);
 --gold:#c8a84b;--goldb:#e8d090;--golddim:rgba(200,168,75,.28);
 --line:rgba(240,230,211,.1);--edge:rgba(255,255,255,.14);--mat:rgba(22,22,24,.62);--wa:#25d366;
 --serif:Georgia,'Iowan Old Style','Palatino Linotype',serif;
 --sans:system-ui,-apple-system,'SF Pro Text','Segoe UI',Roboto,sans-serif}
```
Contrastes verificados: crema sobre #161618 ≥ 12:1; dorado #c8a84b sobre #0a0a0b ≈ 8:1. Reutilizable para otra marca cambiando solo estos tokens.

## 12. Qué skill abrir según la tarea (skills instaladas por separado)
| Tarea | Skill |
|---|---|
| Diseñar/revisar UI con gestos, sheets, materiales, tipografía | `apple-design` |
| Filosofía de detalle y "feel" general | `emil-design-eng` |
| Construir una animación desde cero (¿debe animar?, propiedades, easing, duración) | `animate` |
| Animación que se traba o cuelga fotogramas | `animation-performance` |
| Nombrar un efecto ("¿cómo se llama cuando…?") | `animation-vocabulary` |
| Criticar movimiento existente con reglas estrictas | `review-animations` |
| Detectar dónde conviene (o no) animar | `find-animation-opportunities` |
| Auditar el movimiento de todo un código y generar planes | `improve-animations` |
| Que la web se sienta nativa en el teléfono | `mobile-native` |
| Probar con datos extremos (nombres largos, listas vacías) | `break-ui` |
| Comparar varias versiones de un componente | `prototype` |
| Elegir librería (toasts, gráficos, drag and drop…) | `pick-ui-library` · `ask-sonner` |
| React Native / Expo | `animate-expo` |
| Swift moderno | `write-swift` |

## 13. Checklist de entrega estilo Apple
- [ ] Feedback al presionar (`:active`) en cada elemento tocable; hover solo con puntero preciso.
- [ ] Gestos 1:1, con velocidad entregada al soltar y destino proyectado; interrumpibles.
- [ ] Resortes con damping 1.0 salvo gestos con impulso; sin `transition` CSS en cosas arrastrables.
- [ ] Entrada y salida por el mismo camino; origen anclado al disparador.
- [ ] Barras/hojas translúcidas con alternativas para `reduced-transparency` y `prefers-contrast`.
- [ ] `prefers-reduced-motion`: fundidos en lugar de deslizamientos/resortes.
- [ ] Tracking y interlineado por tamaño; cifras tabulares; texto ≥16 px base.
- [ ] Safe areas, `dvh/svh`, áreas táctiles ≥44 px, inputs ≥16 px.
- [ ] Un solo momento de movimiento orquestado; nada animado sin propósito.
- [ ] Probado con datos extremos (`break-ui`) y revisado en cámara lenta.
