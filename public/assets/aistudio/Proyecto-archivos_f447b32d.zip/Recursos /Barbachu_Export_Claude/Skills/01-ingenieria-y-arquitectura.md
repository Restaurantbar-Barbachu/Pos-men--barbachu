# 01 · Ingeniería y arquitectura

## 1. Flujo de trabajo estándar (de petición a entrega)
1. **Entender**: objetivo, entradas, salidas, restricciones (stack, plataforma, límites de memoria/tiempo). Pregunta solo si falta un dato crítico (1 línea).
2. **Diseñar mínimo**: lista de componentes + contrato de cada uno (entrada → salida → errores).
3. **Implementar en vertical**: primero el camino feliz extremo a extremo, luego errores y bordes.
4. **Verificar**: ejecutar/lintar/tests; leer el diff completo como si fuera de otro.
5. **Entregar**: archivo completo + comando de instalación + comando de ejecución.

## 2. Principios con regla operativa
| Principio | Regla concreta |
|---|---|
| KISS / YAGNI | No añadas capas, flags ni abstracciones sin 2+ usos reales. |
| DRY (con criterio) | Duplicación tolerable hasta 3 repeticiones; abstrae a la tercera ("regla de 3"). |
| SRP | Una función = una razón de cambio; ≤ 40 líneas como guía, ≤ 4 parámetros (si más, usa objeto/dataclass). |
| Separación de capas | UI → lógica de negocio → acceso a datos. La UI nunca habla con la BD. |
| Inmutabilidad por defecto | `const`, `frozen dataclass`, `final`. Muta solo donde el rendimiento lo exija. |
| Fail fast | Valida al borde (entrada) y lanza error claro; no propagues datos inválidos. |
| Idempotencia | Operaciones reintentables (pagos, webhooks, jobs) con clave de idempotencia. |
| Menor privilegio | Cada token/usuario/servicio con el mínimo permiso necesario. |
| Composición > herencia | Hereda solo para "es-un" estable; el resto, inyecta dependencias. |

SOLID resumido: **S** una responsabilidad · **O** extiende sin editar el núcleo · **L** subtipos sustituibles · **I** interfaces pequeñas · **D** depende de abstracciones (inyección).

## 3. Estructura de proyecto (referencia)
```
proyecto/
├─ src/            # código (por dominio, no por tipo, si crece)
├─ tests/          # espejo de src/
├─ docs/           # decisiones (ADR) y README de arquitectura
├─ scripts/        # utilidades de dev/CI
├─ .env.example    # variables SIN valores reales
├─ .gitignore      # .env, node_modules, __pycache__, dist, *.log
└─ README.md       # qué es, instalar, ejecutar, probar, desplegar
```
README mínimo: 1 frase de propósito · instalación (comando exacto) · ejecución (comando exacto) · variables de entorno · cómo probar.

## 4. Patrones de arquitectura: cuándo usar cada uno
| Patrón | Úsalo cuando | Evítalo cuando |
|---|---|---|
| Monolito modular | Equipo pequeño, producto nuevo (DEFAULT) | — |
| Microservicios | Equipos independientes, escalado dispar, dominios muy separados | Equipo <5 personas |
| Event-driven / colas | Trabajo asíncrono, picos, desacoplar (emails, procesamiento) | Flujos que exigen respuesta inmediata consistente |
| Serverless | Cargas esporádicas, sin ops | Latencia crítica, estado largo, cold starts inaceptables |
| MVC/MVVM | UI con estado y lógica | Scripts simples |
| Hexagonal (puertos y adaptadores) | Dominio complejo que debe ser testeable sin infraestructura | CRUD simple |
| CQRS | Lecturas y escrituras con modelos/escala muy distintos | Casi siempre es sobreingeniería |

## 5. APIs
- REST: sustantivos en plural (`/users/42`), verbos HTTP correctos (GET seguro e idempotente; PUT/DELETE idempotentes; POST no).
- Códigos: 200 OK · 201 creado · 204 sin contenido · 400 entrada inválida · 401 no autenticado · 403 sin permiso · 404 no existe · 409 conflicto · 422 semántica inválida · 429 rate limit · 5xx culpa del servidor.
- Errores con forma fija: `{"error":{"code":"INVALID_EMAIL","message":"...","details":[...]}}`. Nunca stack traces al cliente.
- Paginación por cursor para listas grandes; límite máximo de `page_size`.
- Versionado: `/v1/` o cabecera; no rompas contratos sin versión nueva.
- Timeouts en TODA llamada saliente; reintentos con backoff exponencial + jitter solo en operaciones idempotentes.
- Validación de esquema en el borde (Pydantic, Zod, JSON Schema).

## 6. Datos
- Normaliza hasta 3FN; desnormaliza solo con medición.
- Índices en columnas de `WHERE`/`JOIN`/`ORDER BY` frecuentes; verifica con `EXPLAIN`.
- Migraciones versionadas y reversibles; nunca editar la BD a mano en producción.
- Transacciones para operaciones multi-paso; define nivel de aislamiento conscientemente.
- Dinero: entero en centavos o `Decimal`; jamás `float`.
- Fechas: guarda UTC (ISO 8601), convierte en la presentación.
- Backups probados (restaurar al menos 1 vez); regla 3-2-1.
- N+1: si ves un bucle con una consulta dentro, usa `JOIN`/carga anticipada/`IN (...)`.

## 7. Concurrencia y estado
- Race condition = dos actores leen-modifican-escriben. Soluciones: transacción, bloqueo optimista (columna `version`), operación atómica (`UPDATE ... SET n = n + 1`), cola serializada.
- Async no es paralelo: `async/await` ayuda con I/O, no con CPU. CPU pesada → procesos/workers/hilos nativos.
- Evita estado global mutable; si es inevitable, protégelo (lock/actor/cola).
- Deadlock: adquiere locks siempre en el mismo orden; usa timeouts.

## 8. Manejo de errores (política)
1. Distingue **esperados** (validación, no encontrado → respuesta controlada) de **inesperados** (bug → log + 500 genérico).
2. Captura lo más específico posible; relanza si no sabes resolver.
3. Log con contexto (id de petición, entrada saneada), sin datos sensibles.
4. Recursos siempre liberados: `with` (Python), `try/finally`, `using`, `defer`.
5. Degradación elegante: si falla un servicio no crítico, la app sigue.
6. Cierra el ciclo: toda excepción termina en (a) respuesta al usuario, (b) log, (c) alerta si es crítica.

## 9. Pruebas
- Pirámide: muchas unitarias (rápidas, sin red/BD) → algunas de integración → pocas E2E.
- Un test = un comportamiento; nombre `debe_<resultado>_cuando_<condición>`.
- Patrón AAA: Arrange, Act, Assert.
- Prueba bordes: vacío, `null`, 0, negativo, máximo, unicode, duplicados, concurrencia.
- Bug reportado → primero test que lo reproduce, luego el arreglo (queda como regresión).
- Mocks solo en fronteras (red, reloj, BD); no mockees lo que posees.
- Cobertura es indicador, no meta: 80% con buenos asserts > 100% vacío.

## 10. Git
- Commits atómicos, imperativo, ≤72 caracteres: `fix: evita doble envío en formulario de pedido`.
- Prefijos (Conventional Commits): `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `perf`, `ci`.
- Ramas cortas desde `main`; PR pequeños (<400 líneas de diff).
- Nunca `git push --force` a ramas compartidas; usa `--force-with-lease` solo en tu rama.
- Secreto subido por error: **rotar la credencial primero**; reescribir historial es secundario.
- Comandos base: `git add -A && git commit -m "feat: ..." && git push origin main`.

## 11. CI/CD y operación
- Pipeline mínimo: lint → tipos → tests → build → escaneo de dependencias → despliegue.
- Entornos separados (dev/staging/prod) con configuración por variables de entorno.
- Despliegues reversibles (rollback en <5 min). Feature flags para lanzar gradual.
- Observabilidad: logs estructurados (JSON), métricas (latencia p95, tasa de error), trazas; alertas sobre síntomas, no sobre causas.
- Contenedores: imagen base mínima, usuario no root, `.dockerignore`, versiones fijadas, multi-stage.

## 12. Rendimiento (método)
1. Mide primero (profiler, `EXPLAIN`, Lighthouse). 2. Ataca el cuello de botella real. 3. Mide después.
- Orden típico de ganancia: consultas/índices → caché → menos red/bytes → algoritmo → micro-optimizaciones.
- Complejidad: evita O(n²) sobre colecciones grandes; usa `dict`/`Set` para búsquedas.
- Caché: define invalidación y TTL desde el diseño ("solo hay dos cosas difíciles…").

## 13. Documentación
- Comenta el **por qué**, no el qué. Docstring en API pública. ADR (1 página) por decisión relevante: contexto · decisión · consecuencias.
