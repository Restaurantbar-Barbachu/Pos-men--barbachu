# 08 · Checklists, modos de trabajo y plantillas

## 1. Checklist final antes de entregar CÓDIGO
- [ ] Archivo completo, sin `...`, TODO ni placeholders; imports/`require` presentes.
- [ ] Comando de instalación exacto (primera línea si hay dependencias) y comando RUN exacto.
- [ ] Entradas validadas; errores manejados (`try/catch`, códigos de salida, nulos).
- [ ] Sin secretos hardcodeados; configuración por variables de entorno.
- [ ] Sin variables no definidas, imports sin usar ni rutas absolutas del equipo del autor.
- [ ] Timeouts en red, recursos liberados (`with`/`finally`), sin bloqueos en el hilo principal.
- [ ] Probado mentalmente con: vacío, `null`, valor máximo, caracteres especiales, doble ejecución.
- [ ] Seguridad básica: parametrizado, salida escapada, sin `eval`/`shell=True`.
- [ ] Si va a git: `git add -A && git commit -m "tipo: mensaje" && git push origin main`.

## 2. Checklist final antes de entregar WEB/DISEÑO
**Accesibilidad (WCAG 2.2 AA)**: contraste 4.5:1/3:1 · navegación por teclado completa · `:focus-visible` · `alt` correctos · un `<h1>` sin saltos · `aria-label` en botones de icono · `prefers-reduced-motion` · labels y errores con `role="alert"` · áreas táctiles ≥44 px (mínimo 24 px).
**Responsive**: 320 / 768 / 1024 / 1440 sin scroll horizontal · texto base ≥16 px · imágenes `max-width:100%; height:auto`.
**Rendimiento**: sin dependencias innecesarias · imágenes con `width/height` y `loading="lazy"` (no en hero) · máx. 2 familias, `font-display: swap` · animaciones solo `transform`/`opacity`.
**SEO**: `<title>` ≤60, `meta description` ≤155, Open Graph + Twitter Card, `lang`, canonical, HTML semántico válido.
**Contenido**: cero lorem ipsum · CTAs con verbo específico · enlaces descriptivos · jerarquía clara · testimonios placeholder marcados.
**Entrega**: código completo y funcional + paleta HEX + tipografías + 2–4 líneas con decisiones + qué ajustar + 2–3 mejoras opcionales.

## 3. Modos de trabajo (cómo responder según el caso)
**MODO CÓDIGO**: Archivo → Dependencias → Código completo → RUN. Sin explicaciones salvo que se pidan.
**MODO FIXER** (usuario pega código con error): NO explicar. Devolver el archivo completo corregido. Antes: localizar causa raíz con el método de `07-bugs-catalogo.md`; corregir también bugs vecinos evidentes sin cambiar el comportamiento pedido; mantener estilo y nombres.
**MODO DISEÑO**: Archivo (`index.html`) → código completo en un solo archivo → Paleta HEX → Tipografías. Tendencias: bento, glass sutil, tipografía grande, micro-animaciones, copy real.
**MODO DISEÑO APPLE** (UI táctil / app web): seguir `09-estilo-apple.md`: lista agrupada, barra translúcida con título que colapsa, hoja arrastrable con resorte, tokens de marca, alternativas de accesibilidad. Entregar igual que MODO DISEÑO (archivo, código, paleta HEX, tipografías) y cerrar con el checklist de `09` §13.
**MODO MARKETING 1080×1080**: contenedor `1080×1080` px fijo; jerarquía: 1 titular dominante (≥96 px), 1 apoyo (≥40 px), 1 CTA (botón ≥64 px de alto), marca; margen de seguridad 72 px; paleta HEX exacta; contraste ≥4.5:1; exportación: captura a 1080×1080 o `html-to-image`/Puppeteer (`page.screenshot({clip:{x:0,y:0,width:1080,height:1080}})`).
**MODO REVISIÓN** (code review): ordenar hallazgos por severidad: 1) seguridad/pérdida de datos 2) bugs 3) rendimiento 4) mantenibilidad 5) estilo. Cada hallazgo: archivo:línea → problema → arreglo concreto en código.

## 4. Plantilla de prompt para delegar a otro agente (ahorra iteraciones)
```
ROL: <ingeniero backend / diseñador UI / auditor de seguridad>
OBJETIVO: <resultado verificable en 1 frase>
CONTEXTO: <stack y versiones, archivos relevantes, restricciones>
ENTRADAS: <datos/ejemplos exactos>
SALIDA ESPERADA: <formato exacto: archivo(s), estructura, comandos>
CRITERIOS DE ACEPTACIÓN: <lista comprobable: casos que deben pasar>
RESTRICCIONES: <no tocar X, sin dependencias nuevas, compatibilidad Y>
FUERA DE ALCANCE: <lo que NO debe hacer>
```
Buenas prácticas: dar ejemplos de entrada/salida; pedir un solo entregable por prompt; adjuntar el error completo y no un resumen; pedir al agente que declare supuestos al final en ≤3 líneas.

## 5. Estrategia para ahorrar prompts/iteraciones
1. Reúne TODO el contexto antes de pedir: versión, error literal, archivo completo, comportamiento esperado vs real.
2. Pide el entregable completo en una pasada (archivo íntegro), no por fragmentos.
3. Usa checklists de este directorio como criterios de aceptación en el mismo prompt.
4. Divide por responsabilidades y delega: diseño/copy → agente de diseño; código → agente de código; revisión de seguridad → agente auditor con `03-seguridad.md`.
5. Automatiza lo repetible: linters, formatters, tests y CI hacen revisiones sin gastar prompts.
6. Reutiliza plantillas y snippets (carpetas de skills/prompts) en vez de reexplicar el estilo cada vez.
7. Verifica datos dependientes de fecha con búsqueda una sola vez y guárdalos en el archivo correspondiente.

## 6. Plantillas de snippets base
**Reset CSS mínimo**
```css
*,*::before,*::after{box-sizing:border-box}
html{-webkit-text-size-adjust:100%;scroll-padding-top:5rem}
body{margin:0;font-family:var(--font-sans);font-size:var(--fs-base);line-height:var(--lh-base);color:var(--text);background:var(--bg)}
img,svg,video,canvas{display:block;max-width:100%;height:auto}
button,input,select,textarea{font:inherit;color:inherit}
:focus-visible{outline:3px solid var(--c-primary-500);outline-offset:2px}
.skip{position:absolute;left:-9999px}.skip:focus{left:1rem;top:1rem;z-index:100;background:var(--bg);padding:.5rem 1rem}
.visually-hidden{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
```
**Conmutador de tema persistente**
```js
const root = document.documentElement;
const saved = (() => { try { return localStorage.getItem("theme"); } catch { return null; } })();
const prefersDark = matchMedia("(prefers-color-scheme: dark)").matches;
root.classList.toggle("dark", saved ? saved === "dark" : prefersDark);
document.getElementById("theme-toggle")?.addEventListener("click", () => {
  const dark = root.classList.toggle("dark");
  try { localStorage.setItem("theme", dark ? "dark" : "light"); } catch {}
});
```
**Servidor local rápido**: `python3 -m http.server 8080` · `npx serve .`
**Python HTTP robusto**: `requests.Session()` con `Retry(total=3, backoff_factor=0.5, status_forcelist=[429,500,502,503,504])`, `timeout=(3.05, 10)`.
**Dockerfile Node (referencia)**
```dockerfile
FROM node:24-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:24-alpine
WORKDIR /app
ENV NODE_ENV=production
COPY --from=build /app/dist ./dist
COPY package*.json ./
RUN npm ci --omit=dev && addgroup -S app && adduser -S app -G app
USER app
EXPOSE 3000
CMD ["node", "dist/server.js"]
```

## 7. Glosario de severidad
- **Crítico**: pérdida de datos, ejecución remota, bypass de autenticación/autorización, secreto expuesto → bloquea entrega.
- **Alto**: bug visible en flujo principal, fuga de información, DoS fácil.
- **Medio**: bug en flujo secundario, rendimiento degradado, accesibilidad AA incumplida.
- **Bajo**: estilo, deuda técnica, mejoras opcionales.

## 8. Fuentes y cómo mantener esto actualizado
- Seguridad: owasp.org/Top10/2025 · cheatsheetseries.owasp.org · cwe.mitre.org/top25.
- Accesibilidad: w3.org/TR/WCAG22 · w3.org/WAI/ARIA/apg (patrones de componentes).
- Web: developer.mozilla.org (MDN) · web.dev · caniuse.com · developer.chrome.com.
- Versiones y soporte: nodejs.org/en/about/previous-releases · devguide.python.org/versions · endoflife.date.
- Revisar este directorio cada 3–6 meses; actualizar puntos marcados **[VERIFICAR]**.
