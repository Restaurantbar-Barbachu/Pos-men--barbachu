# 07 · Catálogo de bugs: síntoma → causa → arreglo

## A. Método de diagnóstico (usar SIEMPRE en este orden)
1. **Reproducir** de forma fiable (pasos mínimos, entrada exacta, entorno).
2. **Leer el error completo**: mensaje, tipo, archivo:línea, stack trace (de abajo hacia arriba: la primera línea de TU código es el sospechoso).
3. **Aislar**: bisección (comentar mitades, `git bisect`), reducir a un caso mínimo.
4. **Hipótesis única** → comprobar con log/breakpoint/test → confirmar o descartar. Una variable a la vez.
5. **Arreglar la causa raíz**, no el síntoma. Añadir test de regresión.
6. **Revisar el vecindario**: ¿el mismo patrón existe en otros lugares? (búsqueda global).
Regla: si llevas >30 min sin avanzar, explica el problema en voz alta paso a paso (rubber duck) o reduce el caso.
Herramientas: debugger (breakpoints condicionales), `console.table`, `logging` con contexto, DevTools (Network/Console/Performance/Memory), `git bisect`, `strace`/`curl -v`, `EXPLAIN`.

## B. Mensajes de error comunes
| Error | Causa típica | Arreglo |
|---|---|---|
| `TypeError: Cannot read properties of undefined (reading 'x')` (JS) | Objeto/array/resultado de API aún no existe | Optional chaining `a?.b`, valores por defecto, comprobar carga antes de renderizar, verificar la forma real de la respuesta |
| `X is not a function` | Importación incorrecta (default vs named), `this` mal enlazado, shadowing | Revisar `import {x}` vs `import x`; revisar nombre/ámbito |
| `ReferenceError: x is not defined` | Variable fuera de ámbito, script cargado antes que dependencia, typo | Orden de `<script>`, `defer`, declarar variable |
| `Uncaught SyntaxError: Unexpected token '<'` | Pidió JSON/JS y llegó HTML (404 o error de servidor) | Revisar URL/ruta en Network, `res.ok`, rutas relativas |
| `CORS policy: No 'Access-Control-Allow-Origin'` | Servidor no autoriza el origen | Cabeceras CORS en servidor; no se arregla desde el cliente (el modo `no-cors` da respuesta opaca) |
| `Failed to load module script: MIME type` | Servidor sirve `.js` como `text/html` o abres con `file://` | Servir con servidor local (`python -m http.server`, `npx serve`, Vite) |
| `net::ERR_BLOCKED_BY_CLIENT` | Adblock bloquea la URL (analytics, "ads" en el nombre) | Renombrar ruta/ probar sin extensiones |
| `Mixed Content blocked` | Recurso HTTP en página HTTPS | Usar HTTPS en todos los recursos |
| `Maximum call stack size exceeded` | Recursión sin caso base / ciclo en setState/getter | Caso base, memoizar, romper ciclo |
| `Hydration failed` (React/Next) | HTML de servidor ≠ cliente (fechas, `Math.random`, `window`) | Renderizar lo variable en `useEffect`; `suppressHydrationWarning` solo puntual |
| `Too many re-renders` | `setState` durante render / `onClick={fn()}` | `onClick={() => fn()}`; mover a efecto |
| `Module not found` / `ERR_MODULE_NOT_FOUND` | Dependencia no instalada, ruta o extensión mal, mayúsculas (Linux distingue) | `npm i`, revisar ruta y casing, `"type":"module"` y extensiones `.js` en ESM Node |
| `ModuleNotFoundError` (Python) | Entorno virtual distinto / paquete no instalado | Activar `.venv`; `python -m pip install ...` (mismo intérprete) |
| `IndentationError` / `TabError` | Mezcla de tabs y espacios | Solo 4 espacios; configurar editor |
| `UnicodeDecodeError` | Codificación del archivo | `encoding="utf-8"` (o detectar con `chardet`), `errors="replace"` si procede |
| `KeyError` / `IndexError` | Clave o índice inexistente | `dict.get(k, default)`, comprobar longitud, validar entrada |
| `AttributeError: 'NoneType' ...` | Una función devolvió `None` (olvidó `return`, búsqueda sin resultado) | Comprobar `None`, devolver explícitamente |
| `RecursionError` | Igual que stack overflow | Caso base / iterativo |
| `PermissionError` / `EACCES` | Permisos de archivo/puerto | Revisar propietario/`chmod`, ruta escribible; puertos <1024 requieren privilegios |
| `EADDRINUSE` / puerto ocupado | Otro proceso usa el puerto | `lsof -i :PORT` / `ss -ltnp`; matar proceso o cambiar puerto |
| `ENOENT` | Ruta inexistente o relativa al directorio equivocado | Rutas absolutas con `path.join(__dirname, ...)` / `pathlib` |
| `ECONNREFUSED` / `ETIMEDOUT` | Servicio caído, host/puerto erróneo, firewall, DNS | `curl -v`, comprobar servicio, `localhost` vs `127.0.0.1` vs contenedor |
| `npm ERR! ERESOLVE` | Conflicto de peer deps | Alinear versiones; `--legacy-peer-deps` solo como último recurso |
| `git: refusing to merge unrelated histories` | Repos con historiales distintos | `git pull --allow-unrelated-histories` (con criterio) |
| `git push rejected (non-fast-forward)` | Remoto tiene commits nuevos | `git pull --rebase origin main` y reintentar |
| `SQLSTATE duplicate key` | Violación de unicidad | `INSERT ... ON CONFLICT`, validar antes, manejar el error |
| `deadlock detected` | Dos transacciones se bloquean mutuamente | Orden consistente de locks, transacciones cortas, reintento |
| `OOM killed` / `MemoryError` | Datos completos en memoria / fuga | Streaming/chunks, límites, liberar referencias, perfilar |

## C. Bugs lógicos y de comportamiento
| Síntoma | Causas a revisar | Arreglo |
|---|---|---|
| "Funciona en mi máquina" | Versiones distintas, variables de entorno, SO (casing), datos | Fijar versiones, Docker, `.env.example`, CI |
| Resultado intermitente | Race condition, caché, zona horaria, orden no determinista | Hacer determinista; log con timestamps; bloqueo/atomicidad |
| Datos duplicados | Doble clic/doble envío, reintentos, falta de unicidad | Deshabilitar botón, idempotency key, constraint UNIQUE |
| Número raro (0.30000000000000004) | Float binario | Enteros/Decimal, redondeo al mostrar |
| Fecha un día corrida | UTC vs local, DST | Guardar UTC, convertir al mostrar, evitar `new Date("YYYY-MM-DD")` sin cuidado |
| Caracteres `Ã±`, `â€™` | Codificación mal interpretada | UTF-8 extremo a extremo (`<meta charset>`, BD, cabeceras) |
| Lista no refleja cambios (React/Vue) | Mutación directa | Estado inmutable |
| Datos viejos mostrados | Caché del navegador/CDN/Service Worker | Versionar assets, `Cache-Control`, actualizar SW |
| Bucle infinito de peticiones | Efecto que cambia su propia dependencia | Revisar dependencias; condición de salida |
| Estilo no se aplica | Especificidad, orden, caché, selector/typo, `!important` ajeno | DevTools → Computed/Styles; bajar especificidad; recarga forzada |
| Elemento no clicable | Otro elemento encima (z-index, overlay, `pointer-events`) | DevTools → inspeccionar; `pointer-events:none` en decorativos |
| `position: sticky` no funciona | Ancestro con `overflow` ≠ visible, sin `top` | Quitar overflow del ancestro; definir `top` |
| Desbordamiento horizontal en móvil | Elemento más ancho que viewport (imagen, tabla, `100vw` + scrollbar) | `max-width:100%`, `overflow-x:auto`, `100%` en vez de `100vw`, `min-width:0` |
| `z-index` ignorado | Falta `position` o contexto de apilamiento distinto | Crear/ajustar stacking context |
| Salto de contenido al cargar | Imágenes/fuentes sin reservar espacio | `width/height`, `aspect-ratio`, `font-display` |
| Formulario recarga la página | `<button>` dentro de `<form>` sin `type` | `type="button"` o `preventDefault()` |
| `localStorage` falla | Modo privado/cuota/SSR | `try/catch`, comprobar `typeof window` |
| Evento no dispara en elementos nuevos | Listener añadido antes de que existan | Delegación de eventos |
| Scroll bloqueado tras cerrar modal | Quedó `overflow:hidden` en body | Limpiar en cierre/`finally` |
| Imagen no carga | Ruta relativa/mayúsculas/ruta base | Ruta correcta, `<base>` o rutas absolutas desde raíz |

## D. Bugs específicos de ESP8266/ESP32
| Síntoma | Causa | Arreglo |
|---|---|---|
| Reinicio con `Soft WDT reset` | Bucle bloqueante o `delay()` largo | `yield()`, código no bloqueante, dividir tareas |
| Reinicio con `Exception (28/29)` + backtrace | Puntero nulo / memoria inválida | Decodificar con `EspExceptionDecoder`; revisar punteros, buffers |
| Se reinicia al conectar Wi-Fi o al usar relés | Alimentación insuficiente | Fuente ≥1 A, condensador, cables cortos, relé con alimentación propia |
| Se cuelga tras horas | Fragmentación de heap por `String` | `char[]`, `reserve()`, `F()`, monitorear `getFreeHeap()` |
| No guarda/lee archivos | LittleFS no montado / mal formateado / mal subido | Comprobar `begin()`, formatear, subir carpeta `data` |
| Pin no responde / boot falla | Pines de arranque (GPIO0, 2, 15 en ESP8266; strapping pins en ESP32) | Evitar o poner resistencias correctas |
| `ADC` ruidoso | Referencia/alimentación inestable | Promediar, condensador, filtro |
| OTA falla | Poca memoria flash libre / sin esquema de partición OTA / red inestable | Elegir esquema con OTA, liberar flash, señal estable |
| Portal cautivo no se abre en móvil | DNS no redirige todo / URLs de detección no respondidas | `DNSServer` con `*` → IP del AP; responder a `/generate_204`, `/hotspot-detect.html`, `/connecttest.txt` con redirección |
| WebSocket/Server cae con varios clientes | Poca RAM por conexión | Limitar clientes, mensajes pequeños, `AsyncWebServer` |
| Hora incorrecta | Sin RTC/NTP | `configTime()` con NTP y zona horaria |

## E. Prevención (reducir bugs desde el origen)
- Tipado estricto + linter + formateo automático en pre-commit.
- Validación en los bordes; funciones puras donde sea posible.
- Tests para bordes y errores; cada bug corregido deja su test.
- Revisión de código con checklist (archivo 08). PRs pequeños.
- Logs útiles desde el día 1 (sin datos sensibles) y métricas de errores en producción.
- Modo estricto del lenguaje/compilador activado (`"strict": true`, `-Wall -Wextra`, `mypy --strict`, `set -euo pipefail`).
