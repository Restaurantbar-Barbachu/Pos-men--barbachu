# 04 · Diseño UI/UX y accesibilidad

## 1. Proceso de diseño (orden fijo)
1. Objetivo de la página (1 acción principal) → 2. público → 3. jerarquía de contenido → 4. layout → 5. tokens (color, tipo, espacio) → 6. componentes → 7. estados e interacción → 8. revisión de accesibilidad y responsive.
Regla: **una sola acción primaria por pantalla**. Si todo destaca, nada destaca.

## 2. Jerarquía visual
- Herramientas, en orden de potencia: tamaño > peso > contraste > espacio en blanco > color > posición.
- Escala tipográfica modular (ratio 1.2–1.333): 12/14/16/20/24/32/48/64.
- Máximo 2 familias (display + sans); 3–4 pesos. Cuerpo 16–18 px, interlineado 1.5–1.7; titulares 1.1–1.2.
- Longitud de línea 45–75 caracteres (`max-width: 65ch`).
- Alineación a una cuadrícula; todo múltiplo de 4/8 px. Proximidad: más espacio entre grupos que dentro del grupo.
- Patrón de lectura: F en texto denso, Z en landing con pocos elementos. Primer pliegue: propuesta de valor + CTA + prueba (logos/cifra).

## 3. Tokens (fuente única de verdad)
- Todo color, tamaño, radio, sombra y duración como variable CSS en `:root`; modo oscuro redefine variables en `.dark` / `[data-theme="dark"]` / `@media (prefers-color-scheme: dark)`.
- Nada de colores hardcodeados fuera de los tokens. Tamaños con `clamp()`: `font-size: clamp(2.25rem, 1.7rem + 2.5vw, 3.5rem)`.
- Espaciado base 4 px: 4·8·12·16·24·32·48·64·96. Radios coherentes (6/10/16/24). Máx. 2–3 niveles de sombra.
- Semánticos separados de primitivos: `--bg`, `--text`, `--text-muted`, `--border`, `--primary`, `--danger`.

## 4. Color
- Estructura: 1 primario + 1 acento + neutros (escala 50–900) + semánticos (éxito/aviso/error). Regla 60-30-10 (neutro / secundario / acento).
- **Contraste WCAG**: texto normal ≥ 4.5:1; texto grande (≥24 px, o ≥18.66 px negrita) ≥ 3:1; componentes UI e iconos informativos ≥ 3:1.
- No comunicar solo con color (añadir icono/texto/patrón). Estado de error: color + icono + mensaje.
- Modo oscuro: no uses negro puro `#000` con blanco puro; usa fondo ~`#12151c` y texto ~`#f2f4f8`; reduce saturación de acentos; las sombras casi no se ven → usa bordes/superficies más claras para elevar.
- Gradientes: máximo 2–3 colores análogos; texto sobre gradiente comprobar contraste en el punto más claro.
- Herramientas: calculadora de contraste (WebAIM), `oklch()` para paletas perceptualmente uniformes, `color-mix()` para variantes.

## 5. Layout y responsive
- Mobile-first: estilos base = móvil; `min-width` para ampliar (480/768/1024/1280).
- Grid para 2D, Flexbox para 1D. `gap` en vez de márgenes entre hijos. `minmax()`, `auto-fit` para tarjetas: `grid-template-columns: repeat(auto-fit, minmax(min(100%, 18rem), 1fr))`.
- Container queries (`@container`) para componentes reutilizables que dependen de su caja, no de la ventana. Soporte ya amplio **[VERIFICAR en caniuse]**.
- Unidades: `rem` para tipografía/espacio, `%`/`fr` para ancho, `dvh` para altura móvil (evita el salto de la barra del navegador), `ch` para medidas de texto.
- Sin scroll horizontal: imágenes `max-width:100%; height:auto`; tablas en contenedor `overflow-x:auto`; `min-width:0` en hijos flex/grid con texto largo.
- Probar a 320, 375, 768, 1024, 1440. Zoom 200% sin pérdida de contenido (WCAG 1.4.4/1.4.10 reflow a 320 px).
- Safe areas en móvil: `padding-bottom: env(safe-area-inset-bottom)` con `viewport-fit=cover`.

## 6. Patrones de tendencia (cuándo y cómo)
| Patrón | Receta | Cuidado |
|---|---|---|
| **Bento grid** | Grid de tarjetas de tamaños distintos (`grid-template-columns: repeat(4,1fr)`, tarjetas con `col-span`/`row-span`), radios 20–28 px, 1 tarjeta héroe | En móvil colapsar a 1 columna; orden lógico del DOM |
| **Glassmorphism sutil** | `background: rgb(255 255 255 / .08); backdrop-filter: blur(14px) saturate(140%); border: 1px solid rgb(255 255 255 / .18)` | Contraste del texto sobre fondo variable; `backdrop-filter` costoso → pocas capas; fallback sin blur |
| **Tipografía enorme** | Titulares `clamp(2.75rem, 1.9rem + 4vw, 4.5rem)`, tracking negativo `-0.02em`, peso 600–700 | Máx. 2 líneas en móvil; no usar mayúsculas sostenidas |
| **Modo oscuro** | Variables + conmutador persistente, respetar `prefers-color-scheme` | Probar contraste en ambos temas |
| **Micro-interacciones** | Hover/focus/press 120–220 ms, easing `cubic-bezier(.22,.61,.36,1)` | Siempre con alternativa `prefers-reduced-motion` |
| **Neo-brutalismo / editorial** | Bordes gruesos, sombras duras, serif de display | Mantener jerarquía y legibilidad |

## 7. Componentes: estados obligatorios
Botón/enlace/input: normal · hover · `:focus-visible` · active · disabled · loading · error. Listas/datos: vacío · cargando (skeleton) · error con reintento · éxito.
- Botón primario: verbo concreto ("Crear cuenta gratis"), alto ≥ 44 px, radio coherente.
- Formularios: etiqueta visible siempre (no solo placeholder), ayuda bajo el campo, error junto al campo con `role="alert"` o `aria-describedby`, `autocomplete` correcto, `inputmode`/`type` apropiado, validación al salir del campo, no borrar lo escrito en error.
- Navegación: ≤7 ítems; estado activo marcado (`aria-current="page"`); menú móvil con `button` + `aria-expanded`.
- Modales: `<dialog>` nativo (`showModal()`), foco atrapado y devuelto, cierre con Esc, `aria-labelledby`.
- Tablas: `<th scope>`, `<caption>`, columnas numéricas alineadas a la derecha.
- Toasts: `role="status"` (no robar foco); errores críticos `role="alert"`.

## 8. UX: leyes aplicadas
- **Hick**: menos opciones → decisión más rápida. **Fitts**: objetivos grandes y cercanos. **Miller**: agrupar en bloques de ~5–9. **Jakob**: respeta convenciones (logo → inicio, carrito arriba a la derecha). **Proximidad/Similitud**: agrupar lo relacionado. **Efecto de posición serial**: lo importante al inicio y al final.
- Reducir fricción: menos campos (cada campo extra baja conversión), autocompletado, pago como invitado, mostrar progreso en flujos multi-paso.
- Feedback inmediato (<100 ms percibido); operaciones >1 s con indicador; >10 s con progreso real.
- Prevención de errores > mensajes de error. Acciones destructivas: confirmar o permitir deshacer.
- Confianza: prueba social con nombre y resultado, garantías, precios claros, microcopy que elimina miedo ("Sin tarjeta · Cancela cuando quieras").

## 9. Copywriting de conversión
- Titular = resultado + audiencia + diferenciador ("Factura en 30 segundos, no en 30 minutos").
- Subtítulo = cómo, en ≤2 líneas. CTA = lo que obtiene el usuario ("Ver demo en 2 min", no "Enviar").
- Features: Problema → acción → resultado medible. Testimonios: cifra + situación + nombre + rol + empresa (marcar placeholders).
- Frases ≤20 palabras, voz activa, sin signos de exclamación ni mayúsculas sostenidas. Cero lorem ipsum, cero genéricos ("soluciones innovadoras").

## 10. Accesibilidad — WCAG 2.2 nivel AA
**Novedades de 2.2** (respecto a 2.1): 2.4.11 *Focus Not Obscured (mín.)* AA · 2.5.7 *Dragging Movements* AA (alternativa sin arrastre) · 2.5.8 *Target Size (mín.)* AA (≥24×24 CSS px) · 3.2.6 *Consistent Help* A · 3.3.7 *Redundant Entry* A · 3.3.8 *Accessible Authentication (mín.)* AA (no exigir pruebas cognitivas; permitir pegar/gestores de contraseñas). El criterio 4.1.1 (Parsing) quedó obsoleto.
Recomendación práctica: áreas táctiles ≥ 44×44 px (meta AAA 2.5.5, mejor ergonomía).

**Principios POUR**: Perceptible · Operable · Comprensible · Robusto.

**Checklist técnico**
- HTML semántico primero (`<header> <nav> <main> <section> <article> <aside> <footer> <button> <a>`); ARIA solo cuando el HTML nativo no alcanza ("primera regla de ARIA: no uses ARIA si hay elemento nativo").
- Un `<h1>`; niveles sin saltos. Landmarks únicos con `aria-label` si se repiten (dos `<nav>`).
- "Saltar al contenido": primer enlace `<a href="#main" class="skip">`.
- Foco visible siempre: `:focus-visible { outline: 3px solid var(--ring-color); outline-offset: 2px }`. Nunca `outline:none` sin reemplazo. El foco no debe quedar tapado por cabeceras fijas (`scroll-padding-top`).
- Orden de tabulación = orden visual; evitar `tabindex` positivo; `tabindex="-1"` solo para foco programático.
- Imágenes: `alt` descriptivo; decorativas `alt=""`; SVG icónico con `aria-hidden="true"` si hay texto al lado, o `role="img" aria-label`.
- Botones solo-icono: `aria-label`. Enlaces con texto descriptivo ("ver precios"), no "clic aquí".
- Formularios: `<label for>`, `aria-describedby` para ayuda/errores, `aria-invalid="true"`, `required`, agrupar con `<fieldset><legend>`.
- Contenido dinámico: regiones `aria-live="polite"`; cambios de ruta SPA → mover foco al `<h1>` y actualizar `document.title`.
- Idioma: `<html lang="es">`; cambios de idioma con `lang` en el elemento.
- Movimiento: respetar `prefers-reduced-motion`; nada que parpadee >3 veces/s; carruseles con pausa.
- Zoom/texto: no bloquear zoom (`user-scalable=no` prohibido); unidades relativas; espaciado ajustable (1.4.12).
- Vídeo/audio: subtítulos, transcripción; sin autoplay con sonido.
- Contraste de foco y componentes ≥ 3:1.
- Probar: solo teclado, lector de pantalla (NVDA/VoiceOver), zoom 200–400 %, Lighthouse/axe (detectan ~30–40 % de problemas; el resto es manual).

## 11. Iconos e imágenes
- SVG inline o sprite para iconos; un solo set coherente (Lucide, Phosphor, Heroicons). Tamaño 16/20/24 px alineados a la línea base.
- Imágenes: AVIF/WebP + fallback, `srcset`/`sizes`, `width`/`height` explícitos (evita CLS), `loading="lazy"` salvo la imagen LCP (`fetchpriority="high"`), `decoding="async"`.
- Fondos con texto: overlay degradado para asegurar contraste.

## 12. Errores de diseño comunes → arreglo
| Error | Arreglo |
|---|---|
| Gris claro sobre blanco (contraste <4.5) | Subir a `#5b6472` o más oscuro |
| Placeholder como etiqueta | `<label>` visible |
| Botones diferentes en cada sección | Un componente con variantes (primary/secondary/ghost) |
| Párrafos a todo el ancho | `max-width: 65ch` |
| 5 estilos de titular | Escala de 4–5 niveles |
| Animación en cada elemento | Una sola coreografía de entrada; resto en hover |
| Hero con 3 CTAs iguales | 1 primario + 1 secundario de menor peso |
| Texto en imagen | Texto real en HTML |
| Altura fija en contenedores de texto | `min-height` o altura automática |
| Modal que atrapa en móvil | Botón cerrar ≥44 px, Esc, clic en fondo, scroll lock |

## 13. Estilo Apple (interfaces fluidas)
Para UI táctil con gestos, hojas, materiales translúcidos y tipografía óptica, ver `09-estilo-apple.md`. Reglas de contraste, foco y áreas táctiles de este archivo siguen vigentes; el estilo Apple añade respuesta inmediata, resortes y alternativas `prefers-reduced-transparency` / `prefers-contrast`.
