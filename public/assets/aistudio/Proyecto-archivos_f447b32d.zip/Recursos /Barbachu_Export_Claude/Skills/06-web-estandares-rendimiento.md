# 06 · Web: estándares, SEO y rendimiento

## 1. Esqueleto HTML5 correcto
```html
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Título descriptivo único (≤60 car.)</title>
  <meta name="description" content="Resumen accionable (≤155 car.)">
  <link rel="canonical" href="https://ejemplo.com/pagina">
  <meta name="theme-color" content="#3b6bff">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Título">
  <meta property="og:description" content="Descripción">
  <meta property="og:image" content="https://ejemplo.com/og.jpg"> <!-- 1200×630 -->
  <meta property="og:url" content="https://ejemplo.com/pagina">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip" href="#main">Saltar al contenido</a>
  <header>…</header>
  <main id="main">…</main>
  <footer>…</footer>
  <script src="app.js" defer></script>
</body>
</html>
```
- `viewport` sin `user-scalable=no`. `<script defer>` (o `type="module"`, que ya es diferido). Nunca scripts bloqueantes en `<head>`.
- Tailwind por CDN (`cdn.tailwindcss.com`) sirve para prototipos; en producción compila con la CLI/Vite para eliminar CSS no usado y evitar dependencia en runtime.

## 2. HTML semántico (reglas)
- Estructura por significado: `header`, `nav`, `main` (uno), `section` (con encabezado), `article`, `aside`, `footer`, `figure/figcaption`, `time datetime`, `address`.
- `<button>` para acciones, `<a href>` para navegación. Nunca `<div onclick>`.
- Listas reales (`ul/ol`) para conjuntos; tablas solo para datos.
- Formularios: `name`, `type` correcto (`email`, `tel`, `url`, `number`), `autocomplete`, `required`, `pattern` + validación servidor.
- Nativos modernos que reemplazan JS: `<dialog>`, `popover`, `<details>/<summary>`, `inert`, `loading="lazy"`, `<picture>`, `<search>`.

## 3. Core Web Vitals (umbrales "bueno", percentil 75)
| Métrica | Umbral bueno | Qué mide | Mejoras principales |
|---|---|---|---|
| **LCP** | ≤ 2.5 s | Carga del elemento principal | Imagen/hero optimizada (AVIF/WebP), `fetchpriority="high"` en la imagen LCP, sin lazy en ella, preload de fuente/imagen crítica, TTFB bajo (CDN, caché), CSS crítico |
| **INP** | ≤ 200 ms | Respuesta a interacciones (reemplazó a FID en 2024) | Dividir tareas largas (>50 ms) con `scheduler.yield()`/`setTimeout`, menos JS en hilo principal, `content-visibility:auto`, debounce de handlers, Web Workers |
| **CLS** | ≤ 0.1 | Estabilidad visual | `width`/`height` o `aspect-ratio` en imágenes/vídeos/iframes, reservar espacio para anuncios/embeds, `font-display: swap` + fuentes de métrica similar (`size-adjust`), no insertar contenido sobre el existente |
Medir: Lighthouse (laboratorio), PageSpeed Insights / CrUX (campo), `web-vitals` JS.

## 4. Checklist de rendimiento
- Presupuesto orientativo móvil: JS ≤ 170 KB comprimido, CSS ≤ 60 KB, imagen hero ≤ 150 KB, página total ≤ 1 MB para landing simple.
- Compresión Brotli/gzip; HTTP/2 o 3; caché con `Cache-Control: public, max-age=31536000, immutable` para assets con hash; HTML con `no-cache`/revalidación.
- Imágenes: tamaño real de visualización, `srcset`/`sizes`, formatos modernos, `loading="lazy"` + `decoding="async"` fuera del primer pliegue.
- Fuentes: subconjunto (`&text=` o `unicode-range`), máx. 2 familias, 2–4 pesos, `font-display: swap`; self-host reduce conexiones y mejora privacidad.
- JS: dividir por ruta, `defer`, eliminar librerías enteras por una función (lodash completo, moment → `Intl`/`Temporal`/date-fns), tree-shaking.
- CSS: sin frameworks completos cargados si usas el 5 %; `content-visibility:auto` + `contain-intrinsic-size` en secciones largas.
- Recursos de terceros: los más caros (chat, analítica, mapas). Carga bajo demanda (`facade` al clic), `async`, o elimínalos.
- `preconnect` solo a 1–2 orígenes críticos; `preload` solo a lo imprescindible (evitar sobre-preload).
- Speculation Rules / `prefetch` para navegación anticipada **[VERIFICAR soporte]**.
- Service worker + caché para PWA/offline: estrategia stale-while-revalidate para assets, network-first para HTML/datos; versionar caché y limpiar versiones viejas.

## 5. SEO técnico
- Un `<h1>` con la palabra clave principal natural; jerarquía lógica; URL corta y legible en minúsculas con guiones.
- `title` único por página; `meta description` persuasiva con CTA; `canonical` autorreferente.
- `sitemap.xml` + `robots.txt` (no bloquear CSS/JS); `noindex` en páginas de agradecimiento/admin.
- Datos estructurados JSON-LD (`Organization`, `LocalBusiness`, `Product`, `FAQPage`, `Article`, `BreadcrumbList`, `Restaurant` con `menu`, `openingHours`, `address`) validados en la herramienta de resultados enriquecidos.
- Contenido renderizado en servidor/estático (SSR/SSG) para que los rastreadores lo vean; SPA pura = riesgo.
- Móvil-first indexing: mismo contenido en móvil y escritorio.
- Imágenes con `alt` descriptivo y nombres de archivo significativos. Enlaces internos con texto ancla descriptivo.
- Negocio local: ficha de Google Business Profile coherente (NAP: nombre, dirección, teléfono), `LocalBusiness` schema, reseñas, horarios actualizados.
- hreflang para multi-idioma; `lang` correcto.

## 6. PWA y almacenamiento
- Manifest: `name`, `short_name`, `start_url`, `display`, `icons` (192/512, maskable), `theme_color`.
- Almacenamiento: `localStorage` (síncrono, ~5 MB, solo texto, evitar datos sensibles) · `IndexedDB` (estructurado, grande, asíncrono) · Cache API (respuestas) · cookies (servidor, pequeñas). No guardes secretos en el cliente.
- Estado de red: manejar `offline`/errores de fetch con mensaje útil y reintento.

## 7. Compatibilidad
- Mejora progresiva: base funcional sin JS/CSS moderno; añade capas con `@supports` y detección de características.
- Verificar soporte en caniuse/MDN Baseline antes de usar APIs recientes; ofrecer fallback.
- Pruebas mínimas: Chrome, Safari iOS (el más restrictivo), Firefox. Safari iOS: `100vh` → `100dvh`, `position:fixed` + teclado, `backdrop-filter` con prefijo `-webkit-`, inputs <16 px provocan zoom.

## 8. Formularios con envío (sin servidor propio)
- Opciones: Formspree/Web3Forms/Basin, Netlify Forms, `mailto:` (mala UX), webhook a WhatsApp/Telegram vía función serverless.
- Anti-spam: campo honeypot oculto, `rate limit`, reCAPTCHA/hCaptcha/Turnstile si hay abuso.
- Siempre: estado de carga, éxito y error visibles (`aria-live`), deshabilitar el botón durante el envío (evita doble envío), validar en servidor.

## 9. Estructura de entrega (proyecto web estático)
```
/index.html
/css/styles.css        (tokens en :root, componentes, utilidades)
/js/app.js             (módulos pequeños, defer)
/assets/img|fonts|icons
/robots.txt  /sitemap.xml  /favicon.svg  /manifest.webmanifest
```
Despliegue estático: GitHub Pages / Netlify / Vercel / Cloudflare Pages (HTTPS automático, CDN). Dominio propio + redirección www ↔ apex + HSTS.
