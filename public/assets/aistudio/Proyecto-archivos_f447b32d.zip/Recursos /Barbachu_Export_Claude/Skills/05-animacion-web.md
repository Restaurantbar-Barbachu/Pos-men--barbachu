# 05 · Animación web

## 1. Reglas de oro
1. **Solo anima `transform` y `opacity`** (compositor/GPU, sin layout ni repaint). Evita animar `width`, `height`, `top`, `left`, `margin`, `box-shadow` y `filter` pesados.
2. **Propósito**: guiar atención, dar feedback, explicar cambios de estado. Si no cumple una función, quítala.
3. **Duración**: micro-interacciones 120–220 ms; entradas de elemento 300–500 ms; transiciones de página/escena 400–700 ms. >800 ms se siente lento.
4. **Easing**: entradas `ease-out` (`cubic-bezier(.22,.61,.36,1)`), salidas `ease-in`, movimiento continuo `ease-in-out`; nunca `linear` salvo loops/progreso. Muelles solo con librerías.
5. **Accesibilidad**: respetar `prefers-reduced-motion`; no parpadeos; permitir pausar animaciones >5 s.
6. **Rendimiento**: objetivo 60 fps (16.6 ms/frame); si dudas, mide en el panel Performance.

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
    scroll-behavior: auto !important;
  }
}
```
(Uno de los pocos usos de `!important` justificado: utilidad de accesibilidad.)

## 2. Elegir la herramienta
| Necesidad | Herramienta |
|---|---|
| Hover/focus/estados simples | CSS `transition` |
| Entradas, loops, keyframes | CSS `@keyframes` |
| Secuencias controlables por JS (play/pause/reverse) | **Web Animations API** (`element.animate()`) |
| Animar al hacer scroll sin JS | **CSS scroll-driven animations** (`animation-timeline: view()` / `scroll()`) **[VERIFICAR soporte]** |
| Transiciones entre páginas/estados DOM | **View Transitions API** (`document.startViewTransition`, `@view-transition`) **[VERIFICAR soporte]** |
| Timelines complejas, SVG morph, scroll pinning | **GSAP** (+ ScrollTrigger) |
| Animaciones de UI React con gestos/layout | **Motion** (antes Framer Motion) |
| Ilustración vectorial animada | **Lottie** / SVG + SMIL/CSS / Rive para interactivas |
| 3D / shaders | **Three.js**, WebGL/WebGPU |

## 3. Patrones listos
**Aparición al hacer scroll (con IntersectionObserver, sin dependencias)**
```css
.reveal { opacity: 0; transform: translateY(16px); transition: opacity .5s var(--ease), transform .5s var(--ease); }
.reveal.is-visible { opacity: 1; transform: none; }
```
```js
const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); }
  }
}, { threshold: 0.15, rootMargin: "0px 0px -10% 0px" });
document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
```
Escalonado: `style="transition-delay: calc(var(--i) * 60ms)"`. Contenido visible sin JS: añade la clase `js` al `<html>` y aplica el estado oculto solo bajo `.js .reveal`.

**Scroll-driven nativo (mejora progresiva)**
```css
@supports (animation-timeline: view()) {
  .card { animation: rise linear both; animation-timeline: view(); animation-range: entry 0% entry 60%; }
  @keyframes rise { from { opacity: 0; transform: translateY(24px) } to { opacity: 1; transform: none } }
}
```
**Barra de progreso de lectura**: `animation-timeline: scroll(root)` sobre `transform: scaleX()` con `transform-origin: left`.

**Entrada de elementos nuevos/`display` animable**: `@starting-style` y `transition-behavior: allow-discrete` permiten animar entrada/salida de `dialog`/popover **[VERIFICAR soporte]**.
```css
dialog[open] { opacity: 1; transform: none; transition: opacity .25s, transform .25s, display .25s allow-discrete, overlay .25s allow-discrete; }
@starting-style { dialog[open] { opacity: 0; transform: translateY(8px) } }
dialog { opacity: 0; transform: translateY(8px) }
```
**WAAPI**
```js
const anim = el.animate(
  [{ transform: "translateY(12px)", opacity: 0 }, { transform: "none", opacity: 1 }],
  { duration: 350, easing: "cubic-bezier(.22,.61,.36,1)", fill: "both" }
);
await anim.finished; // cancel(), reverse(), pause()
```
**Hover de tarjeta**: `transform: translateY(-4px)` + sombra cambiada vía pseudo-elemento con `opacity` (evita animar `box-shadow`).
**Botón con press**: `:active { transform: scale(.98) }` 80–120 ms.
**Skeleton**: gradiente que se desplaza con `transform: translateX()` sobre un pseudo-elemento, no animando `background-position` (repaint).
**Cursor/parallax**: `requestAnimationFrame` + `transform: translate3d`; throttling; desactivar en táctil y con reduced motion.
**Texto**: revelar por línea/palabra con spans y `transition-delay`; mantener texto real accesible (`aria-label` en el contenedor, `aria-hidden` en los spans si se parte por letra).
**Marquee/loop**: `@keyframes` con `translateX(-50%)` y contenido duplicado; pausa en hover/foco; `prefers-reduced-motion` lo detiene.

## 4. GSAP (cuando CSS no alcanza)
```js
gsap.registerPlugin(ScrollTrigger);
const mm = gsap.matchMedia();
mm.add("(prefers-reduced-motion: no-preference)", () => {
  gsap.from(".hero > *", { y: 24, opacity: 0, duration: .6, ease: "power3.out", stagger: .08 });
  gsap.to(".bar", { scaleX: 1, ease: "none", scrollTrigger: { trigger: ".article", start: "top top", end: "bottom bottom", scrub: true } });
});
```
- Usa `gsap.context()`/`matchMedia` para limpiar en SPAs; `ScrollTrigger.refresh()` tras cargar imágenes/fuentes.
- `will-change: transform` solo en elementos que de verdad animan, y retíralo al terminar (consume memoria).
- Carga por CDN con versión fijada y SRI; si el resultado se logra con CSS, no añadas la librería.

## 5. View Transitions (resumen)
```css
@view-transition { navigation: auto; }           /* MPA, mismo origen */
::view-transition-old(root) { animation: fade-out .25s both }
::view-transition-new(root) { animation: fade-in .25s both }
.hero-img { view-transition-name: hero; }          /* nombre único por página */
```
```js
if (document.startViewTransition) document.startViewTransition(() => actualizarDOM());
else actualizarDOM();
```
Nombres de transición únicos; respeta reduced motion; fallback sin animación.

## 6. Rendimiento y depuración
| Síntoma | Causa | Arreglo |
|---|---|---|
| Jank en scroll/animación | Animas propiedades de layout | Pasar a `transform`/`opacity` |
| Parpadeo al iniciar | FOUC / estado inicial no definido | Estado inicial en CSS; `animation-fill-mode: both` |
| Animación se corta en móvil | `backdrop-filter`/`filter: blur` grande | Reducir área/radio, quitar en móvil |
| Texto borroso tras `transform` | Subpíxel | `translateZ(0)` con cuidado o valores enteros; evita `scale` fraccional en texto |
| Memoria alta | Demasiados `will-change`/capas | Limitar a lo necesario |
| Animación no arranca | Elemento `display:none` o `ScrollTrigger` calculado antes de cargar | Animar `opacity`; `refresh()` |
| Se dispara dos veces | Observer sin `unobserve`, StrictMode en dev | Quitar observer; limpiar en `useEffect` |
| Salta el scroll (CLS) | Animar `height` con contenido | `grid-template-rows: 0fr → 1fr` para expandir |
- Acordeón fluido sin JS de medición: `.panel{display:grid;grid-template-rows:0fr;transition:grid-template-rows .3s}.panel.open{grid-template-rows:1fr}` con hijo `overflow:hidden`.
- Herramientas: Chrome DevTools → Performance, Rendering (Paint flashing, FPS meter), Layers; `PerformanceObserver` para long frames.

## 7. Dirección de arte de motion (coherencia)
- Un solo lenguaje de movimiento: misma curva, mismo rango de duración, misma distancia (12–24 px) en toda la web.
- Jerarquía temporal: lo importante entra primero; escalonado 40–80 ms; máx. 6–8 elementos escalonados.
- Dirección con sentido: elementos que "vienen" desde donde el usuario actuó (origen del clic).
- Feedback > decoración: prioriza estados (hover, press, loading, success) sobre efectos de entrada.
- Carga: skeletons + transición suave a contenido real; evitar spinners infinitos sin contexto.

## 8. Gestos y física (resortes)
CSS `transition`/`@keyframes` sirven para estados simples (hover, aparición). Para todo lo que el usuario **agarra o lanza** (sheets, carruseles, arrastre) usa resortes con entrega de velocidad, proyección de impulso y bordes elásticos: ver `09-estilo-apple.md` §2–§3 (código `spring`, `project`, `rubber`). Regla de decisión: ¿se puede interrumpir a mitad? Si sí, resorte; si no, CSS.
