# 02 · Lenguajes: reglas y trampas

Versiones (verificadas oct-2026): Node.js 24 = Active LTS (soporte hasta 30-abr-2028); Node 26 pasa a LTS el 28-oct-2026; Node 20 sin soporte desde 30-abr-2026; Node 25 EOL. **[VERIFICAR]** antes de fijar versión en Docker/CI.

## PYTHON 3
**Reglas**
- Tipado: `def f(x: int, y: str | None = None) -> list[str]:`; verifica con `mypy --strict` o `pyright`.
- `pathlib.Path` en vez de concatenar rutas; `with open(p, encoding="utf-8") as f:` siempre con encoding.
- `dataclass(frozen=True, slots=True)` para datos; `Enum` para constantes; `logging`, no `print`, en código de servicio.
- Entorno: `python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`. Fija versiones (`pip freeze`, `uv`, `poetry`).
- Punto de entrada: `if __name__ == "__main__": raise SystemExit(main())`; `main()` devuelve código de salida (0 ok, ≠0 error).
- Subprocesos: `subprocess.run([...], check=True, capture_output=True, text=True, timeout=30)`; **nunca** `shell=True` con entrada de usuario.
- Aleatoriedad de seguridad: módulo `secrets`, no `random`.
- Hash de contraseñas: `argon2-cffi` o `bcrypt`; nunca MD5/SHA1/SHA256 solo.
- SQL: consultas parametrizadas (`cur.execute("SELECT * FROM u WHERE id=?", (uid,))`).
- Serialización: `json`; **nunca** `pickle.loads` de fuentes no confiables; `yaml.safe_load`, no `yaml.load`.
- Red: `requests`/`httpx` siempre con `timeout=` y `raise_for_status()`.

**Trampas frecuentes**
| Trampa | Síntoma | Arreglo |
|---|---|---|
| Argumento mutable por defecto `def f(a=[])` | La lista persiste entre llamadas | `a: list | None = None; a = a or []` |
| Cierre tardío en bucles (`lambda: i`) | Todas usan el último `i` | `lambda i=i: i` o `functools.partial` |
| `except:` / `except Exception: pass` | Errores tragados, bug invisible | Captura específica + log + relanza |
| `is` para comparar valores | `x is 1000` falso | `==`; `is` solo con `None`/singletons |
| Modificar lista mientras se itera | Elementos saltados | Iterar sobre copia o construir nueva lista |
| `float` para dinero | `0.1+0.2 != 0.3` | `decimal.Decimal` |
| Fechas naive | Errores por zona horaria | `datetime.now(timezone.utc)` / `zoneinfo` |
| Import circular | `ImportError` parcial | Extraer módulo común; importar dentro de la función |
| `asyncio.run` dentro de loop activo | `RuntimeError` | `await` directo o `asyncio.create_task` |
| Bloqueo en `async def` (`time.sleep`, `requests`) | Congela todo el loop | `await asyncio.sleep`, `httpx.AsyncClient`, `asyncio.to_thread` |
| GIL en CPU pesada con hilos | Sin aceleración | `multiprocessing` / `ProcessPoolExecutor` |
| Leer archivo enorme entero | Memoria | Iterar línea a línea / chunks |

**Plantilla de script robusto**
```python
#!/usr/bin/env python3
from __future__ import annotations
import argparse, logging, sys
from pathlib import Path

log = logging.getLogger(__name__)

def run(path: Path) -> int:
    if not path.is_file():
        log.error("No existe: %s", path)
        return 2
    try:
        data = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        log.error("No se pudo leer %s: %s", path, e)
        return 1
    print(len(data.splitlines()))
    return 0

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("path", type=Path)
    args = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    return run(args.path)

if __name__ == "__main__":
    sys.exit(main())
```

## JAVASCRIPT / TYPESCRIPT
**Reglas**
- `const` por defecto, `let` si reasignas, nunca `var`. `===` siempre. ES modules (`import`/`export`).
- TypeScript con `"strict": true`. Evita `any`; usa `unknown` + estrechamiento (type guards, Zod).
- Node ≥22.18 ejecuta `.ts` quitando tipos sin compilar, pero **no verifica tipos**: corre `tsc --noEmit` en CI.
- `async/await` con `try/catch`; en promesas sueltas, `.catch()`; manejar `unhandledRejection` en servidores.
- `fetch` no lanza en 4xx/5xx: comprueba `res.ok`. Usa `AbortController` para timeout/cancelación.
- Copia profunda: `structuredClone(obj)`, no `JSON.parse(JSON.stringify())` (pierde fechas, `undefined`, `Map`).
- Dinero/precisión: enteros en centavos o `BigInt`/librería decimal.
- DOM: `textContent` para texto; `innerHTML` solo con HTML sanitizado (DOMPurify). Delegación de eventos para listas dinámicas.
- Orden de paquetes: `npm ci` (reproducible) en CI; `npm audit`; lockfile siempre versionado.

**Trampas frecuentes**
| Trampa | Síntoma | Arreglo |
|---|---|---|
| `this` perdido en callbacks | `undefined` | Arrow function o `.bind` |
| `var` en bucles con closures | Todos ven el último valor | `let` |
| `forEach` con `await` | No espera | `for...of` + `await` o `Promise.all(arr.map(...))` |
| `Promise.all` falla por uno | Pierdes los demás | `Promise.allSettled` |
| `parseInt("08")`/sin radix | Resultados raros | `Number()` o `parseInt(x,10)` |
| `==` con tipos mixtos | `"0"==false` true | `===` |
| `sort()` numérico | Orden lexicográfico | `arr.sort((a,b)=>a-b)` |
| Mutar estado React directamente | UI no actualiza | Nuevo objeto/array (`[...a, x]`) |
| `useEffect` sin deps o deps incompletas | Bucle infinito / datos viejos | Declarar dependencias; limpiar en retorno |
| `key={index}` en listas reordenables | Estado mezclado | `key` estable (id) |
| Fugas: listeners/timers sin quitar | Memoria crece | `removeEventListener`, `clearInterval`, `AbortController` |
| Fecha `new Date("2026-10-22")` | Interpreta UTC, se ve día anterior | Construir con partes o `Temporal` **[VERIFICAR soporte]** |
| CORS | Error en navegador, no en curl | Configurar cabeceras en servidor; nunca `*` con credenciales |
| Race en búsquedas (respuestas desordenadas) | Resultado viejo gana | Cancelar con `AbortController` / comparar id de petición |

**Plantilla fetch robusto**
```js
export async function getJSON(url, { timeoutMs = 8000 } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    if (!res.ok) throw new Error(`HTTP ${res.status} en ${url}`);
    return await res.json();
  } catch (err) {
    if (err.name === "AbortError") throw new Error(`Timeout tras ${timeoutMs} ms`);
    throw err;
  } finally {
    clearTimeout(t);
  }
}
```

## SQL
- Siempre parametrizado. `SELECT` con columnas explícitas (no `*` en producción).
- `NULL`: usa `IS NULL`; `NOT IN` con NULL devuelve vacío → usa `NOT EXISTS`.
- `LIMIT` sin `ORDER BY` es no determinista.
- `UPDATE`/`DELETE` sin `WHERE` = desastre: escribe primero el `SELECT` equivalente y revisa conteo; usa transacción (`BEGIN … ROLLBACK/COMMIT`).
- Índice no se usa si envuelves la columna en función (`WHERE LOWER(email)=…`) → índice funcional o normaliza al guardar.
- Paginación grande: keyset (`WHERE id > :last ORDER BY id LIMIT 50`) en vez de `OFFSET` enorme.

## BASH / SHELL
- Cabecera: `#!/usr/bin/env bash` + `set -Eeuo pipefail` + `IFS=$'\n\t'`.
- Comillas SIEMPRE en variables: `"$var"`. Rutas con espacios rompen sin ellas.
- `[[ ... ]]` en bash; `command -v tool >/dev/null || { echo "falta tool" >&2; exit 1; }`.
- `trap 'cleanup' EXIT` para limpiar temporales. `mktemp` para archivos temporales.
- Nunca `rm -rf "$DIR/"` sin validar que `$DIR` no está vacío (`${DIR:?}`).
- Valida con `shellcheck`.

## C++ / ARDUINO — ESP8266 / ESP32 (proyectos de microcontrolador)
**Reglas**
- No bloquees el `loop()`: evita `delay()` largos; usa `millis()` (patrón no bloqueante). Bloqueos >~3 s disparan el watchdog (reinicio). Dentro de bucles largos llama `yield()`.
- Memoria (ESP8266 ≈ 40–50 KB de heap útil): `F("texto")` y `PROGMEM` para cadenas constantes; evita `String` concatenado en bucles (fragmenta heap) → `char[]`/`snprintf` o `reserve()`.
- Vigila `ESP.getFreeHeap()` y `ESP.getMaxFreeBlockSize()`; si cae con el tiempo = fuga/fragmentación.
- Wi-Fi: reconexión automática (`WiFi.setAutoReconnect(true)`), comprobar `WiFi.status()` en el loop; portal cautivo con `DNSServer` + `ESPAsyncWebServer`.
- Archivos web en LittleFS (no SPIFFS, obsoleto en ESP8266); `LittleFS.begin()` comprobando el retorno.
- Servidor web asíncrono: no hagas trabajo pesado dentro del callback; marca una bandera y procesa en `loop()`.
- OTA: `ArduinoOTA.setPassword(...)`; nunca OTA sin contraseña en red de clientes.
- Credenciales fuera del código fuente publicado (archivo no versionado o configuración guardada en LittleFS).
- Entradas analógicas ruidosas: promediar N lecturas; botones: antirrebote (≥20–50 ms).
- JSON: `ArduinoJson` con `JsonDocument` dimensionado; comprueba el resultado de `deserializeJson`.
- Alimentación: picos de Wi-Fi (~300 mA); condensador 100–470 µF cerca del módulo; fuente ≥1 A. Reinicios aleatorios suelen ser alimentación.

**Patrón no bloqueante**
```cpp
unsigned long previo = 0;
const unsigned long INTERVALO = 1000;

void loop() {
  unsigned long ahora = millis();
  if (ahora - previo >= INTERVALO) {   // resta segura ante desbordamiento
    previo = ahora;
    tarea();
  }
  yield();
}
```

## GO / RUST / JAVA / C# (referencia corta)
- **Go**: comprueba `err` siempre; `defer` para liberar; `context.Context` primer parámetro; goroutines con control de salida (`WaitGroup`/`errgroup`); `go vet` + `staticcheck`; no compartas memoria sin mutex/canal.
- **Rust**: `Result`/`?` en vez de `unwrap()` en producción; `clippy`; ownership evita data races en tiempo de compilación; `cargo audit`.
- **Java/Kotlin**: `try-with-resources`; `Optional` en retornos, no en campos; inmutabilidad (`record`); no atrapar `Exception` genérica.
- **C#**: `async` hasta el final (no `.Result`/`.Wait()`); `using`; nullable reference types activados; `CancellationToken` en APIs async.

## REGLAS DE ESTILO COMUNES
- Nombres que revelan intención (`totalConIva`, no `t2`); booleanos como pregunta (`isValid`, `hasAccess`).
- Constantes con nombre en vez de números mágicos.
- Retorno temprano (guard clauses) en vez de `if` anidados >3 niveles.
- Una sola fuente de verdad por dato. Sin código muerto ni comentado.
- Formateo automático: Prettier/ESLint (JS/TS), Ruff/Black (Python), gofmt, rustfmt; no discutas estilo a mano.
