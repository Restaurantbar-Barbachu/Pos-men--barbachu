# Base de conocimiento de ingeniería — ÍNDICE (leer primero)

Destinatario: otra IA/agente que genera o revisa código, diseño, animación y seguridad.
Idioma: español. Actualizado: 22-oct-2026. Formato: reglas accionables, no teoría.

## Cómo usar esta carpeta
1. Identifica la tarea y carga SOLO el archivo que aplica (ahorra contexto).
2. Antes de entregar, ejecuta `08-checklists-y-plantillas.md`.
3. Si un dato depende de versión/fecha (versiones, soporte de navegadores, CVEs), VERIFÍCALO con búsqueda; los archivos marcan esos puntos con **[VERIFICAR]**.

## Router de tareas
| Tarea | Archivo |
|---|---|
| Arquitectura, flujo de trabajo, git, tests, errores | `01-ingenieria-y-arquitectura.md` |
| Escribir/arreglar código (Python, JS/TS, SQL, Bash, C++/ESP8266) | `02-lenguajes-reglas-y-trampas.md` |
| Seguridad (OWASP 2025, auth, secretos, XSS, SQLi, supply chain, IA) | `03-seguridad.md` |
| UI/UX, tokens, tipografía, color, accesibilidad WCAG 2.2 | `04-diseno-ui-ux-accesibilidad.md` |
| Animación y motion (CSS, WAAPI, scroll, GSAP, rendimiento) | `05-animacion-web.md` |
| HTML semántico, SEO, Core Web Vitals, rendimiento | `06-web-estandares-rendimiento.md` |
| Diagnóstico de bugs: catálogo síntoma → causa → arreglo | `07-bugs-catalogo.md` |
| Checklists finales, plantillas de prompt, modo fixer | `08-checklists-y-plantillas.md` |
| **Estilo Apple**: gestos, resortes, sheets, materiales translúcidos, tipografía, UI tipo app | `09-estilo-apple.md` |

## Reglas globales (aplican siempre)
1. Entrega archivos completos y ejecutables; nunca `...`, TODO ni placeholders.
2. Valida toda entrada externa; maneja errores explícitamente; nunca `except:` vacío ni `catch {}` mudo.
3. Cero secretos en código. Cero `eval`/`innerHTML` con datos no confiables.
4. Accesible por defecto (teclado, contraste, `prefers-reduced-motion`).
5. Anima solo `transform` y `opacity`. Mobile-first. Sin dependencias innecesarias.
6. Si modificas código ajeno: cambio mínimo, mismo estilo, sin refactors no pedidos.
7. UI táctil o "tipo app": aplica `09-estilo-apple.md` (respuesta inmediata, gestos 1:1, resortes, materiales) y abre el SKILL.md correspondiente en `skills-style-Apple/skills/`.
8. Si algo es incierto y verificable, busca; no inventes APIs, flags ni versiones.

## Skills de referencia (carpeta `skills-style-Apple/`)
Contiene 15 skills con detalle completo (`skills/<nombre>/SKILL.md`), más `performance-cheatsheet.md`. La tabla "qué skill abrir según la tarea" está en `09-estilo-apple.md` §12. Se pueden subir a claude.ai (un zip por skill) o copiar a `~/.claude/skills/` en Claude Code.
