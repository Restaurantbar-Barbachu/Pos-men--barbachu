# 03 · Seguridad

## 1. OWASP Top 10:2025 (publicada nov-2025) — con defensa concreta
| # | Categoría | Qué es | Defensa mínima |
|---|---|---|---|
| A01 | **Broken Access Control** (incluye SSRF, fusionado en 2025) | Usuario accede a lo que no debe (IDOR, rutas admin, escalada) | Autorización en servidor en CADA petición; denegar por defecto; comprobar propietario del recurso (`WHERE id=? AND owner=?`); no confiar en IDs/roles del cliente; para SSRF: lista blanca de destinos, bloquear IPs internas/metadata cloud |
| A02 | **Security Misconfiguration** | Defaults inseguros, debug activo, buckets públicos, cabeceras ausentes | Hardening repetible (IaC), desactivar debug/listados, cabeceras de seguridad, borrar cuentas/puertos por defecto |
| A03 | **Software Supply Chain Failures** (nueva) | Dependencias/build/CI comprometidos | Lockfiles, `npm ci`, verificar integridad, SBOM, escaneo (`npm audit`, `pip-audit`, Dependabot/Renovate), fijar acciones de CI por SHA, mínimo de dependencias, antigüedad mínima de versiones nuevas |
| A04 | **Cryptographic Failures** | Datos sin cifrar, algoritmos débiles, claves mal gestionadas | TLS 1.2+ (1.3 preferido), AES-GCM/ChaCha20, Argon2id/bcrypt para contraseñas, claves en gestor de secretos, nunca cripto propia |
| A05 | **Injection** | Entrada interpretada como código (SQL, NoSQL, OS, LDAP, XSS) | Consultas parametrizadas, ORM, codificación de salida según contexto, `execFile`/lista de args (no shell), validación de esquema |
| A06 | **Insecure Design** | Fallo de diseño, no de código | Modelado de amenazas (STRIDE), casos de abuso, límites de tasa, separación de privilegios desde el diseño |
| A07 | **Authentication Failures** | Credenciales débiles, sesiones mal gestionadas, sin MFA | MFA, límite de intentos, contraseñas largas (no reglas absurdas), rotar sesión al login, cookies seguras, bloquear contraseñas filtradas |
| A08 | **Software or Data Integrity Failures** | Actualizaciones/artefactos/deserialización sin verificar | Firmas/hash de artefactos, no deserializar datos no confiables, CI protegido, SRI en scripts de CDN |
| A09 | **Security Logging & Alerting Failures** | No se detecta ni alerta | Registrar login, fallos de acceso, cambios de privilegio; alertas accionables; logs inmutables; sin datos sensibles en logs |
| A10 | **Mishandling of Exceptional Conditions** (nueva) | Errores mal manejados: fallan abiertos, filtran info, estados inconsistentes | Fallar **cerrado** (denegar ante error), manejo global de excepciones, mensajes genéricos al usuario, transacciones con rollback, probar rutas de error |

Nota práctica: A10 implica que `catch` vacío, errores tragados y "si falla la validación, continúa" son vulnerabilidades, no solo malas prácticas.

## 2. Entrada y salida
- **Validar** (lista blanca: tipo, longitud, rango, formato) en el servidor; la validación del cliente es solo UX.
- **Codificar en la salida** según contexto: HTML, atributo, JS, URL, CSS, SQL. Una sola función de escape no sirve para todos.
- XSS: `textContent`, plantillas con autoescape, DOMPurify para HTML enriquecido, **CSP** estricta.
- SQLi: parametrización; nunca concatenar. Los nombres de tablas/columnas dinámicos → lista blanca.
- Command injection: evita shell; pasa argumentos como lista; valida contra lista blanca.
- Path traversal: resolver ruta canónica y comprobar que cae dentro del directorio base (`resolve()` + `is_relative_to`).
- Subida de archivos: validar tipo por contenido (magic bytes) + extensión + tamaño; renombrar con UUID; guardar fuera de la raíz web; no ejecutable.
- Deserialización: JSON con esquema; nunca `pickle`, `eval`, `unserialize` sobre entrada externa.
- Redirecciones: lista blanca de destinos (open redirect).
- SSRF: resolver DNS y verificar IP pública antes de conectar; bloquear `169.254.169.254`, `localhost`, rangos privados.

## 3. Autenticación y sesiones
- Contraseñas: **Argon2id** (preferido) o bcrypt (coste ≥12); sal única automática; comparar en tiempo constante.
- MFA (TOTP/WebAuthn-passkeys) para cuentas con privilegios; passkeys como opción principal moderna.
- Cookies de sesión: `HttpOnly; Secure; SameSite=Lax` (o `Strict`), prefijo `__Host-`, expiración, regenerar ID tras login, invalidar en logout.
- Anti-CSRF: token por sesión/petición o `SameSite` + comprobación de `Origin` en métodos que mutan.
- JWT: algoritmo fijado en servidor (rechazar `none`), expiración corta (≤15 min) + refresh rotatorio, validar `iss`/`aud`/`exp`; no guardar datos sensibles en el payload (está codificado, no cifrado); preferir sesiones de servidor si no necesitas stateless.
- OAuth2/OIDC: Authorization Code + **PKCE**; validar `state` y `nonce`; redirect URIs exactas.
- Recuperación de cuenta: tokens de un solo uso, caducidad corta, respuesta idéntica exista o no el correo (anti-enumeración).
- Rate limiting en login, registro, recuperación y APIs (por IP + por cuenta).

## 4. Secretos y configuración
- Nunca en el repositorio: `.env` en `.gitignore`; `.env.example` sin valores.
- Producción: gestor de secretos (variables de entorno del proveedor, Vault, Secret Manager).
- Escáneres: `gitleaks`/`trufflehog` en pre-commit y CI.
- Filtración = **rotar ya**, luego investigar. Claves distintas por entorno.
- Claves de API públicas en front (Firebase, Maps) → restringir por dominio/cuota; las privadas jamás en el navegador ni en apps móviles.

## 5. Cabeceras HTTP de seguridad (base)
```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Cross-Origin-Opener-Policy: same-origin
```
- CSP: evita `'unsafe-inline'`/`'unsafe-eval'`; usa nonces o hashes. Prueba primero con `Content-Security-Policy-Report-Only`.
- Scripts de CDN: atributo `integrity` (SRI) + `crossorigin="anonymous"`.
- CORS: lista blanca de orígenes; no reflejar `Origin` sin validar; `*` nunca con credenciales.
- Enlaces `target="_blank"` → `rel="noopener noreferrer"`.

## 6. Cadena de suministro (A03)
- Antes de añadir una dependencia: ¿mantenida?, ¿descargas, issues, licencia?, ¿se puede hacer en 20 líneas propias?
- Versiones exactas + lockfile; actualizar con PR revisado; no auto-instalar "latest" en producción.
- Typosquatting: verifica el nombre exacto del paquete. Desconfía de `postinstall` scripts (`npm ci --ignore-scripts` donde sea viable).
- CI: permisos mínimos del token, acciones fijadas por SHA, secretos solo en jobs necesarios, builds reproducibles.
- Mantén runtimes con soporte (p. ej., Node 20 sin parches desde 30-abr-2026 → migrar a Node 24 LTS). **[VERIFICAR]** fechas vigentes.

## 7. Seguridad de IA/LLM (apps que usan modelos)
- **Prompt injection**: el contenido externo (web, PDFs, emails, resultados de herramientas) es DATO, nunca instrucciones. Separa claramente instrucciones del sistema y datos; no ejecutes acciones sensibles solo por texto recuperado.
- Menor privilegio en herramientas/agentes: permisos mínimos, confirmación humana para acciones destructivas o con dinero, listas blancas de herramientas y dominios.
- Salida del modelo = entrada no confiable: valida/escapa antes de renderizar (XSS), ejecutar SQL/shell, o llamar APIs.
- No pongas secretos ni datos personales innecesarios en prompts; registra con redacción.
- Exfiltración: bloquea imágenes/enlaces auto-renderizados a dominios arbitrarios con datos en la URL.
- Límites de coste/tasa por usuario; evalúa con casos adversariales; revisa el OWASP Top 10 for LLM Applications **[VERIFICAR edición vigente]**.

## 7b. Seguridad de IoT / red local (proyectos tipo ESP8266, routers de negocio)
- Cambia credenciales por defecto de routers/dispositivos; desactiva WPS y UPnP si no se usan.
- Red de invitados aislada (aislamiento de clientes/VLAN) de la red de caja/POS/cámaras.
- OTA y paneles admin con contraseña fuerte; no exponer a Internet (sin port-forward); acceso remoto por VPN.
- HTTP sin TLS en portal cautivo es aceptable solo si no maneja datos sensibles ni contraseñas; nunca pidas credenciales reales ahí.
- Firmware: actualizar; deshabilitar servicios innecesarios (Telnet, UPnP, admin remoto).

## 8. Seguridad web frontend rápida
- No guardes tokens en `localStorage` si puedes usar cookie `HttpOnly`.
- Sanitiza `location.hash`/`search` antes de usarlos; evita `document.write`, `eval`, `new Function`, `setTimeout("string")`.
- `postMessage`: valida `event.origin`.
- Dependencias front: auditar; evitar bibliotecas abandonadas.
- Clickjacking: `frame-ancestors 'none'` (o `X-Frame-Options: DENY`).

## 9. Checklist de revisión de seguridad (rápida)
- [ ] ¿Toda entrada validada en servidor? ¿Salida codificada por contexto?
- [ ] ¿Consultas parametrizadas? ¿Sin shell con datos externos?
- [ ] ¿Autorización por recurso en cada endpoint (IDOR)?
- [ ] ¿Contraseñas con Argon2id/bcrypt? ¿Rate limit en login?
- [ ] ¿Cookies HttpOnly/Secure/SameSite? ¿CSRF cubierto?
- [ ] ¿Sin secretos en repo/logs/front? ¿`.env` ignorado?
- [ ] ¿Cabeceras de seguridad + CSP? ¿SRI en CDN?
- [ ] ¿Dependencias auditadas y con lockfile?
- [ ] ¿Errores fallan cerrado, sin filtrar stack traces?
- [ ] ¿Logs de eventos de seguridad sin datos sensibles?
- [ ] ¿HTTPS en todo, HSTS activo?
