# Intent — POS Barbachu, ampliación del prototipo

## Problem
El prototipo inicial solo permite una cuenta activa por mesa, ofrece un catálogo sin flujo completo de servicios y no registra movimientos operativos de forma auditable.

## Proposed Outcome
Ampliar el prototipo local para demostrar múltiples cuentas independientes por ubicación, cinco tipos de servicio, notas por producto, prioridades, división/traspaso, reubicación, cancelaciones justificadas, descuentos y reaperturas simuladas, así como datos de entrega a domicilio.

## Constraints
- Conservar el menú público, las claves y los precios originales de SoftRestaurant.
- No habilitar cobros bancarios, autenticación, permisos de servidor ni inventario automático real.
- No descontar insumos sin recetas y existencias validadas.
- Los datos de esta demo permanecen en el navegador mediante localStorage; no hay sincronización multi-dispositivo.
- No publicar ni modificar el sitio de producción.
