import csv, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rows(name):
    with (ROOT/'catalogo'/name).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
class CatalogIntegrityTests(unittest.TestCase):
    def test_row_counts(self):
        self.assertEqual(len(rows('productos_softrestaurant.csv')),199)
        self.assertEqual(len(rows('insumos_softrestaurant.csv')),121)
    def test_product_keys_unique(self):
        k=[r['Clave'].strip() for r in rows('productos_softrestaurant.csv')]
        self.assertTrue(all(k)); self.assertEqual(len(k),len(set(k)))
    def test_ingredient_keys_unique(self):
        k=[r['Clave'].strip() for r in rows('insumos_softrestaurant.csv')]
        self.assertTrue(all(k)); self.assertEqual(len(k),len(set(k)))
    def test_zero_price_rows_preserved(self):
        p=rows('productos_softrestaurant.csv')
        self.assertEqual(sum(float(r['Precio'] or 0)<=0 for r in p),40)
if __name__=='__main__': unittest.main()
