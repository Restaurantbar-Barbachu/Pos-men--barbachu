# Barbachu POS — Fase 1

Paquete de auditoría; todavía no es un POS operativo ni está conectado a producción.

- `fuente/`: exportación original Numbers y conversión XLSX.
- `catalogo/`: productos e insumos en CSV y JSON, conservando valores de origen.
- `docs/auditoria-catalogo.md`: hallazgos y discrepancias iniciales.
- `docs/plan-implementacion-pos.md`: fases y criterios de salida.
- `scripts/validar_catalogo.py`: validador de integridad básica.
- `tests/test_catalog_integrity.py`: pruebas de filas, claves y precios cero.

## Pruebas
```bash
python -m unittest discover -s tests -v
python scripts/validar_catalogo.py
```

La escritura de una rama en GitHub fue bloqueada por la integración con un error 403. No se modificó el menú público ni se desplegó código. Este ZIP se entrega para revisar los datos y continuar la implementación con una vía de escritura habilitada.
