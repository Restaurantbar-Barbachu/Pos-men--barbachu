#!/usr/bin/env python3
"""Valida integridad básica sin modificar nombres, claves ni precios."""
from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parents[1]
def read(name):
    with (ROOT/'catalogo'/name).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def main():
    errors=[]; p=read('productos_softrestaurant.csv'); i=read('insumos_softrestaurant.csv')
    if len(p)!=199: errors.append(f'Productos: se esperaban 199; hay {len(p)}')
    if len(i)!=121: errors.append(f'Insumos: se esperaban 121; hay {len(i)}')
    for label,rows in [('Productos',p),('Insumos',i)]:
        keys=[r.get('Clave','').strip() for r in rows]
        if any(not k for k in keys): errors.append(label+': claves vacías')
        dup=sorted({k for k in keys if keys.count(k)>1})
        if dup: errors.append(label+': claves duplicadas '+', '.join(dup))
    zero=[]
    for r in p:
        try:
            if float(r.get('Precio') or 0)<=0: zero.append(r.get('Clave',''))
        except ValueError: errors.append(f"Precio no numérico en clave {r.get('Clave')}")
    print(f'Productos: {len(p)}'); print(f'Insumos: {len(i)}')
    print(f'Productos con precio <= 0 (revisión): {len(zero)}')
    if zero: print('Claves: '+', '.join(zero))
    if errors: print('\nERRORES:\n'+'\n'.join('- '+e for e in errors)); return 1
    print('OK: filas y claves verificadas. Precio cero/costos faltantes son alertas de negocio, no errores de formato.')
    return 0
if __name__=='__main__': sys.exit(main())
