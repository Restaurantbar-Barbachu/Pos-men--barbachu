# POS Barbachu — Plan de implementación por fases

## Objetivo
Integrar un POS privado y adaptable a celulares/tablets al ecosistema del sitio actual, con comandero, caja, cocina/barra e inventario por receta. El menú público seguirá separado y no expondrá datos operativos.

## Fase 1 — Catálogo y reglas (en curso)
- [x] Convertir la exportación a CSV/JSON conservando columnas, claves y precios originales.
- [x] Revisar filas, claves duplicadas y precios/costos cero.
- [x] Registrar discrepancias iniciales frente al menú publicado.
- [ ] Aprobar precios y presentaciones ambiguas.
- [ ] Clasificar registros vendibles, modificadores y conceptos internos.
- [ ] Documentar cantidades/unidades de recetas.
**Salida:** catálogo aprobado, sin precios cambiados silenciosamente; todos los productos vendibles tienen precio autorizado.

## Fase 2 — Base de datos y seguridad
- Crear rutas separadas para `/pos`, `/mesero`, `/cocina`, `/barra` y `/admin`.
- Modelar productos, variantes, modificadores, recetas, insumos, unidades, mesas, comandas, pagos y movimientos de inventario.
- Añadir autenticación, roles y autorización del lado servidor; usar RLS si se adopta Supabase.
- Separar credenciales y datos de desarrollo/pruebas/producción.
**Salida:** usuarios sin sesión no acceden a operaciones; permisos probados en API/base de datos, no solo ocultando botones.

## Fase 3 — POS y comandero táctil
- Mesas y cuentas abiertas; búsqueda por nombre, categoría y clave.
- Añadir productos, notas y modificadores.
- Enviar comanda a cocina/barra con estados y registro de usuario/hora.
- Evitar cargos o comandas duplicadas cuando dos dispositivos actúan a la vez.
**Salida:** flujo completo de mesa a entrega probado en celular y tablet.

## Fase 4 — Caja y pagos
- Subtotales, descuentos autorizados, pagos parciales, métodos de pago y cierre.
- Cortes de caja y bitácora de anulaciones.
- No almacenar números completos de tarjeta ni CVV; no marcar pagos como confirmados antes de recibir confirmación.
**Salida:** cálculos, pagos parciales, cancelaciones y conciliación probados.

## Fase 5 — Inventario por receta
- Recetas, cantidades, unidades convertibles y merma/rendimiento.
- Descuento único por evento confirmado e idempotencia.
- Movimientos de entrada, consumo, merma, ajuste, devolución y reversión.
- Alertas de existencia baja; costos cero quedan marcados como incompletos.
**Salida:** cada insumo se descuenta exactamente la cantidad esperada una sola vez; cancelaciones generan la reversión autorizada.

## Fase 6 — QA, piloto y despliegue
- Pruebas unitarias, integración, end-to-end, permisos y endpoints.
- Probar desconexión, concurrencia, comandas duplicadas y actualizaciones de cocina.
- Pruebas responsive y accesibilidad táctil.
- Desplegar primero a preview/staging, ejecutar piloto y aprobar antes de producción.
- Definir copias de seguridad y plan de reversión.

## Decisiones pendientes
- Confirmar base de datos/autenticación (Supabase es opción, no está conectada).
- Confirmar alojamiento Vercel; no se encontró un proyecto llamado Barbachu en la cuenta consultada.
- Definir impresoras/tickets, operación sin internet, pagos, número de mesas, áreas, roles, descuentos y propinas.

## Reglas críticas
- No confiar en totales, precios, descuentos o roles enviados por el navegador: validar/recalcular en servidor.
- Guardar dinero como enteros en centavos.
- Guardar precio vendido como snapshot en cada línea para no reescribir ventas históricas.
- Registrar quién/cuándo/por qué cambia precios, cancela comandas o ajusta inventario.
- No activar ventas reales con catálogo no aprobado.
