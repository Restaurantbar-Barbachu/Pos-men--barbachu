# Auditoría inicial del catálogo Barbachu

**Fecha:** 25 de octubre de 2026  
**Fuente:** `BARBACHU_PRODUCTOS_Y_INSUMOS.numbers` (exportación SoftRestaurant).  
**Menú de referencia:** https://restaurantbar-barbachu.github.io/Barbachu/  
**Estado:** auditoría inicial. No aplicar cambios de precio al menú público hasta confirmar las discrepancias.

## 1. Integridad de los datos

| Control | Resultado |
|---|---:|
| Productos | 199 |
| Insumos | 121 |
| Claves vacías en productos | 0 |
| Claves duplicadas en productos | 0 |
| Claves vacías en insumos | 0 |
| Claves duplicadas en insumos | 0 |
| Productos con precio cero o negativo | 40 |
| Insumos con costo cero | 94 |
| Insumos con costo promedio cero | 102 |

Las claves no se duplican dentro de cada hoja. Conservarlas como `source_key`; no usar la descripción como clave primaria. Los nombres y precios se exportaron sin normalización ni reescritura.

## 2. Productos con precio cero o no positivo

No activar automáticamente estos registros para venta. Confirmar si son modificadores, conceptos internos, cortesías o productos que necesitan precio autorizado.

| Clave | Descripción | Grupo | Precio | Categoría |
|---:|---|---:|---:|---|
| 1415 | ORDEN PEPINO | 14 | 0 | BOTANAS |
| 915 | IMPORTE | 9 | 0 | DESTILADOS |
| 918 | SHOT CUMPLEAÑERO | 9 | 0 | DESTILADOS |
| 1010 | PRESTAMO EFECTIVO | 10 | 0 | EXTRAS |
| 1012 | RECARGA CELULAR | 10 | 0 | EXTRAS |
| 1202 | 1/2 | 12 | 0 | MODIFICADORES |
| 1205 | 3/4 | 12 | 0 | MODIFICADORES |
| 1201 | BARBACHU MAMALONAS | 12 | 0 | MODIFICADORES |
| 1215 | BBQ | 12 | 0 | MODIFICADORES |
| 1204 | BIEN COCIDO | 12 | 0 | MODIFICADORES |
| 735 | BUFALO | 12 | 0 | MODIFICADORES |
| 1238 | CAMARON | 12 | 0 | MODIFICADORES |
| 805 | CAPSU | 12 | 0 | MODIFICADORES |
| 1209 | CEBOLLA | 12 | 0 | MODIFICADORES |
| 1240 | CECINA | 12 | 0 | MODIFICADORES |
| 1418 | CHAMOY | 12 | 0 | MODIFICADORES |
| 1416 | CHILE | 12 | 0 | MODIFICADORES |
| 232 | CLAMATO | 12 | 0 | MODIFICADORES |
| 718 | CON TODO | 12 | 0 | MODIFICADORES |
| 1231 | CREMA | 12 | 0 | MODIFICADORES |
| 512 | DURAZNO | 12 | 0 | MODIFICADORES |
| 1241 | ELOTE ADEREZO BARBACHU | 12 | 0 | MODIFICADORES |
| 1207 | ENSALADA | 12 | 0 | MODIFICADORES |
| 1206 | GAJO | 12 | 0 | MODIFICADORES |
| 804 | JITOMATE | 12 | 0 | MODIFICADORES |
| 1213 | LECHUGA | 12 | 0 | MODIFICADORES |
| 1419 | LIMON | 12 | 0 | MODIFICADORES |
| 1217 | MANGO | 12 | 0 | MODIFICADORES |
| 1228 | MINERAL | 12 | 0 | MODIFICADORES |
| 920 | MINERAL | 12 | 0 | MODIFICADORES |
| 919 | MITAD COCA MITAD MINERAL | 12 | 0 | MODIFICADORES |
| 806 | MOSTAZA | 12 | 0 | MODIFICADORES |
| 733 | PICOSAS | 12 | 0 | MODIFICADORES |
| 1227 | PINTADO | 12 | 0 | MODIFICADORES |
| 233 | PIÑA | 12 | 0 | MODIFICADORES |
| 1203 | POCO CHILE | 12 | 0 | MODIFICADORES |
| 807 | QUESO AMARILLO | 12 | 0 | MODIFICADORES |
| 1417 | SAL | 12 | 0 | MODIFICADORES |
| 1704 | SENCILLA | 12 | 0 | MODIFICADORES |
| 1239 | TAJIN | 12 | 0 | MODIFICADORES |

## 3. Discrepancias de precio iniciales

La comparación inicial del HTML público identificó estos casos. La cifra SoftRestaurant se conserva como dato de origen, pero no se asume que sea necesariamente el precio vigente.

| Producto/presentación | Menú publicado | SoftRestaurant | Acción |
|---|---:|---:|---|
| Limonada | $90 | $85 (clave 119) | Confirmar precio vigente |
| Rusa de cerveza 1 litro | $90 | $95 (clave 114) | Confirmar precio y receta |
| Jugo Boing | $30 | $25 (clave 320) | Confirmar presentación/precio |
| Pechuga de pollo | $190 | $185 (clave 604) | Confirmar precio vigente |
| Aguachiles verde/rojo/negro | $190 general | $185 cada uno (claves 505–507); Barbachu $190 (508) | Definir precio por variante |
| Pacifico | $35 en el menú | Clave 1514 $35 y clave 1515 $28 | Identificar presentación antes de combinar |
| Limonada frutos rojos | $95 sin alcohol / $145 preparada con vodka | claves 303 $95 / 120 $145 | Mantener como productos distintos |

Estos son casos a confirmar, no autorización para modificar precios. Los artículos agrupados por el menú pueden tener variantes y precios específicos.

## 4. Productos exportados que no aparecen claramente como opciones del menú

El HTML actual tiene 51 opciones/variantes detectables y no implementa persistencia de ventas, autenticación ni API. Una ausencia por nombre no prueba que un producto esté descontinuado.

- **Familias aparentemente faltantes:** boneless (9 registros), pulpo (clave 511), hamburguesa de camarón (808), hamburguesa de pechuga de pollo (802) y ensalada de pollo (510).
- **Cubetas/presentaciones:** comparar las 8 claves de `CUBETAS`; no fusionar presentaciones de 5 y 10 piezas.
- **Destilados:** revisar los 31 registros; separar botella, shot, vino y preparado. Nombres similares pueden representar tamaños distintos.
- **Bebidas sin alcohol:** comparar las 20 claves con opciones genéricas del menú; no asumir que “Pepsico” equivale a cada refresco exportado.
- **Extras/modificadores:** validar qué se vende por separado y qué requiere producto base.
- **Hamburguesas:** el menú presenta Res y Pollo; exportación incluye también Burger Camarón y Burger Pechuga Pollo.

## 5. Insumos y recetas

Un costo cero no necesariamente significa que el insumo sea gratuito. No calcular márgenes definitivos con costos incompletos. Unidades exportadas:
- `PZA`: 104
- `KGS`: 13
- `OZ`: 2
- `GALON`: 1
- `LTS`: 1

Para el descuento automático faltan recetas con cantidades por insumo, unidad de consumo y conversiones validadas, rendimiento/merma cuando aplique, reglas para modificadores y sustituciones, y política para comandas canceladas, devoluciones, cortesías y desperdicio. Los movimientos deben ser idempotentes para evitar descuentos duplicados.

## 6. Reglas propuestas para importar

- Conservar `source_key`, `source_description`, `source_price`, `source_category`, `source_group` y archivo de origen.
- Representar dinero como enteros en centavos MXN, no como coma flotante.
- No sobrescribir precios vigentes automáticamente: generar una discrepancia pendiente de aprobación.
- Separar producto vendible, modificador, insumo y concepto administrativo.
- No publicar en el menú público todo registro exportado automáticamente.
- Registrar importaciones y quién aprueba cambios.

## 7. Estado

Se generaron CSV y JSON fieles a la exportación, con validación básica de claves. La conciliación definitiva fila por fila, las presentaciones ambiguas, las recetas y los precios vigentes requieren confirmación antes de activar ventas o inventario automático.
