# Guía Universal de SDLC Nativo con IA (AI-Native SDLC Framework)

Esta especificación define un flujo de desarrollo guiado por archivos de contexto (`.md`) e instrucciones deterministas, optimizado para ser interpretado por **cualquier agente de código de IA** (ej. Claude Code, Cursor, Windsurf, Aider, GitHub Copilot Workspace, Devika).

---

## 🔄 El Ciclo de Desarrollo Basado en Archivos de Estado (State Files)

Los agentes de IA funcionan mejor cuando no dependen únicamente de la memoria conversacional (context window), sino de **archivos de estado persistentes** que documentan cada etapa. Cada fase produce un artefacto que consume la siguiente:

```
    [ 1. PLAN ] ---------> intent.md
         │
    [ 2. DESIGN ] -------> spec.md
         │
    [ 3. BUILD ] --------> plan.md
         │
    [ 4. TEST ] ---------> suite de pruebas / logs
         │
    [ 5. DEPLOY ] -------> PR / REVIEW.md (Aprobación humana)
         │
    [ 6. MAINTAIN ] -----> nuevo intent.md
```

---

## 📋 Estructura de las 6 Etapas del Flujo Agéntico

### 1. Plan (`intent.md`)
* **Responsable:** Humano (con asistencia opcional de IA).
* **Propósito:** Capturar la intención de alto nivel antes de escribir código o arquitectura.
* **Contenido obligatorio:**
  * `## Problem`: Descripción del problema actual o necesidad de usuario.
  * `## Proposed Outcome`: Qué constituye el éxito.
  * `## Constraints`: Restricciones arquitectónicas, de seguridad o legales que la IA **no debe alterar**.

### 2. Design (`spec.md`)
* **Responsable:** Agente de IA + Revisión Humana.
* **Propósito:** Traducir `intent.md` en una especificación funcional e interfaz/sistema.
* **Contenido obligatorio:**
  * Requisitos de API / Modelos de Datos / Endpoints.
  * Comportamientos de la interfaz y estados (Carga, Éxito, Error).
  * Casos borde a considerar.

### 3. Build (`plan.md`)
* **Responsable:** Agente de IA en Modo Solo-Lectura / Planificación.
* **Propósito:** Diseñar un plan de ejecución detallado paso a paso sin realizar modificaciones aún.
* **Contenido obligatorio:**
  * `## Files to Modify/Create`: Lista explícita de archivos impactados.
  * `## Execution Order`: Pasos secuenciales.
  * `## Verification Plan`: Cómo validará la IA que el código funciona.
* **Regla Agéntica:** *No se edita ningún archivo del código hasta que el humano apruebe este `plan.md`.*

### 4. Test
* **Responsable:** Agente de IA (Ejecución automática).
* **Propósito:** Verificación continua de la solución.
* **Regla de Oro:** Si una prueba unitaria o de integración falla, **el agente debe corregir el código**, nunca modificar las pruebas para forzar que pasen, a menos que el contrato explícitamente cambie en `spec.md`.

### 5. Deploy
* **Responsable:** Humano (Puerta de control).
* **Propósito:** Publicación y fusión en producción/main.
* **Proceso:** El agente emite un resumen de cambios (`REVIEW.md` o descripción de PR) analizando seguridad, rendimiento e impacto. El despliegue final lo autoriza siempre un usuario humano.

### 6. Maintain
* **Responsable:** Agente de IA + Telemetría.
* **Propósito:** Diagnóstico de errores en producción o feedback de usuarios.
* **Proceso:** Ante un log de error o reporte de bug, el agente analiza el incidente y genera automáticamente un nuevo `intent.md`, iniciando un nuevo ciclo.

---

## 🛠️ Arquitectura de Gobernanza para Cualquier Agente

Para garantizar la consistencia técnica de cualquier agente de IA en tu proyecto, configura el entorno utilizando estas tres capas de abstracción:

### 1. Archivo de Reglas del Proyecto (System Prompt / Workspace Context)
Define el estándar que la IA debe leer al iniciar cualquier sesión de trabajo:
* **Cursor / Copilot / Aider / Claude:** Configurar mediante `.cursorrules`, `.github/copilot-instructions.md` o `AGENTS.md` / `CLAUDE.md`.
* **Contenido indispensable:**
  * Comandos para ejecutar pruebas (`npm test`, `pytest`, `cargo test`).
  * Estilo de código y arquitectura de carpetas.
  * Dependencias permitidas.

### 2. Modos de Ejecución (Plan Mode vs. Act Mode)
Independientemente de la CLI o IDE utilizada, impón al agente la disciplina en dos fases:
* **Modo Plan:** Inspección y propuesta (`read-only`).
* **Modo Act:** Implementación de cambios (`write`).

### 3. Habilidades (Skills) vs. Restricciones Inquebrantables (Hooks)

| Concepto | Mecanismo | Comportamiento del Agente |
| :--- | :--- | :--- |
| **Skill (`SKILL.md` / Prompts)** | Guía de Buenas Prácticas | Instrucción suave que la IA **procurará seguir**, pero puede desviar si el contexto cambia. |
| **Hook (`settings.json` / CI/CD / Scripts)** | Bloqueo Determinista | Regla estricta por script / linters (`exit 2`, pre-commit hooks). **Si falla, el proceso se detiene por completo.** |

> **Principio de Integridad:** Utiliza **Skills** para orientación de diseño y convenciones, y **Hooks/CI-CD** para reglas críticas que nunca deben romperse (cobertura de tests, credenciales expuestas, validaciones de tipos).