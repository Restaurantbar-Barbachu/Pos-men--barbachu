# Spec — POS Barbachu v2 (prototipo)

## Servicios y ubicaciones
- Mesa: 8 ubicaciones.
- Barra exterior: 6 bancos.
- Barra interior: 3 bancos.
- Para llevar: ubicación lógica única, sin mesa.
- A domicilio: ubicación lógica única; requiere nombre, teléfono y dirección, con referencias opcionales.

## Cuentas y comandas
- Una ubicación puede tener múltiples cuentas abiertas identificadas por ID/folio.
- Cada cuenta conserva mesero, productos, notas, prioridad, servicio, ubicación y descuento de demostración.
- Permite crear cuenta, dividir unidades a una cuenta nueva, traspasar unidades a otra cuenta de la misma ubicación, mover una cuenta a otra ubicación y cancelar productos/cuentas con motivo.
- Estados de comanda: sent, ready y served; se muestran en Comandas.
- Reabrir una venta crea una cuenta nueva; no modifica ni borra el folio histórico.

## Caja
- Cobro completo simulado con método registrado: efectivo, tarjeta, transferencia o Mercado Pago. No se conecta a terminal ni pasarela.
- Descuento fijo simulado requiere motivo y confirmación; no equivale a autorización de servidor.
- Bitácora local para movimientos críticos.

## Inventario
- Consulta del catálogo de insumos. No hay receta validada ni descuento automático.

## Casos límite
- Impedir cobro de cuenta vacía.
- Rechazar cantidad de división/traspaso/cancelación fuera del rango disponible.
- Evitar traspaso que duplique unidades.
- No permitir guardar pedido a domicilio sin nombre, teléfono y dirección.
- Preservar los productos con precio cero como no vendibles.

## Fuera de alcance
Autenticación/roles reales, API, sincronización, pagos reales, impresión fiscal, caja multiusuario, respaldo/restauración automatizados, recetas y movimientos de inventario reales.
