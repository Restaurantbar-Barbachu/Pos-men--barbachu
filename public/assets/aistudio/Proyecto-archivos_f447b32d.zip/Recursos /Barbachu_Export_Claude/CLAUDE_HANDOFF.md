# Barbachu — paquete de continuidad para Claude

## Objetivo
Continuar el desarrollo del menú digital Barbachu y su prototipo POS sin perder decisiones, límites ni contexto. Este paquete es una exportación de archivos para adjuntar a Claude; no significa que el proyecto se haya importado automáticamente ni que el sitio publicado se haya modificado.

## Qué revisar primero
1. `Barbachu_POS_Prueba/index.html`: prototipo POS integrado en una copia del menú. Es la versión principal para pruebas.
2. `Barbachu_POS_Prueba/index-original.html`: copia del menú original usada como base.
3. `Barbachu_POS_Prueba/README.md`: instrucciones de prueba y limitaciones conocidas.
4. `Barbachu_POS_Prueba/productos_softrestaurant.json` y `.csv`: catálogo exportado de productos.
5. `Barbachu_POS_Prueba/insumos_softrestaurant.json` y `.csv`: catálogo exportado de insumos.
6. `Skills/`: estándares, checklists y skills incluidos en el proyecto. Consultarlos cuando correspondan; no asumir que son paquetes instalados en Claude.
7. `fuentes_originales/`: exportación original de SoftRestaurant en Numbers y archivo Markdown aportado por el usuario.

## Estado confirmado del prototipo POS
- Se añadió un acceso `POS · Prueba` al menú existente.
- Vistas/módulos de prueba: Venta, Comandas, Caja e Inventario.
- El catálogo integrado tiene 199 productos; 40 con precio cero están deshabilitados.
- Se incluyen 121 filas de insumos en la fuente de catálogo.
- Permite buscar artículos, seleccionar mesa, capturar mesero y nota, agregar/quitar productos, enviar comandas, marcar estados, simular cobro en efectivo, ver resumen local y exportar ventas a CSV.
- Los importes se calculan en centavos enteros.
- La persistencia es `localStorage`: los datos quedan en ese navegador/dispositivo, sin sincronización multi-dispositivo.
- No hay backend, autenticación real, permisos de servidor, procesamiento de pagos, impresión fiscal ni deducción automática real de inventario.
- No habilitar operación real ni deducciones de inventario hasta validar recetas, cantidades, unidades, rendimiento, existencias iniciales y reglas de cancelación/devolución.

## Decisiones y requisitos de arquitectura discutidos
- Operación de una sola sucursal inicialmente.
- Debe funcionar con tabletas, teléfonos y computadora.
- Impresoras previstas: USB y Ethernet/Wi-Fi; aún faltan marcas/modelos y pruebas de compatibilidad.
- Preferencia por internet con contingencia local.
- Preferencia por comenzar sin mensualidades, usando hardware existente y componentes de código abierto cuando sea viable.
- Propuesta pendiente de implementación: arquitectura local-first con servidor/API local y base de datos centralizada; cola de eventos con IDs únicos y reintentos; sincronización remota/respaldos cuando haya internet; no usar `localStorage` como solución multiusuario.
- SQLite en un servidor local podría servir para un MVP pequeño; PostgreSQL si la carga y requisitos lo justifican. Los clientes no deben compartir directamente un archivo SQLite por red: deben usar una API.
- Para impresoras USB se prevé un puente de impresión local; la compatibilidad depende de los modelos concretos.

## Datos y discrepancias a validar
- La exportación de SoftRestaurant no contiene cantidades de recetas ni existencias suficientes para calcular descuentos automáticos fiables.
- Se detectaron muchos costos nulos/cero; no usarlos como costos definitivos sin confirmación.
- Se observaron discrepancias entre algunos precios del menú público y el catálogo fuente, entre ellas: limonada, rusa 1 L, jugo Boing, pechuga de pollo, variantes de aguachile y presentaciones de cerveza Pacífico. No cambiar precios automáticamente: confirmar con el responsable del negocio.

## Pendientes prioritarios
1. Auditar el código actual y documentar errores reproducibles sin cambiar el menú público.
2. Decidir si se mantiene HTML monolítico solo como demo o se migra a una estructura modular.
3. Definir servidor disponible, router/red local y modelos exactos de impresoras.
4. Definir si el POS solo registra pagos al principio o integrará terminal/pasarela (no guardar datos de tarjetas).
5. Diseñar esquema de datos y API, usuarios/roles/permisos, comandas, caja, movimientos de inventario, recetas y auditoría.
6. Añadir pruebas automatizadas y pruebas reales en teléfono/tableta/PC.
7. Diseñar respaldos locales y copia externa cifrada cuando haya internet, con pruebas de restauración.
8. Solo después de validar recetas y existencias, implementar deducción de inventario y reversos auditables.

## Reglas para continuar
- No afirmar que se desplegó, sincronizó, publicó o importó algo sin comprobarlo.
- No editar el sitio público ni el repositorio remoto sin autorización explícita y una operación verificada.
- Antes de cambiar precios, recetas, costos o inventario, presentar discrepancias y pedir confirmación.
- Mantener una separación clara entre funciones implementadas, propuestas y pendientes.
- Priorizar seguridad, trazabilidad de caja, prevención de ventas duplicadas y tolerancia a interrupciones de internet.
- Para cada cambio: explicar archivos tocados, motivo, pruebas ejecutadas y limitaciones; entregar ZIP actualizado y verificar que el archivo exista.

## Primera tarea recomendada para Claude
Inspecciona el paquete. Resume la estructura y el estado real del código, identifica los riesgos de seguridad y consistencia más importantes, ejecuta las pruebas que sean posibles en el entorno disponible y propone un plan por fases. No hagas una reescritura completa ni cambies precios/datos de negocio sin justificar y solicitar confirmación.


## Marco de desarrollo obligatorio añadido

Se incluye `AI_Native_SDLC_Universal_Agent_Spec.md`. Úsalo como marco de proceso para continuar el proyecto:
1. **Plan:** documentar problema, resultado esperado y restricciones en `intent.md`.
2. **Design:** definir requisitos funcionales, API/modelos, estados de interfaz y casos límite en `spec.md`.
3. **Build:** preparar `plan.md` con archivos a modificar, orden de ejecución y plan de verificación.
4. **Aprobación antes de editar:** no modificar código hasta que el usuario apruebe el plan.
5. **Test:** corregir el código cuando fallen pruebas; no cambiar pruebas solo para hacerlas pasar salvo que cambie explícitamente el contrato.
6. **Deploy:** entregar `REVIEW.md` con seguridad, rendimiento e impacto; la publicación requiere autorización humana.
7. **Maintain:** convertir reportes de errores en un nuevo ciclo de intención y planificación.

El documento distingue instrucciones orientativas (skills) de controles deterministas (hooks/CI). No afirmes que estos archivos de estado, hooks o pipelines ya están implementados en el repositorio: son reglas de proceso que deben incorporarse explícitamente y aprobarse según el plan.
