# Plan — ejecución v2

## Files to Modify/Create
- `Barbachu_POS_Prueba/index.html`: interfaz y lógica del prototipo POS.
- `Barbachu_POS_Prueba/README.md`: instrucciones y límites actualizados.
- `intent.md`, `spec.md`, `plan.md`, `REVIEW.md`: archivos de estado SDLC.

## Execution Order
1. Preservar copia del ZIP fuente y modificar únicamente la copia de trabajo.
2. Añadir selectores de servicio, ubicación y cuenta.
3. Incorporar funciones de cuentas, notas, prioridad, división, traspaso, cancelación, descuento, reubicación y reapertura simulada.
4. Actualizar documentación y pruebas estáticas.
5. Empaquetar ZIP y verificar integridad del archivo.

## Verification Plan
- `node --check` para cada bloque JavaScript ejecutable.
- Parseo HTML y validación de IDs únicos.
- Parseo de JSON de productos e insumos; comprobar conteos, claves y productos de precio cero.
- Comprobar presencia de los servicios y cantidades de ubicaciones, y que los controles clave tengan manejadores declarados.
- Intento de prueba de navegador automatizada; si el entorno bloquea el navegador, documentar el límite y no declarar pruebas de interacción como aprobadas.
