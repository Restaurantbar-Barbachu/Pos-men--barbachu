# Barbachu POS — prototipo v2

## Cómo probarlo
1. Abre `index.html` en un navegador moderno.
2. Pulsa **POS · Prueba**.
3. Selecciona uno de los cinco servicios y su ubicación.
4. Agrega productos, notas y mesero; guarda la comanda.
5. Crea otra cuenta en la misma ubicación para comprobar cuentas independientes.
6. En Comandas, cambia prioridad y estados. En Venta, prueba división, traspaso, reubicación y cancelaciones.
7. En Caja, prueba descuentos y cobros simulados, revisa la bitácora y exporta CSV.

## Servicios
- 8 mesas.
- 6 bancos de barra exterior.
- 3 bancos de barra interior.
- Para llevar.
- A domicilio, con nombre, teléfono y dirección obligatorios.

## Mejoras incluidas
Cuentas múltiples por ubicación, notas individuales de preparación, prioridad de comandas, división por unidades, traspaso entre cuentas de una misma ubicación, cambio de mesa/banco/servicio, cancelación justificada de productos y cuentas, descuento de demostración, reapertura como nueva cuenta, bitácora local y selección de método de pago de prueba.

## Límites y advertencias
- Es una demostración local, no un POS de producción.
- La persistencia usa `localStorage`; no sincroniza teléfonos, tablets, cocina ni caja.
- No hay autenticación ni permisos reales. Las confirmaciones y motivos son solo simulaciones.
- Efectivo, tarjeta, transferencia y Mercado Pago son etiquetas de prueba; no se procesa ningún pago.
- No hay impresión fiscal.
- No hay descuento automático de inventario: faltan recetas, unidades, rendimientos y existencias verificadas.
- No cambiar precios o claves del catálogo fuente. Los artículos de precio cero siguen deshabilitados.
- Antes de operar realmente se requiere backend, controles de acceso, concurrencia, respaldos y pruebas en los dispositivos físicos.
