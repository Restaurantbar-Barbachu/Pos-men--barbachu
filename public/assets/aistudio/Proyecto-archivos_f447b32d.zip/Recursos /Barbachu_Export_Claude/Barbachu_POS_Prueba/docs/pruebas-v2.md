# Pruebas estáticas — POS v2

- Productos del catálogo: **199**.
- Insumos: **121**.
- Productos sin precio vendible / deshabilitados: **40**.
- IDs HTML duplicados: **0**.
- Controles funcionales requeridos presentes: **10/10**.
- Bloques JavaScript ejecutables: 2; ambos pasan `node --check`.
- Prueba interactiva de navegador: no ejecutada por bloqueo del Chromium del entorno (`ERR_BLOCKED_BY_ADMINISTRATOR`).

Estas comprobaciones estáticas no sustituyen pruebas de aceptación manuales en iPhone/iPad, Android, tablets y PC.
