import React, { useState, useEffect, useMemo } from 'react';
import { AppState, Catalog, OrderStatus } from '../types';
import { DEMO_CATALOG } from '../data/demoCatalog';
import {
  closeOrder,
  createOrder,
  formatPesos,
  STATUS_LABELS,
  transitionOrder,
} from '../core';
import {
  DEMO_STORAGE_KEY,
  loadDemoState,
  resetDemoStorage,
  saveDemoState,
} from '../storage';

interface CartLine {
  productId: string;
  name: string;
  unitPriceCents: number;
  quantity: number;
}

interface PosViewProps {
  onSwitchToMenu?: () => void;
}

export const PosView: React.FC<PosViewProps> = ({ onSwitchToMenu }) => {
  const catalog: Catalog = DEMO_CATALOG;
  const [state, setState] = useState<AppState>(() => loadDemoState(window.localStorage, catalog));
  const [view, setView] = useState<'sale' | 'orders' | 'cash' | 'stock'>('sale');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [table, setTable] = useState<number>(1);
  const [waiter, setWaiter] = useState<string>('Mesero Demo');
  const [note, setNote] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [productCategory, setProductCategory] = useState<string>('all');

  // Sync to localStorage
  useEffect(() => {
    saveDemoState(window.localStorage, state);
  }, [state]);

  // Listen for storage events across tabs
  useEffect(() => {
    const handleStorage = (event: StorageEvent) => {
      if (event.key === DEMO_STORAGE_KEY) {
        setState(loadDemoState(window.localStorage, catalog));
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [catalog]);

  const notify = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 2500);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const activeOrders = useMemo(() => {
    return state.orders.filter((o) => o.status !== 'closed');
  }, [state.orders]);

  const closedOrders = useMemo(() => {
    return state.orders.filter((o) => o.status === 'closed');
  }, [state.orders]);

  const cartTotalCents = useMemo(() => {
    return cart.reduce((sum, line) => sum + line.unitPriceCents * line.quantity, 0);
  }, [cart]);

  const handleAddToCart = (productId: string) => {
    const product = catalog.products.find((p) => p.id === productId);
    if (!product) return;
    setCart((prev) => {
      const existing = prev.find((item) => item.productId === productId);
      if (existing) {
        return prev.map((item) =>
          item.productId === productId ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          unitPriceCents: product.priceCents,
          quantity: 1,
        },
      ];
    });
  };

  const handleQuantityDelta = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.productId === productId) {
            return { ...item, quantity: item.quantity + delta };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleSendOrder = () => {
    try {
      const nextState = createOrder(state, catalog, {
        table: Number(table),
        waiter,
        note,
        items: cart,
      });
      setState(nextState);
      setCart([]);
      setNote('');
      setView('orders');
      notify('Comanda demo enviada.');
    } catch (err: any) {
      notify(err.message || 'Error al enviar la comanda');
    }
  };

  const handleTransition = (orderId: string, nextStatus: OrderStatus) => {
    try {
      const nextState = transitionOrder(state, orderId, nextStatus);
      setState(nextState);
      notify('Estado de comanda actualizado.');
    } catch (err: any) {
      notify(err.message || 'Error al actualizar comanda');
    }
  };

  const handleClose = (orderId: string, paymentMethod: 'cash' | 'card') => {
    try {
      const nextState = closeOrder(state, catalog, orderId, paymentMethod);
      setState(nextState);
      notify('Cobro y descuento de receta simulados.');
    } catch (err: any) {
      notify(err.message || 'Error al procesar cobro');
    }
  };

  const handleResetDemo = () => {
    setShowResetConfirm(true);
  };

  const confirmResetDemo = () => {
    const fresh = resetDemoStorage(window.localStorage, catalog);
    setState(fresh);
    setCart([]);
    setView('sale');
    setShowResetConfirm(false);
    notify('Demo reiniciada.');
  };

  const viewTitles = {
    sale: 'Nueva venta',
    orders: 'Comandas',
    cash: 'Caja demo',
    stock: 'Inventario demo',
  };

  // Filter products by category if selected
  const availableCategories = useMemo(() => {
    const cats = Array.from(new Set(catalog.products.map((p) => p.category)));
    return ['all', ...cats];
  }, [catalog.products]);

  const filteredProducts = useMemo(() => {
    if (productCategory === 'all') return catalog.products;
    return catalog.products.filter((p) => p.category === productCategory);
  }, [catalog.products, productCategory]);

  const cashTotalCents = useMemo(() => {
    return state.sales.reduce((sum, s) => sum + s.totalCents, 0);
  }, [state.sales]);

  return (
    <div className="min-h-screen bg-[#f4f5ef] text-[#182b27] flex flex-col justify-between">
      <div>
        <div className="demo-ribbon" role="note">
          DEMO · DATOS FICTICIOS · NO USAR PARA VENTAS
        </div>

        <header className="topbar">
          <div className="brand-mark" aria-hidden="true">
            B
          </div>
          <div className="brand-copy">
            <p className="eyebrow">BARBACHU · PROTOTIPO</p>
            <h1>POS Barbachu</h1>
          </div>
          <div className="flex items-center gap-2">
            {onSwitchToMenu && (
              <button
                className="quiet-button !border-[#d8b368] !text-[#f4c96b] hover:!bg-[#dba84c22]"
                type="button"
                onClick={onSwitchToMenu}
                title="Ver Menú Digital para Clientes"
              >
                📖 Ver Menú
              </button>
            )}
            <button
              className="quiet-button"
              id="reset-demo"
              type="button"
              onClick={handleResetDemo}
            >
              Reiniciar demo
            </button>
          </div>
        </header>

        <main className="pos-container">
          <div className="intro">
            <div>
              <p className="eyebrow">OPERACIÓN DE PRUEBA</p>
              <h2 id="view-title">{viewTitles[view]}</h2>
            </div>
            <span className="demo-pill">LOCAL · DEMO</span>
          </div>

          <nav className="tabs" aria-label="Secciones POS" role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={view === 'sale'}
              data-view="sale"
              onClick={() => setView('sale')}
            >
              Venta
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={view === 'orders'}
              data-view="orders"
              onClick={() => setView('orders')}
            >
              Comandas <span id="order-count" className="count-badge">{activeOrders.length}</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={view === 'cash'}
              data-view="cash"
              onClick={() => setView('cash')}
            >
              Caja
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={view === 'stock'}
              data-view="stock"
              onClick={() => setView('stock')}
            >
              Inventario
            </button>
          </nav>

          <section id="app-view" aria-live="polite">
            {view === 'sale' && (
              <div className="sale-layout">
                <div>
                  <section className="panel">
                    <h3>Datos de la comanda</h3>
                    <div className="field-grid">
                      <div className="field">
                        <label htmlFor="table">Mesa</label>
                        <select
                          id="table"
                          value={table}
                          onChange={(e) => setTable(Number(e.target.value))}
                        >
                          {Array.from({ length: 12 }, (_, i) => (
                            <option key={i + 1} value={i + 1}>
                              Mesa {i + 1}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <label htmlFor="waiter">Mesero</label>
                        <input
                          id="waiter"
                          value={waiter}
                          onChange={(e) => setWaiter(e.target.value)}
                          autoComplete="off"
                        />
                      </div>
                    </div>
                    <div className="field" style={{ marginTop: '10px' }}>
                      <label htmlFor="note">Nota para cocina (opcional)</label>
                      <input
                        id="note"
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Ej. Sin cebolla"
                      />
                    </div>
                  </section>

                  <section className="panel">
                    <div className="flex items-center justify-between mb-3">
                      <h3 style={{ margin: 0 }}>Productos de prueba</h3>
                      {availableCategories.length > 2 && (
                        <div className="flex gap-1 text-xs">
                          {availableCategories.map((cat) => (
                            <button
                              key={cat}
                              type="button"
                              onClick={() => setProductCategory(cat)}
                              className={`px-2 py-1 rounded-md font-medium text-xs transition-colors ${
                                productCategory === cat
                                  ? 'bg-[#173c34] text-white'
                                  : 'bg-[#edf2ea] text-[#5b6c62] hover:bg-[#dfe6dc]'
                              }`}
                            >
                              {cat === 'all' ? 'Todos' : cat}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="product-grid">
                      {filteredProducts.map((product) => (
                        <button
                          key={product.id}
                          className="product-card"
                          type="button"
                          data-add={product.id}
                          onClick={() => handleAddToCart(product.id)}
                        >
                          <strong>{product.name}</strong>
                          <span>{formatPesos(product.priceCents)}</span>
                        </button>
                      ))}
                    </div>
                  </section>
                </div>

                <section className="panel">
                  <h3>Resumen</h3>
                  <div id="cart-lines">
                    {cart.length > 0 ? (
                      cart.map((line) => (
                        <div key={line.productId} className="cart-line">
                          <div>
                            <strong>{line.name}</strong>
                            <span className="secondary">{formatPesos(line.unitPriceCents)} c/u</span>
                          </div>
                          <div className="quantity-control">
                            <button
                              type="button"
                              aria-label={`Quitar ${line.name}`}
                              data-qty={line.productId}
                              data-delta="-1"
                              onClick={() => handleQuantityDelta(line.productId, -1)}
                            >
                              −
                            </button>
                            <strong>{line.quantity}</strong>
                            <button
                              type="button"
                              aria-label={`Agregar ${line.name}`}
                              data-qty={line.productId}
                              data-delta="1"
                              onClick={() => handleQuantityDelta(line.productId, 1)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="empty">Agrega un producto para iniciar.</p>
                    )}
                  </div>
                  <div className="total-row">
                    <span>Total</span>
                    <strong data-testid="cart-total">{formatPesos(cartTotalCents)}</strong>
                  </div>
                  <button
                    id="send-order"
                    className="primary-button"
                    type="button"
                    disabled={cart.length === 0}
                    onClick={handleSendOrder}
                  >
                    Enviar comanda
                  </button>
                </section>
              </div>
            )}

            {view === 'orders' && (
              <div>
                {activeOrders.length === 0 && closedOrders.length === 0 ? (
                  <section className="panel empty">Aún no hay comandas demo.</section>
                ) : (
                  [...activeOrders.slice().reverse(), ...closedOrders.slice().reverse()].map((order) => (
                    <article key={order.id} className="panel">
                      <div className="order-line" style={{ paddingTop: 0 }}>
                        <div>
                          <strong>{order.id} · Mesa {order.table}</strong>
                          <span className="secondary">
                            {order.waiter} · {formatPesos(order.totalCents)}
                          </span>
                        </div>
                        <span className={`status ${order.status}`}>
                          {STATUS_LABELS[order.status]}
                        </span>
                      </div>
                      <div className="secondary mt-2">
                        {order.items.map((item) => `${item.quantity} × ${item.name}`).join(' · ')}
                      </div>
                      {order.note && <p className="note">Nota: {order.note}</p>}
                      <div className="action-row">
                        {order.status === 'sent' && (
                          <button
                            className="action-button light"
                            data-next="ready"
                            data-order={order.id}
                            onClick={() => handleTransition(order.id, 'ready')}
                          >
                            Marcar lista
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            className="action-button light"
                            data-next="served"
                            data-order={order.id}
                            onClick={() => handleTransition(order.id, 'served')}
                          >
                            Marcar entregada
                          </button>
                        )}
                        {order.status === 'served' && (
                          <>
                            <button
                              className="action-button gold"
                              data-pay="cash"
                              data-order={order.id}
                              onClick={() => handleClose(order.id, 'cash')}
                            >
                              Cobrar efectivo
                            </button>
                            <button
                              className="action-button gold"
                              data-pay="card"
                              data-order={order.id}
                              onClick={() => handleClose(order.id, 'card')}
                            >
                              Cobrar tarjeta
                            </button>
                          </>
                        )}
                      </div>
                    </article>
                  ))
                )}
              </div>
            )}

            {view === 'cash' && (
              <div>
                <section className="panel">
                  <h3>Resumen de caja · ficticio</h3>
                  <div className="summary-grid">
                    <div className="metric">
                      <span>Ventas demo</span>
                      <strong>{state.sales.length}</strong>
                    </div>
                    <div className="metric">
                      <span>Total cobrado demo</span>
                      <strong>{formatPesos(cashTotalCents)}</strong>
                    </div>
                  </div>
                </section>
                <section className="panel">
                  <h3>Movimientos</h3>
                  {state.sales.length > 0 ? (
                    state.sales
                      .slice()
                      .reverse()
                      .map((sale) => (
                        <div key={sale.id} className="sale-row">
                          <div>
                            <strong>{sale.id}</strong>
                            <span className="secondary">
                              {sale.orderId} · {sale.paymentMethod === 'cash' ? 'Efectivo' : 'Tarjeta'}
                            </span>
                          </div>
                          <strong>{formatPesos(sale.totalCents)}</strong>
                        </div>
                      ))
                  ) : (
                    <p className="empty">Sin cobros demo por ahora.</p>
                  )}
                </section>
              </div>
            )}

            {view === 'stock' && (
              <section className="panel">
                <h3>Existencias de prueba</h3>
                {catalog.ingredients.map((ingredient) => (
                  <div key={ingredient.id} className="stock-row">
                    <div>
                      <strong>{ingredient.name}</strong>
                      <span className="stock-id">{ingredient.id}</span>
                    </div>
                    <div className="stock-qty">
                      {state.stock[ingredient.id]} {ingredient.unit}
                    </div>
                  </div>
                ))}
                <p className="note">
                  El descuento ocurre al cobrar una comanda entregada, según la receta sintética.
                </p>
              </section>
            )}
          </section>
        </main>
      </div>

      <footer className="pos-footer">
        Prototipo de evaluación · Los cambios se guardan solo en este navegador.
      </footer>

      {/* Toast Notification */}
      <div
        id="toast"
        className={`toast ${toastMessage ? 'show' : ''}`}
        role="status"
        aria-live="polite"
      >
        {toastMessage}
      </div>

      {/* In-app Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-[#e5e8df]">
            <h3 className="font-serif font-bold text-xl text-[#173c34] mb-2">
              ¿Reiniciar demo?
            </h3>
            <p className="text-sm text-[#738078] mb-6">
              Se eliminarán todas las comandas, ventas e inventario ficticio de esta demo y se restaurarán los valores iniciales.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                className="px-4 py-2.5 rounded-lg border border-[#dfe4dc] text-sm font-semibold text-[#5b6c62] hover:bg-[#f4f6f0]"
                onClick={() => setShowResetConfirm(false)}
              >
                Cancelar
              </button>
              <button
                type="button"
                className="px-4 py-2.5 rounded-lg bg-[#a43d35] text-white text-sm font-bold hover:bg-[#8e342d]"
                onClick={confirmResetDemo}
              >
                Sí, reiniciar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
