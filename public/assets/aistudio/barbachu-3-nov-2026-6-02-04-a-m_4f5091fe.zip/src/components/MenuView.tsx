import React, { useState, useEffect } from 'react';
import { RESTAURANT_MENU_SECTIONS } from '../data/restaurantMenu';
import { MenuItemData } from '../types';

interface MenuViewProps {
  onSwitchToPos?: () => void;
}

export const MenuView: React.FC<MenuViewProps> = ({ onSwitchToPos }) => {
  const [selectedItem, setSelectedItem] = useState<MenuItemData | null>(null);
  const [activeSection, setActiveSection] = useState<string>('espec');

  const chips = [
    { id: 'espec', label: 'Especialidades' },
    { id: 'sec-platillos', label: 'Platillos' },
    { id: 'sec-hambur', label: 'Hamburguesas' },
    { id: 'sec-extras', label: 'Extras' },
    { id: 'sec-botana', label: 'Botana' },
    { id: 'sec-cecina', label: 'Cecina' },
    { id: 'sec-mich', label: 'Micheladas' },
    { id: 'sec-cerveza', label: 'Cerveza' },
    { id: 'sec-na', label: 'Sin alcohol' },
  ];

  const handleScrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const topOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 120;
      for (let i = chips.length - 1; i >= 0; i--) {
        const el = document.getElementById(chips[i].id);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(chips[i].id);
          break;
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getWhatsAppUrl = (item: MenuItemData) => {
    const msg = `Hola, quiero pedir: ${item.name} (${item.price})`;
    return `https://wa.me/523314456850?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-[#f0e6d3] selection:bg-[#c8a84b] selection:text-[#0a0a0b]">
      {/* Top Banner & Quick Switcher */}
      <div className="sticky top-0 z-40 bg-[#141416]/90 backdrop-blur-md border-b border-[#2a2a2d] px-4 py-2 flex items-center justify-between text-xs">
        <span className="text-[#c8a84b] font-medium tracking-wide">
          Barbachu · Restaurante Bar
        </span>
        {onSwitchToPos && (
          <button
            type="button"
            onClick={onSwitchToPos}
            className="px-3 py-1.5 rounded-full bg-[#173c34] text-[#f4c96b] border border-[#28584c] font-semibold hover:bg-[#28584c] transition-colors flex items-center gap-1.5"
          >
            <span>💼</span> Sistema POS Barbachu
          </button>
        )}
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-24">
        {/* Hero Section */}
        <header className="pt-10 pb-6 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full border border-[#c8a84b]/40 flex items-center justify-center bg-[#17171a] shadow-[0_0_30px_rgba(200,168,75,0.15)]">
            <span className="font-serif font-bold text-4xl text-[#c8a84b]">B</span>
          </div>
          <h1 className="font-serif font-bold text-4xl tracking-tight text-[#f0e6d3]">
            Barbachu
          </h1>
          <p className="text-[#c8a84b] font-semibold text-sm tracking-widest uppercase mt-1">
            Restaurante Bar
          </p>
          <address className="not-italic text-sm text-[#8c8c94] mt-2">
            Poza Rica #4984, San Pedrito
          </address>
        </header>

        {/* Sticky Chips Bar */}
        <div className="sticky top-[45px] z-30 bg-[#0a0a0b]/90 backdrop-blur-lg -mx-4 px-4 py-3 border-y border-[#222226]">
          <nav className="flex gap-2 overflow-x-auto no-scrollbar scroll-smooth" aria-label="Secciones del menú">
            {chips.map((chip) => (
              <button
                key={chip.id}
                type="button"
                onClick={() => handleScrollToSection(chip.id)}
                className={`flex-none min-h-[38px] px-4 rounded-full text-xs font-semibold tracking-wide transition-all whitespace-nowrap ${
                  activeSection === chip.id
                    ? 'bg-[#c8a84b] text-[#0a0a0b] font-bold shadow-md'
                    : 'bg-[#18181c] text-[#a4a4b0] border border-[#2f2f35] hover:border-[#c8a84b]/50 hover:text-[#f0e6d3]'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Menu Content */}
        <main className="mt-6 space-y-12">
          {RESTAURANT_MENU_SECTIONS.map((section) => (
            <section key={section.id} id={section.id} className="scroll-mt-28">
              {section.part && (
                <h2 className="font-serif font-bold text-2xl text-[#c8a84b] mb-4 mt-8">
                  {section.part}
                </h2>
              )}

              {section.id !== 'espec' && (
                <div className="mb-3">
                  <h3 className="font-serif font-bold text-xl text-[#f0e6d3]">
                    {section.title}
                  </h3>
                  {section.note && (
                    <p className="text-xs text-[#8c8c94] mt-0.5">{section.note}</p>
                  )}
                </div>
              )}

              {/* Special horizontal cards for Especialidades */}
              {section.id === 'espec' && (
                <div className="flex gap-3 overflow-x-auto no-scrollbar pb-3 -mx-4 px-4 scroll-pl-4">
                  {section.items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSelectedItem(item)}
                      className="flex-none w-56 text-left p-4 rounded-2xl bg-gradient-to-br from-[#c8a84b]/10 via-[#18181c] to-[#121215] border border-[#c8a84b]/30 hover:border-[#c8a84b] transition-all transform active:scale-95 shadow-lg group"
                    >
                      <span className="text-3xl block mb-2">{item.icon}</span>
                      <strong className="block font-serif font-bold text-base text-[#f0e6d3] group-hover:text-[#c8a84b] transition-colors">
                        {item.name}
                      </strong>
                      <span className="text-sm font-bold text-[#c8a84b] block mt-1">
                        {item.price} {item.sub && `· ${item.sub}`}
                      </span>
                      {item.desc && (
                        <p className="text-xs text-[#8c8c94] mt-2 line-clamp-2">
                          {item.desc}
                        </p>
                      )}
                    </button>
                  ))}
                </div>
              )}

              {/* Standard List Items */}
              {section.items.length > 0 && section.id !== 'espec' && (
                <div className="bg-[#141418] border border-[#25252a] rounded-2xl divide-y divide-[#232328] overflow-hidden shadow-sm">
                  {section.items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSelectedItem(item)}
                      className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1b1b20] active:bg-[#202026] transition-colors"
                    >
                      <div className="pr-4">
                        <span className="block font-medium text-sm text-[#f0e6d3]">
                          {item.name}
                        </span>
                        {item.sub && (
                          <span className="block text-xs text-[#8c8c94] mt-0.5">
                            {item.sub}
                          </span>
                        )}
                        {item.desc && (
                          <span className="block text-xs text-[#8c8c94] mt-0.5">
                            {item.desc}
                          </span>
                        )}
                      </div>
                      <span className="flex-none font-bold text-sm text-[#c8a84b] font-mono">
                        {item.price}
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {/* Subcategories (like Alas, Botana Barbachu, Cubetas, Sabores) */}
              {section.subcategories && section.subcategories.length > 0 && (
                <div className="space-y-5 mt-4">
                  {section.subcategories.map((sub, idx) => (
                    <div key={idx}>
                      <p className="text-xs uppercase tracking-wider font-bold text-[#8c8c94] mb-1.5 px-1">
                        {sub.caption}
                      </p>
                      {sub.description && (
                        <p className="text-xs text-[#a4a4b0] mb-2 px-1">
                          {sub.description}
                        </p>
                      )}
                      <div className="bg-[#141418] border border-[#25252a] rounded-2xl divide-y divide-[#232328] overflow-hidden">
                        {sub.items.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => setSelectedItem(item)}
                            className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1b1b20] active:bg-[#202026] transition-colors"
                          >
                            <div className="pr-4">
                              <span className="block font-medium text-sm text-[#f0e6d3]">
                                {item.name}
                              </span>
                              {item.sub && (
                                <span className="block text-xs text-[#8c8c94] mt-0.5">
                                  {item.sub}
                                </span>
                              )}
                            </div>
                            <span className="flex-none font-bold text-sm text-[#c8a84b] font-mono">
                              {item.price}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Michelada Flavors Pill List */}
              {section.id === 'sec-mich' && (
                <div className="mt-4">
                  <p className="text-xs uppercase tracking-wider font-bold text-[#8c8c94] mb-2 px-1">
                    Sabores disponibles
                  </p>
                  <div className="flex flex-wrap gap-2 p-3 bg-[#141418] border border-[#25252a] rounded-2xl">
                    {['Clamato', 'Mango', 'Durazno', 'Piña', 'Tamarindo'].map((flavor) => (
                      <span
                        key={flavor}
                        className="px-3 py-1 rounded-full text-xs font-semibold bg-[#c8a84b]/15 text-[#c8a84b] border border-[#c8a84b]/30"
                      >
                        {flavor}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </section>
          ))}
        </main>

        {/* Footer */}
        <footer className="mt-16 pt-8 border-t border-[#222226] text-center text-xs text-[#8c8c94]">
          <p className="font-medium text-[#a4a4b0]">Poza Rica #4984, San Pedrito</p>
          <div className="flex items-center justify-center gap-6 mt-3">
            <a
              href="https://www.instagram.com/barbachu__oficial/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#c8a84b] hover:underline py-2"
            >
              Instagram
            </a>
            <a
              href="https://www.facebook.com/share/14xz4YsgiW6/?mibextid=wwXIfr"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#c8a84b] hover:underline py-2"
            >
              Facebook
            </a>
          </div>
          <p className="mt-4 text-[#66666f]">
            Barbachu © Restaurante Bar. Todos los derechos reservados.
          </p>
        </footer>
      </div>

      {/* WhatsApp Floating Action Button */}
      <a
        href="https://wa.me/523314456850?text=Hola%2C%20quiero%20hacer%20un%20pedido"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Pedir por WhatsApp"
        className="fixed right-4 bottom-6 z-40 flex items-center gap-2 px-4 py-3 rounded-full bg-[#25D366] text-[#0a0a0b] font-bold text-xs shadow-[0_8px_24px_rgba(0,0,0,0.5)] hover:scale-105 active:scale-95 transition-transform"
      >
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.39 1.26 4.82L2 22l5.4-1.42a9.9 9.9 0 0 0 4.64 1.18h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2Zm5.8 14.07c-.24.68-1.4 1.3-1.93 1.37-.5.07-1.1.1-1.77-.11a16 16 0 0 1-1.6-.59c-2.8-1.21-4.63-4.04-4.77-4.23-.14-.18-1.14-1.52-1.14-2.9s.72-2.06.97-2.34c.25-.28.55-.35.73-.35h.53c.17 0 .4-.03.62.48.24.56.8 1.95.87 2.09.07.14.12.3.02.49-.1.18-.15.3-.3.46-.14.16-.3.36-.43.48-.14.14-.3.29-.13.57.17.28.76 1.25 1.63 2.03 1.12 1 2.06 1.3 2.34 1.45.28.14.44.12.6-.07.17-.19.72-.84.91-1.13.19-.28.38-.23.63-.14.26.1 1.64.77 1.92.91.28.14.47.21.54.33.07.12.07.68-.17 1.36Z" />
        </svg>
        <span>WhatsApp</span>
      </a>

      {/* Item Detail Modal / Sheet */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="w-full sm:max-w-md bg-[#16161a] border-t sm:border border-[#2e2e36] rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-[#3a3a44] mx-auto mb-4 sm:hidden"></div>
            {selectedItem.icon && (
              <span className="text-4xl block mb-2">{selectedItem.icon}</span>
            )}
            <h2 className="font-serif font-bold text-2xl text-[#f0e6d3]">
              {selectedItem.name}
            </h2>
            <p className="font-mono font-bold text-xl text-[#c8a84b] mt-1">
              {selectedItem.price}
            </p>
            <p className="text-xs text-[#8c8c94] uppercase tracking-wider font-semibold mt-2">
              {selectedItem.group}
            </p>
            {selectedItem.sub && (
              <p className="text-sm text-[#b0b0bb] mt-2">
                {selectedItem.sub}
              </p>
            )}
            {selectedItem.desc && (
              <p className="text-sm text-[#8c8c94] mt-1">
                {selectedItem.desc}
              </p>
            )}

            <a
              href={getWhatsAppUrl(selectedItem)}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 w-full min-h-[50px] rounded-xl bg-[#25D366] text-[#0a0a0b] font-bold text-sm flex items-center justify-center gap-2 hover:bg-[#20b858] transition-colors"
            >
              Pedir por WhatsApp
            </a>

            <button
              type="button"
              onClick={() => setSelectedItem(null)}
              className="mt-2.5 w-full min-h-[44px] rounded-xl text-sm font-semibold text-[#8c8c94] hover:bg-[#222228] transition-colors"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
