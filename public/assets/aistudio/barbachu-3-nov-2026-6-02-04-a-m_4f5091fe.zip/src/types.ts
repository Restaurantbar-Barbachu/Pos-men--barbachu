export interface Product {
  id: string;
  name: string;
  category: string;
  priceCents: number;
}

export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  initialQuantity: number;
}

export interface Recipe {
  productId: string;
  ingredientId: string;
  quantityPerUnit: number;
}

export interface Catalog {
  products: Product[];
  ingredients: Ingredient[];
  recipes: Recipe[];
}

export interface OrderItem {
  productId: string;
  name: string;
  quantity: number;
  unitPriceCents: number;
}

export type OrderStatus = 'sent' | 'ready' | 'served' | 'closed';

export interface Order {
  id: string;
  table: number;
  waiter: string;
  note: string;
  status: OrderStatus;
  items: OrderItem[];
  totalCents: number;
}

export interface Sale {
  id: string;
  orderId: string;
  totalCents: number;
  paymentMethod: 'cash' | 'card';
}

export interface AppState {
  schemaVersion: number;
  orders: Order[];
  sales: Sale[];
  stock: Record<string, number>;
  nextOrderNumber: number;
}

export interface MenuItemData {
  id: string;
  name: string;
  price: string;
  priceCents?: number;
  group: string;
  sub?: string;
  icon?: string;
  desc?: string;
}

export interface MenuSectionData {
  id: string;
  title: string;
  part?: string;
  items: MenuItemData[];
  note?: string;
  subcategories?: {
    caption: string;
    description?: string;
    items: MenuItemData[];
  }[];
}
