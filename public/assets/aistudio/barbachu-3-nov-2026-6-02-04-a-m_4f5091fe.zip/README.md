# Barbachu — Restaurante Bar & POS (React + TypeScript)

Aplicación moderna desarrollada en React + TypeScript y Vite que integra el sistema de punto de venta (POS) y el menú digital interactivo para el restaurante **Barbachu** (Poza Rica #4984, San Pedrito).

## Características principales

### 1. Sistema POS Barbachu (Operación / Punto de Venta)
- **Venta / Nueva Comanda**:
  - Asignación de mesa (Mesa 1 a Mesa 12)
  - Nombre del mesero y notas personalizadas para cocina
  - Catálogo de productos interactivo con filtrado por categoría
  - Control de cantidades en tiempo real (`+` / `−`) y cálculo preciso de totales
- **Comandas Activas & Historial**:
  - Control de ciclo de vida de comandas: `Enviada` → `Lista` → `Entregada` → `Cobrada`
  - Desglose por mesa, productos, mesero y notas de cocina
- **Caja & Cobros**:
  - Cobro simulado en Efectivo o Tarjeta
  - Registro de transacciones y cálculo automático del monto total cobrado
- **Inventario Simulado**:
  - Descuento automático de insumos según recetas sintéticas al cerrar una comanda entregada
  - Control de stock y alerta ante existencias insuficientes
- **Persistencia**:
  - Almacenamiento local mediante `localStorage` bajo la clave `barbachu.pos-demo.v1`
  - Función de reinicio de demo con confirmación

### 2. Menú Digital Barbachu (Cliente)
- Diseño oscuro elegante con acentos dorados (`#0a0a0b` y `#c8a84b`)
- Barra sticky de navegación rápida por categorías: Especialidades, Platillos, Hamburguesas, Extras, Botana, Cecina, Micheladas, Cervezas y Bebidas sin alcohol
- Tarjetas interactivas con detalle de cada platillo
- Modal de detalle con botón directo para ordenar vía WhatsApp (`https://wa.me/523314456850`)
- Botón flotante persistente de contacto WhatsApp

## Ejecución en desarrollo

```bash
npm install
npm run dev
```

La aplicación se ejecuta en el puerto 3000 (`http://localhost:3000`).
